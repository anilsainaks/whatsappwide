import mysql from 'mysql2/promise';

// MySQL configuration
const MYSQL_HOST = process.env.MYSQL_HOST || 'localhost';
const MYSQL_PORT = Number(process.env.MYSQL_PORT) || 3306;
const MYSQL_USER = process.env.MYSQL_USER || 'root';
const MYSQL_PASSWORD = process.env.MYSQL_PASSWORD || '07470747';
const MYSQL_DATABASE = process.env.MYSQL_DATABASE || 'whatsappwide';

export let mysqlPool: mysql.Pool | null = null;
let isConnected = false;

export function isDbConnected() {
  return isConnected;
}

export async function connectDB() {
  console.log(`\n⏳ [DB] Attempting to connect to MySQL Database at ${MYSQL_HOST}:${MYSQL_PORT}...`);
  try {
    // Connect to mysql server (without specifying DB first to ensure DB is created)
    const setupConn = await mysql.createConnection({
      host: MYSQL_HOST,
      port: MYSQL_PORT,
      user: MYSQL_USER,
      password: MYSQL_PASSWORD
    });

    // Create database if not exists
    await setupConn.query(`CREATE DATABASE IF NOT EXISTS \`${MYSQL_DATABASE}\``);
    await setupConn.end();

    // Create connection pool with database selected
    mysqlPool = mysql.createPool({
      host: MYSQL_HOST,
      port: MYSQL_PORT,
      user: MYSQL_USER,
      password: MYSQL_PASSWORD,
      database: MYSQL_DATABASE,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });

    // Test connection
    const [pingResult] = await mysqlPool.execute('SELECT 1');
    console.log('✅ [DB] Connected to MySQL Database successfully!');

    // Create Tables
    await createMysqlTables();

    // Seed MySQL database
    await seedMysqlDatabase();

    isConnected = true;
    return true;
  } catch (err) {
    console.error('❌ [DB] Connection to MySQL failed:', err);
    isConnected = false;
    return false;
  }
}

// ==========================================
// MYSQL COMPATIBILITY ENGINES & WRAPPERS
// ==========================================
class MysqlModel {
  tableName: string;

  constructor(tableName: string) {
    this.tableName = tableName;
  }

  find(query: any = {}) {
    return {
      lean: async () => {
        if (!mysqlPool) throw new Error('[DB] Mysql connection pool is not initialized!');
        const [rows]: any = await mysqlPool.execute(`SELECT * FROM \`${this.tableName}\``);
        return rows.map((row: any) => this.rowToObj(row));
      }
    };
  }

  async updateOne(filter: { id: string }, updateObj: { $set: any }, options: { upsert?: boolean } = {}) {
    if (!mysqlPool) throw new Error('[DB] Mysql connection pool is not initialized!');
    const id = filter.id;
    const setFields = updateObj.$set || {};
    
    const data: any = { ...setFields };
    if (!data.id) data.id = id;

    const finalData = this.objToRow(data);
    const keys = Object.keys(finalData);
    
    if (keys.length === 0) return { nModified: 0, ok: 1 };

    const placeholders = keys.map(() => '?').join(', ');
    const updateClauses = keys.map(k => `\`${k}\` = VALUES(\`${k}\`)`).join(', ');

    const sql = `INSERT INTO \`${this.tableName}\` (${keys.map(k => `\`${k}\``).join(', ')}) 
                 VALUES (${placeholders}) 
                 ON DUPLICATE KEY UPDATE ${updateClauses}`;
    
    const values = keys.map(k => finalData[k]);
    await mysqlPool.execute(sql, values);
    
    return { nModified: 1, ok: 1 };
  }

  async deleteOne(filter: { id: string }) {
    if (!mysqlPool) throw new Error('[DB] Mysql connection pool is not initialized!');
    const id = filter.id;
    await mysqlPool.execute(`DELETE FROM \`${this.tableName}\` WHERE id = ?`, [id]);
    return { nRemoved: 1, ok: 1 };
  }

  async deleteMany(filter: any = {}) {
    if (!mysqlPool) throw new Error('[DB] Mysql connection pool is not initialized!');
    await mysqlPool.execute(`DELETE FROM \`${this.tableName}\``);
    return { nRemoved: 1, ok: 1 };
  }

  rowToObj(row: any) {
    if (!row) return null;
    const result = { ...row };

    if (result.createdAt instanceof Date) result.createdAt = result.createdAt.toISOString();
    if (result.updatedAt instanceof Date) result.updatedAt = result.updatedAt.toISOString();

    if (this.tableName === 'users') {
      result.campaignApproved = result.campaignApproved === 1 || result.campaignApproved === true;
    }
    
    if (this.tableName === 'admin_staff') {
      try {
        result.accesses = typeof result.accesses === 'string' ? JSON.parse(result.accesses) : result.accesses || {};
      } catch (e) { result.accesses = {}; }
    }
    
    if (this.tableName === 'campaigns') {
      result.isDemo = result.isDemo === 1 || result.isDemo === true;
      result.isPaused = result.isPaused === 1 || result.isPaused === true;
      result.isScanned = result.isScanned === 1 || result.isScanned === true;
      result.isRefunded = result.isRefunded === 1 || result.isRefunded === true;
      
      try {
        result.files = typeof result.files === 'string' ? JSON.parse(result.files) : result.files || [];
      } catch (e) { result.files = []; }

      try {
        result.numbers = typeof result.numbers === 'string' ? JSON.parse(result.numbers) : result.numbers || [];
      } catch (e) { result.numbers = []; }

      try {
        result.originalNumbers = typeof result.originalNumbers === 'string' ? JSON.parse(result.originalNumbers) : result.originalNumbers || [];
      } catch (e) { result.originalNumbers = []; }

      try {
        result.buttonDetails = typeof result.buttonDetails === 'string' ? JSON.parse(result.buttonDetails) : result.buttonDetails || {};
      } catch (e) { result.buttonDetails = {}; }

      try {
        result.reportData = typeof result.reportData === 'string' ? JSON.parse(result.reportData) : result.reportData || [];
      } catch (e) { result.reportData = []; }
    }

    return result;
  }

  objToRow(obj: any) {
    const result = { ...obj };
    
    delete result._id;
    delete result.__v;
    delete result.createdAt;
    delete result.updatedAt;

    if (this.tableName === 'users') {
      if (typeof result.campaignApproved === 'boolean') {
        result.campaignApproved = result.campaignApproved ? 1 : 0;
      }
    }

    if (this.tableName === 'admin_staff') {
      if (result.accesses && typeof result.accesses === 'object') {
        result.accesses = JSON.stringify(result.accesses);
      }
    }

    if (this.tableName === 'campaigns') {
      if (typeof result.isDemo === 'boolean') result.isDemo = result.isDemo ? 1 : 0;
      if (typeof result.isPaused === 'boolean') result.isPaused = result.isPaused ? 1 : 0;
      if (typeof result.isScanned === 'boolean') result.isScanned = result.isScanned ? 1 : 0;
      if (typeof result.isRefunded === 'boolean') result.isRefunded = result.isRefunded ? 1 : 0;

      if (result.files && typeof result.files === 'object') result.files = JSON.stringify(result.files);
      if (result.numbers && typeof result.numbers === 'object') result.numbers = JSON.stringify(result.numbers);
      if (result.originalNumbers && typeof result.originalNumbers === 'object') result.originalNumbers = JSON.stringify(result.originalNumbers);
      if (result.buttonDetails && typeof result.buttonDetails === 'object') result.buttonDetails = JSON.stringify(result.buttonDetails);
      if (result.reportData && typeof result.reportData === 'object') result.reportData = JSON.stringify(result.reportData);
    }

    return result;
  }
}

const MysqlUser = new MysqlModel('users');
const MysqlCampaign = new MysqlModel('campaigns');
const MysqlTransaction = new MysqlModel('transactions');
const MysqlCity = new MysqlModel('cities');
const MysqlWhitelist = new MysqlModel('whitelisted_numbers');
const MysqlNonWhatsapp = new MysqlModel('non_whatsapp_numbers');
const MysqlWhitelistRecord = new MysqlModel('whitelist_records');
const MysqlNonWhatsappRecord = new MysqlModel('non_whatsapp_records');
const MysqlAdminStaff = new MysqlModel('admin_staff');
const MysqlCampaignConfig = new MysqlModel('campaign_configs');

export const DbUser = {
  find: (query?: any) => MysqlUser.find(query),
  updateOne: (filter: any, update: any, options?: any) => MysqlUser.updateOne(filter, update, options),
  deleteOne: (filter: any) => MysqlUser.deleteOne(filter),
  deleteMany: (filter: any) => MysqlUser.deleteMany(filter)
} as any;

export const DbCampaign = {
  find: (query?: any) => MysqlCampaign.find(query),
  updateOne: (filter: any, update: any, options?: any) => MysqlCampaign.updateOne(filter, update, options),
  deleteOne: (filter: any) => MysqlCampaign.deleteOne(filter),
  deleteMany: (filter: any) => MysqlCampaign.deleteMany(filter)
} as any;

export const DbTransaction = {
  find: (query?: any) => MysqlTransaction.find(query),
  updateOne: (filter: any, update: any, options?: any) => MysqlTransaction.updateOne(filter, update, options),
  deleteOne: (filter: any) => MysqlTransaction.deleteOne(filter),
  deleteMany: (filter: any) => MysqlTransaction.deleteMany(filter)
} as any;

export const DbCity = {
  find: (query?: any) => MysqlCity.find(query),
  updateOne: (filter: any, update: any, options?: any) => MysqlCity.updateOne(filter, update, options),
  deleteOne: (filter: any) => MysqlCity.deleteOne(filter),
  deleteMany: (filter: any) => MysqlCity.deleteMany(filter)
} as any;

export const DbWhitelist = {
  find: (query?: any) => MysqlWhitelist.find(query),
  updateOne: (filter: any, update: any, options?: any) => MysqlWhitelist.updateOne(filter, update, options),
  deleteOne: (filter: any) => MysqlWhitelist.deleteOne(filter),
  deleteMany: (filter: any) => MysqlWhitelist.deleteMany(filter)
} as any;

export const DbNonWhatsapp = {
  find: (query?: any) => MysqlNonWhatsapp.find(query),
  updateOne: (filter: any, update: any, options?: any) => MysqlNonWhatsapp.updateOne(filter, update, options),
  deleteOne: (filter: any) => MysqlNonWhatsapp.deleteOne(filter),
  deleteMany: (filter: any) => MysqlNonWhatsapp.deleteMany(filter)
} as any;

export const DbWhitelistRecord = {
  find: (query?: any) => MysqlWhitelistRecord.find(query),
  updateOne: (filter: any, update: any, options?: any) => MysqlWhitelistRecord.updateOne(filter, update, options),
  deleteOne: (filter: any) => MysqlWhitelistRecord.deleteOne(filter),
  deleteMany: (filter: any) => MysqlWhitelistRecord.deleteMany(filter)
} as any;

export const DbNonWhatsappRecord = {
  find: (query?: any) => MysqlNonWhatsappRecord.find(query),
  updateOne: (filter: any, update: any, options?: any) => MysqlNonWhatsappRecord.updateOne(filter, update, options),
  deleteOne: (filter: any) => MysqlNonWhatsappRecord.deleteOne(filter),
  deleteMany: (filter: any) => MysqlNonWhatsappRecord.deleteMany(filter)
} as any;

export const DbAdminStaff = {
  find: (query?: any) => MysqlAdminStaff.find(query),
  updateOne: (filter: any, update: any, options?: any) => MysqlAdminStaff.updateOne(filter, update, options),
  deleteOne: (filter: any) => MysqlAdminStaff.deleteOne(filter),
  deleteMany: (filter: any) => MysqlAdminStaff.deleteMany(filter)
} as any;

export const DbCampaignConfig = {
  find: (query?: any) => MysqlCampaignConfig.find(query),
  updateOne: (filter: any, update: any, options?: any) => MysqlCampaignConfig.updateOne(filter, update, options),
  deleteOne: (filter: any) => MysqlCampaignConfig.deleteOne(filter),
  deleteMany: (filter: any) => MysqlCampaignConfig.deleteMany(filter)
} as any;

// ==========================================
// GENERAL CREATION / SEEDING HELPERS
// ==========================================
async function createMysqlTables() {
  if (!mysqlPool) return;

  await mysqlPool.execute(`
    CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(255) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      username VARCHAR(255) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL,
      mobile VARCHAR(255) DEFAULT '',
      email VARCHAR(255) DEFAULT '',
      role VARCHAR(50) DEFAULT 'User',
      status VARCHAR(50) DEFAULT 'Active',
      location VARCHAR(255) DEFAULT '',
      uplink VARCHAR(255) DEFAULT '',
      domCredits INT DEFAULT 0,
      intCredits INT DEFAULT 0,
      btnCredits INT DEFAULT 0,
      cuttingPercentage VARCHAR(50) DEFAULT '0%',
      privateSenderExpiry VARCHAR(255) DEFAULT NULL,
      privateSenderActivation VARCHAR(255) DEFAULT NULL,
      privateSenderSubscription VARCHAR(55) DEFAULT 'none',
      privateSenderPendingDuration INT DEFAULT NULL,
      planExpiryDate VARCHAR(255) DEFAULT NULL,
      campaignApproved TINYINT(1) DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await mysqlPool.execute(`
    CREATE TABLE IF NOT EXISTS campaigns (
      id VARCHAR(255) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      status VARCHAR(50) DEFAULT 'Pending',
      date VARCHAR(255) NOT NULL,
      message LONGTEXT,
      files LONGTEXT,
      type VARCHAR(255) DEFAULT 'Standard',
      userId VARCHAR(255),
      userName VARCHAR(255),
      creditsUsed INT DEFAULT 0,
      rejectionReason VARCHAR(255) DEFAULT NULL,
      isDemo TINYINT(1) DEFAULT 0,
      assignedServerId VARCHAR(255) DEFAULT NULL,
      filterMode VARCHAR(255) DEFAULT NULL,
      numbers LONGTEXT,
      isPaused TINYINT(1) DEFAULT 0,
      isScanned TINYINT(1) DEFAULT 0,
      sentCount INT DEFAULT 0,
      totalCount INT DEFAULT 0,
      originalNumbers LONGTEXT,
      buttonDetails TEXT,
      reportData LONGTEXT,
      isRefunded TINYINT(1) DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // Migration for existing tables where columns might still be limited TEXT
  try {
    await mysqlPool.execute(`ALTER TABLE campaigns MODIFY COLUMN files LONGTEXT`);
  } catch (e) {}
  try {
    await mysqlPool.execute(`ALTER TABLE campaigns MODIFY COLUMN message LONGTEXT`);
  } catch (e) {}
  try {
    await mysqlPool.execute(`ALTER TABLE campaigns MODIFY COLUMN numbers LONGTEXT`);
  } catch (e) {}
  try {
    await mysqlPool.execute(`ALTER TABLE campaigns MODIFY COLUMN originalNumbers LONGTEXT`);
  } catch (e) {}

  await mysqlPool.execute(`
    CREATE TABLE IF NOT EXISTS transactions (
      id VARCHAR(255) PRIMARY KEY,
      userId VARCHAR(255) NOT NULL,
      amount INT NOT NULL,
      type VARCHAR(50) NOT NULL,
      date VARCHAR(255) NOT NULL,
      note TEXT,
      action VARCHAR(50) NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await mysqlPool.execute(`
    CREATE TABLE IF NOT EXISTS cities (
      id VARCHAR(255) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await mysqlPool.execute(`
    CREATE TABLE IF NOT EXISTS whitelisted_numbers (
      id VARCHAR(255) PRIMARY KEY,
      number VARCHAR(255) NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await mysqlPool.execute(`
    CREATE TABLE IF NOT EXISTS non_whatsapp_numbers (
      id VARCHAR(255) PRIMARY KEY,
      number VARCHAR(255) NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await mysqlPool.execute(`
    CREATE TABLE IF NOT EXISTS whitelist_records (
      id VARCHAR(255) PRIMARY KEY,
      number VARCHAR(255) NOT NULL,
      status VARCHAR(255) NOT NULL,
      result VARCHAR(255) DEFAULT '',
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await mysqlPool.execute(`
    CREATE TABLE IF NOT EXISTS non_whatsapp_records (
      id VARCHAR(255) PRIMARY KEY,
      number VARCHAR(255) NOT NULL,
      status VARCHAR(255) NOT NULL,
      result VARCHAR(255) DEFAULT '',
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await mysqlPool.execute(`
    CREATE TABLE IF NOT EXISTS admin_staff (
      id VARCHAR(255) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL,
      status VARCHAR(50) NOT NULL,
      accesses TEXT,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  await mysqlPool.execute(`
    CREATE TABLE IF NOT EXISTS campaign_configs (
      id VARCHAR(255) PRIMARY KEY,
      category VARCHAR(50) NOT NULL,
      name VARCHAR(255) NOT NULL,
      size VARCHAR(255) NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);
}

async function seedMysqlDatabase() {
  if (!mysqlPool) return;
  try {
    const [rows]: any = await mysqlPool.execute('SELECT COUNT(*) as count FROM users');
    if (rows[0].count === 0) {
      console.log('🌱 [DB] No users found in MySQL. Seeding initial default Admin and User...');
      const defaultAdmin = [
        'admin', 'Administrator', 'anil', 'sain', '9999999999', 'admin@example.com',
        'Admin', 'Active', 'Delhi', 'system', 1000000, 1000000, 1000000, '0',
        null, null, 'none', null, '2030-05-30T10:00:00.000Z', 1
      ];
      const defaultUser = [
        '2', 'Priyanka', 'priyanka', 'priyanka', '9932082831', 'priyanka@example.com',
        'User', 'Active', 'Delhi', 'admin', 100, 100, 100, '0',
        null, null, 'none', null, '2030-05-30T10:00:00.000Z', 1
      ];

      const fieldsStr = '`id`, `name`, `username`, `password`, `mobile`, `email`, `role`, `status`, `location`, `uplink`, `domCredits`, `intCredits`, `btnCredits`, `cuttingPercentage`, `privateSenderExpiry`, `privateSenderActivation`, `privateSenderSubscription`, `privateSenderPendingDuration`, `planExpiryDate`, `campaignApproved`';
      const placeholders = Array(20).fill('?').join(', ');
      
      await mysqlPool.execute(`INSERT INTO users (${fieldsStr}) VALUES (${placeholders})`, defaultAdmin);
      await mysqlPool.execute(`INSERT INTO users (${fieldsStr}) VALUES (${placeholders})`, defaultUser);
      console.log('✅ [DB] MySQL seeded successfully!');
    }

    // Seed Cities
    const [cityRows]: any = await mysqlPool.execute('SELECT COUNT(*) as count FROM cities');
    if (cityRows[0].count === 0) {
      console.log('🌱 [DB] No cities found in MySQL. Seeding default Indian zones...');
      const defaultCitiesList = [
        "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar",
        "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa",
        "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka",
        "Kerala", "Ladakh", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya",
        "Mizoram", "Nagaland", "Odisha", "Puducherry", "Punjab", "Rajasthan", "Sikkim",
        "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"
      ];
      for (const name of defaultCitiesList) {
        await mysqlPool.execute('INSERT INTO cities (id, name) VALUES (?, ?)', [name, name]);
      }
    }

    // Seed Admin Staff
    const [staffRows]: any = await mysqlPool.execute('SELECT COUNT(*) as count FROM admin_staff');
    if (staffRows[0].count === 0) {
      console.log('🌱 [DB] No admin staff found in MySQL. Seeding default developer...');
      await mysqlPool.execute('INSERT INTO admin_staff (id, name, email, status, accesses) VALUES (?, ?, ?, ?, ?)', [
        '1', 'Ravi', 'ravi@admin.com', 'Active', JSON.stringify({ 'Admin Staff': true, 'Users': true })
      ]);
    }

    // Seed Campaign Configs
    const [configRows]: any = await mysqlPool.execute('SELECT COUNT(*) as count FROM campaign_configs');
    if (configRows[0].count === 0) {
      console.log('🌱 [DB] No campaign configs found in MySQL. Seeding standard protocol preset...');
      const defaultCampaignConfigs = [
        // General configs
        { id: 'gen-1', category: 'General', name: 'Image Size', size: '03 MB' },
        { id: 'gen-2', category: 'General', name: 'Number of Images', size: '2' },
        { id: 'gen-3', category: 'General', name: 'PDF Size', size: '03 MB' },
        { id: 'gen-4', category: 'General', name: 'Number Of PDFs', size: '1' },
        { id: 'gen-5', category: 'General', name: 'Video Size', size: '10 MB' },
        { id: 'gen-6', category: 'General', name: 'Number of Videos', size: '1' },
        { id: 'gen-7', category: 'General', name: 'Running Message', size: 'Campaign will be deliver between 8.00 AM to 6 PM, Monday - Saturday.' },
        { id: 'gen-8', category: 'General', name: 'Auto Send Campaign No.', size: '10' },
        { id: 'gen-9', category: 'General', name: 'Phase Number Count', size: '50' },
        { id: 'gen-10', category: 'General', name: 'Phase Gap Time', size: '100' },
        { id: 'gen-11', category: 'General', name: 'Phase Gap Time Filter', size: '1000' },
        { id: 'gen-12', category: 'General', name: 'Maximum Phone Numbers', size: '10000000' },
        // Domestic configs
        { id: 'dom-1', category: 'Domestic', name: 'DOM Demo Max Campaigns Allowed', size: '3' },
        { id: 'dom-2', category: 'Domestic', name: 'DOM Max Campaigns Allowed', size: '15' },
        { id: 'dom-3', category: 'Domestic', name: 'DOM Campaigns Allowed From Time', size: '08:01 AM' },
        { id: 'dom-4', category: 'Domestic', name: 'DOM Campaigns Allowed To Time', size: '06:01 PM' },
        { id: 'dom-5', category: 'Domestic', name: 'DOM Demo Campaigns Allowed From Time', size: '09:31 AM' },
        { id: 'dom-6', category: 'Domestic', name: 'DOM Demo Campaigns Allowed To Time', size: '08:59 PM' },
        { id: 'dom-7', category: 'Domestic', name: 'DOM Demo Default Filtering Server ID', size: '6865348853639d14732f3a85' },
        { id: 'dom-8', category: 'Domestic', name: 'DOM Demo Default Running Server ID', size: '6865348853639d14732f3a85' },
        // International configs
        { id: 'int-1', category: 'International', name: 'INT Demo Max Campaigns Allowed', size: '3' },
        { id: 'int-2', category: 'International', name: 'INT Max Campaigns Allowed', size: '15' },
        { id: 'int-3', category: 'International', name: 'INT Campaigns Allowed From Time', size: '08:01 AM' },
        { id: 'int-4', category: 'International', name: 'INT Campaigns Allowed To Time', size: '06:01 PM' },
        { id: 'int-5', category: 'International', name: 'INT Demo Campaigns Allowed From Time', size: '09:31 AM' },
        { id: 'int-6', category: 'International', name: 'INT Demo Campaigns Allowed To Time', size: '08:59 PM' },
        { id: 'int-7', category: 'International', name: 'INT Demo Default Filtering Server ID', size: '6865348853639d14732f3a85' },
        { id: 'int-8', category: 'International', name: 'INT Demo Default Running Server ID', size: '6865348853639d14732f3a85' },
        // Button configs
        { id: 'btn-1', category: 'Button', name: 'BTN Demo Max Campaigns Allowed', size: '3' },
        { id: 'btn-2', category: 'Button', name: 'BTN Max Campaigns Allowed', size: '15' },
        { id: 'btn-3', category: 'Button', name: 'BTN Campaigns Allowed From Time', size: '08:01 AM' },
        { id: 'btn-4', category: 'Button', name: 'BTN Campaigns Allowed To Time', size: '06:01 PM' },
        { id: 'btn-5', category: 'Button', name: 'BTN Demo Campaigns Allowed From Time', size: '09:31 AM' },
        { id: 'btn-6', category: 'Button', name: 'BTN Demo Campaigns Allowed To Time', size: '08:59 PM' },
        { id: 'btn-7', category: 'Button', name: 'BTN Demo Default Filtering Server ID', size: '6865348853639d14732f3a85' },
        { id: 'btn-8', category: 'Button', name: 'BTN Demo Default Running Server ID', size: '6865348853639d14732f3a85' }
      ];
      for (const conf of defaultCampaignConfigs) {
        await mysqlPool.execute('INSERT INTO campaign_configs (id, category, name, size) VALUES (?, ?, ?, ?)', [
          conf.id, conf.category, conf.name, conf.size
        ]);
      }
    }
  } catch (err) {
    console.error('❌ [DB] Error during seeding MySQL database:', err);
  }
}
