import React, { useState, useEffect } from 'react';
import { 
  MousePointer2, 
  Globe, 
  Smartphone, 
  Play, 
  MoreVertical, 
  Eye, 
  Pencil, 
  Send, 
  Download, 
  RefreshCw, 
  RotateCcw, 
  XCircle 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Campaign } from '../types';

interface TableActionProps {
  icon: any;
  label: string;
  onClick: () => void;
  color?: string;
}

const TableAction = ({ icon: Icon, label, onClick, color = "text-slate-300" }: TableActionProps) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-2.5 text-xs font-black transition-all hover:bg-white/5 group ${color}`}
  >
    <Icon size={16} className="opacity-50 group-hover:opacity-100 transition-opacity" />
    <span className="uppercase tracking-widest">{label}</span>
  </button>
);

interface CampaignTableProps {
  campaigns: Campaign[]; 
  onFinish?: (id: string, serverId?: string) => void; 
  onView?: (campaign: Campaign) => void;
  onReject?: (id: string) => void;
  onRestore?: (id: string) => void;
  onReport?: (campaign: Campaign) => void;
  onEdit?: (campaign: Campaign) => void;
  onTestMessage?: (campaign: Campaign) => void;
  onReset?: (id: string) => void;
  onRefundNonWA?: (id: string) => void;
  isAdmin?: boolean;
  isSystemAdmin?: boolean;
}

export const CampaignTable = React.memo(({ 
  campaigns, 
  onFinish, 
  onView, 
  onReject, 
  onRestore, 
  onReport, 
  onEdit, 
  onTestMessage, 
  onReset, 
  onRefundNonWA, 
  isAdmin, 
  isSystemAdmin 
}: CampaignTableProps) => {
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);

  useEffect(() => {
    const handleClickOutside = () => setOpenMenuId(null);
    if (openMenuId) {
      window.addEventListener('click', handleClickOutside);
    }
    return () => window.removeEventListener('click', handleClickOutside);
  }, [openMenuId]);

  return (
    <div className="overflow-x-auto min-h-[400px] custom-scrollbar">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="border-b border-slate-100">
            <th className="py-5 px-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Campaign Hub</th>
            <th className="py-5 px-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Engagement Type</th>
            <th className="py-5 px-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Status Matrix</th>
            <th className="py-5 px-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Creator</th>
            <th className="py-5 px-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Volume</th>
            <th className="py-5 px-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
          {campaigns.map((c) => (
            <motion.tr 
              layout
              key={c.id} 
              className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-colors group"
            >
              <td className="py-5 px-6">
                <div className="flex flex-col">
                   <span className="text-sm font-bold text-slate-800 tracking-tight">{c.name}</span>
                   <span className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">{c.date}</span>
                </div>
              </td>
              <td className="py-5 px-6 text-center">
                <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full border text-[10px] font-black uppercase tracking-wider ${
                  c.type === 'Button' ? 'bg-indigo-50 border-indigo-100 text-indigo-700' :
                  c.type === 'International' ? 'bg-amber-50 border-amber-100 text-amber-700' :
                  'bg-sky-50 border-sky-100 text-sky-700'
                }`}>
                   {c.type === 'Button' ? <MousePointer2 size={12} /> : 
                    c.type === 'International' ? <Globe size={12} /> : 
                    <Smartphone size={12} />}
                   {c.type === 'Button' ? 'BUTTON' : 
                    c.type === 'International' ? 'INTERNATIONAL' : 
                    'DOMESTIC'}
                </div>
              </td>
              <td className="py-5 px-6 text-center">
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                  (c.status === 'Completed' || (isSystemAdmin && c.status === 'Pending' && c.isScanned)) ? 'bg-emerald-100 text-emerald-700' : 
                  c.status === 'Active' ? 'bg-blue-100 text-blue-700 animate-pulse' :
                  c.status === 'Pending' ? 'bg-amber-100 text-amber-700' :
                  'bg-red-100 text-red-700'
                }`}>
                  <div className={`w-1.5 h-1.5 rounded-full ${
                    (c.status === 'Completed' || (isSystemAdmin && c.status === 'Pending' && c.isScanned)) ? 'bg-emerald-500' : 
                    c.status === 'Active' ? 'bg-blue-500' :
                    c.status === 'Pending' ? 'bg-amber-500' :
                    'bg-red-500'
                  }`} />
                  {c.status === 'Completed' ? 'OPTIMIZED' : ((isSystemAdmin && c.status === 'Pending' && c.isScanned) ? 'READY TO SEND' : c.status)}
                </span>
              </td>
              <td className="py-5 px-6">
                 <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-slate-100 flex items-center justify-center text-[10px] font-black text-slate-400">
                       {c.userName?.charAt(0).toUpperCase() || 'U'}
                    </div>
                    <span className="text-xs font-bold text-slate-600">{c.userName || 'Anonymous'}</span>
                 </div>
              </td>
              <td className="py-5 px-6 text-center">
                 <span className="text-xs font-black text-slate-700">{c.creditsUsed?.toLocaleString() || 0}</span>
              </td>
              <td className="py-5 px-6 text-right">
                <div className="flex items-center justify-end gap-2">
                    {isAdmin && onFinish && (c.status === 'Pending' || c.status === 'Active') && (
                      <button 
                        onClick={() => onFinish(c.id)}
                        className="bg-emerald-500 hover:bg-emerald-600 text-white w-8 h-8 flex items-center justify-center rounded-xl transition-all shadow-lg shadow-emerald-500/20 active:scale-90"
                        title="Inception Campaign"
                      >
                        <Play size={14} fill="currentColor" />
                      </button>
                    )}
                    
                    <div className="relative">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setOpenMenuId(openMenuId === c.id ? null : c.id);
                        }}
                        className="bg-slate-900 hover:bg-slate-800 text-white w-8 h-8 flex items-center justify-center rounded-xl transition-all shadow-md active:scale-90"
                      >
                        <MoreVertical size={14} />
                      </button>

                      <AnimatePresence>
                        {openMenuId === c.id && (
                          <>
                            <div className="fixed inset-0 z-40" onClick={() => setOpenMenuId(null)} />
                            <motion.div
                              initial={{ opacity: 0, scale: 0.9, y: -10 }}
                              animate={{ opacity: 1, scale: 1, y: 0 }}
                              exit={{ opacity: 0, scale: 0.9 }}
                              className="absolute right-0 top-full mt-2 w-56 bg-slate-900 border border-white/10 rounded-2xl shadow-2xl py-2 z-50 backdrop-blur-xl"
                            >
                              <TableAction icon={Eye} label="Inspect Details" onClick={() => { onView?.(c); setOpenMenuId(null); }} />
                              {(isAdmin || c.status === 'Pending') && onEdit && (
                                <TableAction icon={Pencil} label="Modify Content" onClick={() => { onEdit(c); setOpenMenuId(null); }} />
                              )}
                              {isAdmin && onTestMessage && (
                                <TableAction icon={Send} label="Deploy Test" onClick={() => { onTestMessage(c); setOpenMenuId(null); }} />
                              )}
                              {c.status === 'Completed' && onReport && (
                                <TableAction icon={Download} label="Export Analytics" onClick={() => { onReport?.(c); setOpenMenuId(null); }} />
                              )}
                              {isAdmin && onReset && (c.status === 'Completed' || c.status === 'Active') && (
                                <TableAction icon={RefreshCw} label="Re-Initialize" onClick={() => { onReset(c.id); setOpenMenuId(null); }} />
                              )}
                              {onRestore && c.status === 'Rejected' && (
                                <TableAction icon={RotateCcw} label="Restore Session" onClick={() => { onRestore(c.id); setOpenMenuId(null); }} />
                              )}
                              {isAdmin && onReject && (c.status === 'Pending' || c.status === 'Active') && (
                                <TableAction icon={XCircle} label="Terminate" color="text-red-400" onClick={() => { onReject(c.id); setOpenMenuId(null); }} />
                              )}
                              {isAdmin && onRefundNonWA && c.status === 'Completed' && !c.isRefunded && (
                                <TableAction icon={RotateCcw} label="Non-WA Refund" color="text-emerald-400" onClick={() => { onRefundNonWA(c.id); setOpenMenuId(null); }} />
                              )}
                            </motion.div>
                          </>
                        )}
                      </AnimatePresence>
                    </div>
                </div>
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
});

CampaignTable.displayName = 'CampaignTable';
