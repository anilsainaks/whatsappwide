import React, { useState, useMemo, useEffect } from 'react';
import { 
  Zap, 
  X, 
  Search, 
  ShieldCheck, 
  Globe, 
  ArrowLeftRight, 
  Check, 
  RefreshCw, 
  Cpu, 
  Users, 
  User as UserIcon, 
  Layers, 
  HardDrive, 
  ShieldAlert, 
  Terminal, 
  Send, 
  Power 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Campaign, Channel, FilterMode } from '../types';

interface RunCampaignModalProps {
  campaign?: Campaign; 
  allCampaigns: Campaign[];
  channels: Channel[]; 
  mockDb: string[];
  nonWaDb: string[];
  onClose: () => void; 
  onRun: (serverId: string, filterMode: FilterMode) => void;
  onDirectFinish: (id: string) => void;
  isAdmin?: boolean;
  onScanned?: (id: string) => void;
}

export const RunCampaignModal = ({ 
  campaign, 
  allCampaigns,
  channels, 
  mockDb,
  nonWaDb,
  onClose, 
  onRun,
  onDirectFinish,
  isAdmin,
  onScanned
}: RunCampaignModalProps) => {
  const [step, setStep] = useState<'processing' | 'selection'>('processing');
  
  const activeConnectedChannels = useMemo(() => {
    return channels.filter(ch => !ch.isRestricted);
  }, [channels]);

  const [selectedServerIds, setSelectedServerIds] = useState<string[]>(() => {
    return activeConnectedChannels.map(ch => ch.id);
  });

  const [filterMode, setFilterMode] = useState<FilterMode>('all');

  const isAllSelected = activeConnectedChannels.length > 0 && selectedServerIds.length === activeConnectedChannels.length;

  const handleSelectAllToggle = () => {
    if (isAllSelected) {
      setSelectedServerIds([]);
    } else {
      setSelectedServerIds(activeConnectedChannels.map(ch => ch.id));
    }
  };

  const toggleServerSelection = (id: string) => {
    setSelectedServerIds(prev => {
      if (prev.includes(id)) {
        return prev.filter(x => x !== id);
      } else {
        return [...prev, id];
      }
    });
  };
  
  const [processingState, setProcessingState] = useState({
    filterNonWA: 'pending',
    checkWhitelist: 'pending',
    findNonWA: 'pending',
    comparePrev: 'pending',
    commonNumbers: 0,
    whitelistedNumbers: 0,
    nonWaNumbers: 0
  });

  useEffect(() => {
    const calculateCounts = () => {
      if (!campaign?.numbers) return { wCount: 0, cCount: 0, nwCount: 0 };
      
      const whitelistSet = new Set(mockDb.map(n => n.replace(/\D/g, '').slice(-10)));
      const nonWaSet = new Set(nonWaDb.map(n => n.replace(/\D/g, '').slice(-10)));
      
      const otherCampaignsNumbers = (allCampaigns || [])
        .filter(c => c.id !== campaign.id)
        .flatMap(c => c.numbers || []);
      const otherCampaignsSet = new Set(otherCampaignsNumbers.map(n => n.replace(/\D/g, '').slice(-10)));
      
      let wc = 0;
      let cc = 0;
      let nwc = 0;
      campaign.numbers.forEach(n => {
        const cleanNum = n.replace(/\D/g, '').slice(-10);
        if (cleanNum.length >= 10) {
          if (whitelistSet.has(cleanNum)) wc++;
          if (otherCampaignsSet.has(cleanNum)) cc++;
          if (nonWaSet.has(cleanNum)) nwc++;
        }
      });
      return { wCount: wc, cCount: cc, nwCount: nwc };
    };

    if (campaign?.isScanned) {
      const counts = calculateCounts();
      setProcessingState({
        filterNonWA: 'completed',
        checkWhitelist: 'completed',
        findNonWA: 'completed',
        comparePrev: 'completed',
        commonNumbers: counts.cCount,
        whitelistedNumbers: counts.wCount,
        nonWaNumbers: counts.nwCount
      });
      return;
    }

    const simulateProcessing = async () => {
      // Step 1
      setProcessingState(prev => ({ ...prev, filterNonWA: 'processing' }));
      await new Promise(r => setTimeout(r, 800));
      setProcessingState(prev => ({ ...prev, filterNonWA: 'completed' }));

      // Step 2
      setProcessingState(prev => ({ ...prev, checkWhitelist: 'processing' }));
      await new Promise(r => setTimeout(r, 600));
      setProcessingState(prev => ({ ...prev, checkWhitelist: 'completed' }));

      // Step 3
      setProcessingState(prev => ({ ...prev, findNonWA: 'processing' }));
      await new Promise(r => setTimeout(r, 1000));
      setProcessingState(prev => ({ ...prev, findNonWA: 'completed' }));

      // Step 4
      setProcessingState(prev => ({ ...prev, comparePrev: 'processing' }));
      await new Promise(r => setTimeout(r, 900));
      
      const { wCount, cCount, nwCount } = calculateCounts();

      setProcessingState(prev => ({ 
        ...prev, 
        comparePrev: 'completed',
        commonNumbers: cCount,
        whitelistedNumbers: wCount,
        nonWaNumbers: nwCount
      }));

      // Set as scanned but stay on this step to show results
      if (campaign?.id && onScanned) {
        onScanned(campaign.id);
      }
    };

    if (campaign) {
      simulateProcessing();
    }
  }, [campaign, mockDb, allCampaigns]);

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 30 }}
        className="glass rounded-[3rem] shadow-2xl w-full max-w-xl overflow-hidden border border-white/40 flex flex-col"
      >
        <div className="p-10 border-b border-white/20 bg-white/40 shadow-sm flex justify-between items-center">
          <div className="space-y-1">
             <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-4">
               <Zap size={24} className="text-amber-500" />
               Mission Activation
             </h3>
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Transmission: {campaign?.name}</p>
          </div>
          <button onClick={onClose} className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group border border-white/40">
            <X size={24} className="group-hover:rotate-90 transition-transform" />
          </button>
        </div>
        
        <div className="p-10 space-y-8 bg-white/10 max-h-[75vh] overflow-y-auto custom-scrollbar">
          <AnimatePresence mode="wait">
            {step === 'processing' ? (
              <motion.div 
                key="processing"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="space-y-10"
              >
                <div>
                  {isAdmin && (
                    <>
                      <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 mb-6 block">Heuristic Scan Sequence</label>
                      
                      <div className="grid grid-cols-3 gap-4 mb-10">
                        <div className="glass p-5 rounded-3xl border border-white/60 shadow-lg text-center space-y-1">
                           <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Whitelisted</p>
                           <p className="text-2xl font-black text-indigo-600">{processingState.whitelistedNumbers}</p>
                        </div>
                        <div className="glass p-5 rounded-3xl border border-white/60 shadow-lg text-center space-y-1">
                           <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Duplicates</p>
                           <p className="text-2xl font-black text-emerald-600">{processingState.commonNumbers}</p>
                        </div>
                        <div className="glass p-5 rounded-3xl border border-white/60 shadow-lg text-center space-y-1">
                           <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Invalid Nos.</p>
                           <p className="text-2xl font-black text-rose-600">{processingState.nonWaNumbers}</p>
                        </div>
                      </div>
                    </>
                  )}
                  
                  <div className="space-y-6 relative ml-6">
                    <div className="absolute left-[-1.5rem] top-4 bottom-4 w-[2px] bg-white/40 shadow-sm" />
                    
                    {[
                      { id: 'filterNonWA', label: 'Initial Filter', desc: 'Removing non-formatted numbers', icon: <Search size={16} />, state: processingState.filterNonWA },
                      { id: 'checkWhitelist', label: 'Whitelist Sync', desc: 'Verifying with whitelist database', icon: <ShieldCheck size={16} />, state: processingState.checkWhitelist },
                      { id: 'findNonWA', label: 'WhatsApp Lookup', desc: 'Verifying active WhatsApp accounts', icon: <Globe size={16} />, state: processingState.findNonWA },
                      { id: 'comparePrev', label: 'Duplicate Check', desc: 'Removing already sent numbers', icon: <ArrowLeftRight size={16} />, state: processingState.comparePrev },
                    ].map((stepItem) => (
                      <div key={stepItem.id} className="relative group">
                        <div className={`absolute left-[-2.15rem] top-2 w-5 h-5 rounded-full z-10 p-1 flex items-center justify-center transition-all shadow-xl ${
                          stepItem.state === 'completed' ? 'bg-indigo-600' : 
                          stepItem.state === 'processing' ? 'bg-amber-400 animate-spin-slow' : 
                          'bg-white/60 border border-white/80'
                        }`}>
                          {stepItem.state === 'completed' ? <Check size={10} className="text-white" strokeWidth={4} /> : 
                           stepItem.state === 'processing' ? <RefreshCw size={10} className="text-white" /> : null}
                        </div>
                        
                        <div className="flex items-center gap-6">
                          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-inner border ${
                            stepItem.state === 'completed' ? 'bg-indigo-600/10 border-indigo-600/20 text-indigo-600' :
                            stepItem.state === 'processing' ? 'bg-amber-400/10 border-amber-400/20 text-amber-400' :
                            'bg-white/40 border-white/60 text-slate-400'
                          }`}>
                            {stepItem.icon}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-4">
                              <h5 className={`text-xs font-black uppercase tracking-widest transition-all ${stepItem.state === 'pending' ? 'text-slate-400' : 'text-slate-900'}`}>
                                {stepItem.label}
                              </h5>
                              {stepItem.state === 'completed' && (
                                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="bg-emerald-500/10 text-emerald-600 text-[8px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 border border-emerald-500/20">
                                   SYNCED
                                </motion.div>
                              )}
                            </div>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter mt-1">{stepItem.desc}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <button 
                  onClick={() => {
                    if (campaign?.id && onScanned) {
                      onScanned(campaign.id);
                    }
                    setStep('selection');
                  }}
                  disabled={processingState.comparePrev !== 'completed'}
                  className="w-full py-6 bg-slate-900 hover:bg-black disabled:bg-slate-200 text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98] flex items-center justify-center gap-4 group"
                >
                  <Cpu size={16} className="group-hover:rotate-180 transition-transform duration-500" />
                  Initialize Link Protocol
                </button>
              </motion.div>
            ) : (
              <motion.div 
                key="selection"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-10"
              >
                <div>
                  <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 mb-6 block">Targeting Parameters</label>
                  <div className="grid grid-cols-2 gap-4 mb-8">
                    {[
                      { id: 'all', label: 'All Numbers', icon: <Users size={14} />, color: 'slate' },
                      { id: 'whitelisted', label: 'Only Whitelisted', icon: <ShieldCheck size={14} />, color: 'indigo' },
                      { id: 'common', label: 'Only Common', icon: <Zap size={14} />, color: 'emerald' },
                      { id: 'both', label: 'Whitelist & Common', icon: <Globe size={14} />, color: 'amber' },
                      { id: 'agent', label: 'WA - Agent', icon: <UserIcon size={14} />, color: 'purple' },
                    ].map((mode) => (
                      <button
                        key={mode.id}
                        onClick={() => setFilterMode(mode.id as any)}
                        className={`flex items-center gap-3 p-4 rounded-2xl border-2 transition-all ${
                          filterMode === mode.id 
                            ? 'border-indigo-600 bg-indigo-50 shadow-md' 
                            : 'border-white/60 bg-white/40 hover:border-white/80'
                        }`}
                      >
                         <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                           filterMode === mode.id ? 'bg-indigo-600 text-white' : 'bg-white/60 text-slate-400'
                         }`}>
                           {mode.icon}
                         </div>
                         <span className={`text-[10px] font-black uppercase tracking-tight ${
                           filterMode === mode.id ? 'text-indigo-900' : 'text-slate-500'
                         }`}>
                           {mode.label}
                         </span>
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center justify-between mb-6">
                    <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Command Center Authorization</label>
                    {activeConnectedChannels.length > 0 && (
                      <button
                        type="button"
                        onClick={handleSelectAllToggle}
                        className="px-4 py-1.5 bg-indigo-50 border border-indigo-200 text-indigo-700 text-[9px] font-black rounded-xl hover:bg-indigo-100 uppercase tracking-wider transition-all"
                      >
                        {isAllSelected ? "Deselect All" : "Select All Channels"}
                      </button>
                    )}
                  </div>
                  
                  {selectedServerIds.length > 0 && (
                    <div className="mb-6 bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100 flex items-center gap-3">
                      <Layers size={16} className="text-indigo-500" />
                      <p className="text-[9px] font-black text-indigo-900 uppercase tracking-wider">
                        {selectedServerIds.length === activeConnectedChannels.length 
                          ? `All ${selectedServerIds.length} connected channels are active. Messages will rotate amongst them round-robin.`
                          : `Campaign will split load round-robin among ${selectedServerIds.length} chosen channel(s).`}
                      </p>
                    </div>
                  )}

                  <div className="space-y-4 max-h-[450px] overflow-y-auto px-2 custom-scrollbar">
                    {channels.length > 0 ? (
                      channels.map(ch => {
                        const isSelected = selectedServerIds.includes(ch.id);
                        return (
                          <button
                            key={ch.id}
                            onClick={() => toggleServerSelection(ch.id)}
                            className={`w-full group relative flex items-center gap-6 p-6 rounded-[2rem] border-2 transition-all overflow-hidden ${
                              isSelected 
                                ? 'border-indigo-600 bg-white/80 shadow-2xl -translate-y-1' 
                                : 'border-white/60 bg-white/40 hover:border-white/80'
                            }`}
                          >
                            <div className={`w-16 h-16 rounded-3xl flex items-center justify-center transition-all shadow-inner ${
                              isSelected ? 'bg-indigo-600 text-white' : 'bg-white/60 text-slate-400 group-hover:text-slate-900'
                            }`}>
                              <HardDrive size={24} />
                            </div>
                            <div className="text-left flex-1">
                              <div className="flex items-center gap-2">
                                <p className="text-sm font-black text-slate-900 uppercase tracking-tight">{ch.name}</p>
                                {ch.isRestricted && (
                                  <span className="px-2 py-0.5 bg-rose-50 border border-rose-200 text-rose-700 text-[8px] font-bold rounded-lg uppercase tracking-wider animate-pulse flex items-center gap-1">
                                    <ShieldAlert size={10} className="stroke-[3]" /> Restricted
                                  </span>
                                )}
                              </div>
                              <code className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mt-1">{ch.number}</code>
                            </div>
                            
                            {/* Checkbox Icon */}
                            <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all ${
                              isSelected ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-300 bg-white group-hover:border-slate-400'
                            }`}>
                              {isSelected && <Check size={14} strokeWidth={3} />}
                            </div>
                          </button>
                        );
                      })
                    ) : (
                      <div className="text-center py-20 bg-white/20 rounded-[3rem] border-2 border-dashed border-white/60 flex flex-col items-center gap-4">
                        <Terminal size={40} className="text-slate-300" />
                        <div className="space-y-2">
                           <p className="text-sm font-black text-slate-900 uppercase tracking-widest">No Active Channels Linked</p>
                           <p className="text-[10px] font-bold text-slate-400 uppercase">Initialize matrix link in Demo Server first</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
 
                <div className="flex flex-col gap-6">
                  <button 
                    onClick={() => {
                      if (selectedServerIds.length === 0) return;
                      const targetServerId = selectedServerIds.length === activeConnectedChannels.length
                        ? 'divide_all'
                        : `divide_selected:${selectedServerIds.join(',')}`;
                      onRun(targetServerId, filterMode);
                    }}
                    disabled={selectedServerIds.length === 0}
                    className="w-full py-6 bg-slate-900 hover:bg-black disabled:bg-slate-200 disabled:cursor-not-allowed text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98] flex items-center justify-center gap-4 group"
                  >
                    <Send size={16} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                    Commence Data Stream
                  </button>
                  
                  <div className="flex items-center gap-4">
                    <button 
                      onClick={() => {
                        if (campaign) {
                          onDirectFinish(campaign.id);
                          onClose();
                        }
                      }}
                      className="flex-1 py-4 glass border-white/60 hover:border-rose-500/40 text-rose-500 font-black text-[9px] uppercase tracking-[0.2em] rounded-2xl transition-all flex items-center justify-center gap-3"
                    >
                      <Power size={14} />
                      Manual Termination
                    </button>
                    <button 
                      onClick={onClose}
                      className="flex-1 py-4 glass border-white/60 hover:bg-white text-slate-400 hover:text-slate-900 font-black text-[9px] uppercase tracking-[0.2em] rounded-2xl transition-all"
                    >
                      Abort Protocol
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};
