import React, { useState, useMemo } from 'react';
import { 
  Info, 
  X, 
  ShieldCheck, 
  Zap, 
  WifiOff, 
  Download, 
  Eye, 
  FileUp, 
  File as FileIcon, 
  ShieldAlert 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Campaign, UploadedFile } from '../types';

interface MediaPreviewModalProps {
  file: UploadedFile;
  onClose: () => void;
}

export const MediaPreviewModal = ({ file, onClose }: MediaPreviewModalProps) => (
  <div className="fixed inset-0 z-[310] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl overflow-hidden flex flex-col"
    >
      <div className="flex items-center justify-between p-4 border-b border-slate-100">
        <h3 className="text-lg font-bold text-slate-800 truncate pr-4">{file.name}</h3>
        <button 
          onClick={onClose}
          className="p-2 hover:bg-slate-100 rounded-full text-slate-400 transition-colors shrink-0"
        >
          <X size={20} />
        </button>
      </div>
      
      <div className="p-4 bg-black flex items-center justify-center min-h-[400px] max-h-[80vh] overflow-hidden">
        {file.type === 'image' ? (
          <img src={file.url} alt={file.name} className="max-w-full max-h-full object-contain" referrerPolicy="no-referrer" />
        ) : file.type === 'video' ? (
          <video src={file.url} controls className="max-w-full max-h-full" autoPlay />
        ) : file.type === 'pdf' ? (
          <iframe 
            src={`${file.url}#toolbar=1&navpanes=1&scrollbar=1`} 
            className="w-full h-[70vh] rounded-xl border-none bg-white"
            title="PDF Preview"
          />
        ) : (
          <div className="bg-white p-12 rounded-2xl flex flex-col items-center gap-4">
            <FileIcon size={64} className="text-slate-300" />
            <p className="text-slate-500 font-medium">{file.name}</p>
            <a 
              href={file.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-6 py-2 bg-[#00796B] text-white rounded-xl font-bold hover:bg-[#00695C] transition-all"
            >
              Open PDF
            </a>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-slate-100 flex justify-end">
        <button 
          onClick={onClose}
          className="px-6 py-2 text-sm font-bold text-[#00796B] hover:bg-green-50 rounded-xl transition-all"
        >
          Close
        </button>
      </div>
    </motion.div>
  </div>
);

interface CampaignDetailsModalProps {
  campaign: Campaign; 
  mockDb: string[];
  nonWaDb: string[];
  allCampaigns: Campaign[];
  onClose: () => void;
  onEdit?: (campaign: Campaign) => void;
  isAdmin?: boolean;
  isSystemAdmin?: boolean;
  onCSVDownload?: (campaign: Campaign) => void;
  onWhitelistingDownload?: (campaign: Campaign) => void;
  onWhitelistingCommonDownload?: (campaign: Campaign) => void;
}

export const CampaignDetailsModal = ({ 
  campaign, 
  mockDb,
  nonWaDb,
  allCampaigns,
  onClose, 
  isAdmin,
  isSystemAdmin,
  onCSVDownload,
  onWhitelistingCommonDownload
}: CampaignDetailsModalProps) => {
  const [previewFile, setPreviewFile] = useState<UploadedFile | null>(null);

  const { whitelistedCount, commonCount, nonWaCount } = useMemo(() => {
    if (!campaign.numbers) return { whitelistedCount: 0, commonCount: 0, whitelistedAndCommonCount: 0, nonWaCount: 0 };
    
    const whitelistSet = new Set(mockDb.map(n => n.replace(/\D/g, '').slice(-10)));
    const nonWaSet = new Set(nonWaDb.map(n => n.replace(/\D/g, '').slice(-10)));
    
    const otherCampaignsNumbers = (allCampaigns || [])
      .filter(c => c.id !== campaign.id)
      .flatMap(c => c.numbers || []);
    const otherSet = new Set(otherCampaignsNumbers.map(n => n.replace(/\D/g, '').slice(-10)));
    
    let wCount = 0;
    let cCount = 0;
    let wcCount = 0;
    let nwCount = 0;

    campaign.numbers.forEach(n => {
      const cleanNum = n.replace(/\D/g, '').slice(-10);
      if (cleanNum.length >= 10) {
        const isWhitelisted = whitelistSet.has(cleanNum);
        const isCommon = otherSet.has(cleanNum);
        const isNonWa = nonWaSet.has(cleanNum);
        
        if (isWhitelisted) wCount++;
        if (isCommon) cCount++;
        if (isWhitelisted || isCommon) wcCount++;
        if (isNonWa) nwCount++;
      }
    });

    return { 
      whitelistedCount: wCount, 
      commonCount: cCount, 
      whitelistedAndCommonCount: wcCount,
      nonWaCount: nwCount
    };
  }, [campaign.numbers, mockDb, nonWaDb, allCampaigns, campaign.id]);

  const handleDownload = (file: UploadedFile) => {
    if (!file.url) return;
    const link = document.createElement('a');
    link.href = file.url;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 30 }}
        className="glass rounded-[3rem] shadow-2xl w-full max-w-3xl overflow-hidden border border-white/40 flex flex-col"
      >
        <div className="p-10 border-b border-white/20 bg-white/40 shadow-sm flex justify-between items-center">
          <div className="space-y-1">
             <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-4">
               <Info size={24} className="text-blue-500" />
               Operation Manifest
               {isSystemAdmin && campaign.status === 'Pending' && campaign.isScanned ? (
                 <motion.span 
                   initial={{ opacity: 0, scale: 0.8 }}
                   animate={{ opacity: 1, scale: 1 }}
                   className="px-3 py-1 bg-emerald-500 text-white rounded-lg text-[10px] font-black uppercase tracking-[0.2em] shadow-lg shadow-emerald-500/20 animate-pulse flex items-center gap-2"
                 >
                   <div className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                   READY TO SEND
                 </motion.span>
               ) : (
                 <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-[0.2em] ${
                   campaign.status === 'Completed' ? 'bg-emerald-500 text-white' :
                   campaign.status === 'Active' ? 'bg-blue-500 text-white' :
                   campaign.status === 'Pending' ? 'bg-amber-500 text-white' :
                   'bg-red-500 text-white'
                 }`}>
                   {campaign.status === 'Completed' ? 'OPTIMIZED' : campaign.status}
                 </span>
               )}
             </h3>
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{campaign.name}</p>
          </div>
          <button onClick={onClose} className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group border border-white/40">
            <X size={24} className="group-hover:rotate-90 transition-transform" />
          </button>
        </div>
        
        <div className="p-10 space-y-10 bg-white/10 max-h-[75vh] overflow-y-auto custom-scrollbar">
          {campaign.status === 'Rejected' && campaign.rejectionReason && (
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-red-500/10 border border-red-500/20 p-8 rounded-[2rem] shadow-inner"
            >
              <div className="flex items-center gap-4 mb-3">
                <div className="w-10 h-10 rounded-xl bg-red-500 text-white flex items-center justify-center shadow-lg shadow-red-500/30">
                  <ShieldAlert size={20} />
                </div>
                <h4 className="text-xs font-black text-red-600 uppercase tracking-[0.3em]">Termination Sequence Data</h4>
              </div>
              <p className="text-sm font-bold text-slate-700 leading-relaxed italic pl-14">
                "{campaign.rejectionReason}"
              </p>
            </motion.div>
          )}

          {/* Metrics Grid */}
          {isAdmin && (
            <div className="grid grid-cols-3 gap-6">
              <div className="p-6 bg-blue-500/10 rounded-[2rem] border border-blue-500/20 shadow-inner flex flex-col items-center gap-2 group hover:bg-blue-500/20 transition-all">
                <ShieldCheck size={20} className="text-blue-500" />
                <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest">Whitelisted</span>
                <span className="text-3xl font-black text-blue-700">{whitelistedCount}</span>
              </div>
              <div className="p-6 bg-emerald-500/10 rounded-[2rem] border border-emerald-500/20 shadow-inner flex flex-col items-center gap-2 group hover:bg-emerald-500/20 transition-all">
                <Zap size={20} className="text-emerald-500" />
                <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Common</span>
                <span className="text-3xl font-black text-emerald-700">{commonCount}</span>
              </div>
              <div className="p-6 bg-rose-500/10 rounded-[2rem] border border-rose-500/20 shadow-inner flex flex-col items-center gap-2 group hover:bg-rose-500/20 transition-all">
                <WifiOff size={20} className="text-rose-500" />
                <span className="text-[10px] font-black text-rose-500 uppercase tracking-widest">Non-WA</span>
                <span className="text-3xl font-black text-rose-700">{nonWaCount}</span>
              </div>
            </div>
          )}

          {/* Action Row */}
          <div className="flex justify-between items-center bg-white/40 p-6 rounded-[2rem] border border-white/60 shadow-sm">
             <div className="space-y-1">
                <p className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em]">Operational Report</p>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Comprehensive data export available</p>
             </div>
             <button 
                onClick={() => onWhitelistingCommonDownload?.(campaign)}
                className="px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-2xl shadow-xl transition-all active:scale-95 flex items-center gap-3"
             >
                <Download size={16} /> Fetch Full Core
             </button>
          </div>

          {/* Media Section */}
          <div className="space-y-6">
            <div className="flex items-center gap-4">
               <h4 className="text-xs font-black text-slate-900 uppercase tracking-[0.3em]">Payload Components</h4>
               <div className="h-px flex-1 bg-slate-200" />
            </div>
            <div className="glass rounded-[2.5rem] border border-white/60 overflow-hidden shadow-inner">
               <table className="w-full">
                <thead className="bg-white/40 border-b border-white/60">
                  <tr>
                    <th className="px-8 py-6 text-left text-[9px] font-black text-slate-400 uppercase tracking-widest">Type</th>
                    <th className="px-8 py-6 text-left text-[9px] font-black text-slate-400 uppercase tracking-widest">Asset Name</th>
                    <th className="px-8 py-6 text-right text-[9px] font-black text-slate-400 uppercase tracking-widest">Ops</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/20 bg-white/10">
                  {campaign.files && campaign.files.length > 0 ? (
                    campaign.files.map((file) => (
                      <tr key={file.id} className="text-slate-600 hover:bg-white/20 transition-colors group">
                        <td className="px-8 py-6">
                           <span className="px-4 py-1.5 bg-white/60 rounded-full text-[9px] font-black text-slate-600 uppercase tracking-wider">{file.type}</span>
                        </td>
                        <td className="px-8 py-6">
                           <p className="text-xs font-bold text-slate-900 max-w-[200px] truncate">{file.name}</p>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex justify-end gap-3 opacity-60 group-hover:opacity-100 transition-opacity">
                            <button 
                              onClick={() => file.url && setPreviewFile(file)}
                              className="w-10 h-10 bg-white/60 hover:bg-indigo-600 hover:text-white rounded-xl flex items-center justify-center transition-all shadow-sm border border-white/40"
                            >
                              <Eye size={16} />
                            </button>
                            <button 
                              onClick={() => handleDownload(file)}
                              className="w-10 h-10 bg-white/60 hover:bg-emerald-600 hover:text-white rounded-xl flex items-center justify-center transition-all shadow-sm border border-white/40"
                            >
                              <Download size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="px-8 py-12 text-center text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Payload Empty</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quick Access */}
          <div className="flex justify-center pt-4">
            <button 
              className="px-10 py-6 bg-white/60 hover:bg-white border border-white/80 rounded-[2rem] text-[10px] font-black text-slate-900 uppercase tracking-[0.3em] flex items-center gap-4 transition-all shadow-xl active:scale-95 group"
            >
              <FileUp size={18} className="text-amber-500 group-hover:scale-110 transition-transform" />
              Download Message Script (.doc)
            </button>
          </div>

          <div className="space-y-10">
            {/* Manifest Grid */}
            <div className="grid grid-cols-2 gap-10">
              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Operation Protocol</label>
                <div className="p-6 bg-white/40 rounded-[2rem] border border-white/60 shadow-inner">
                  <span className="px-4 py-2 bg-slate-900 text-white rounded-full text-[9px] font-black uppercase tracking-widest">
                    {campaign.isDemo ? 'DEMO_ENCRYPTED' : (campaign.type === 'Button' ? 'BUTTON_HANDSHAKE' : (campaign.type === 'International' ? 'INTERNATIONAL_HANDSHAKE' : 'DOMESTIC_HANDSHAKE'))}
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Session Alias</label>
                <div className="p-6 bg-white/40 rounded-[2rem] border border-white/60 shadow-inner text-sm font-black text-slate-900 uppercase tracking-tight">
                  {campaign.name}
                </div>
              </div>
            </div>

            {/* Content Field */}
            <div className="space-y-4">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">Message Payload</label>
              <div className="bg-white/40 rounded-[2.5rem] p-10 text-[11px] font-bold text-slate-600 border border-white/60 whitespace-pre-wrap leading-relaxed shadow-inner min-h-[150px]">
                {campaign.message || "PROTOCOL_NULL: No string data detected."}
              </div>
            </div>

            {/* Endpoint Summary */}
            <div className="space-y-4">
              <div className="flex items-center justify-between px-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Endpoint Census</label>
                <div className="flex items-center gap-4">
                   <div className="px-4 py-1.5 bg-slate-900 text-white rounded-full text-[9px] font-black uppercase tracking-widest">
                      Total: {campaign.totalCount || 0}
                   </div>
                   <button onClick={() => onCSVDownload?.(campaign)} className="w-8 h-8 bg-white/60 rounded-lg flex items-center justify-center text-slate-400 hover:text-indigo-600 transition-colors shadow-sm">
                      <Download size={14} />
                   </button>
                </div>
              </div>
            </div>

            {/* Interactive Section */}
            {campaign.type === 'Button' && campaign.buttonDetails && (
              <div className="space-y-6 pt-6 border-t border-white/20">
                <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-[0.3em]">Haptic Feedback</h4>
                <div className="grid grid-cols-2 gap-6">
                  {campaign.buttonDetails.linkText && (
                    <div className="bg-indigo-50/50 border border-indigo-100/50 rounded-[2rem] p-8 space-y-3 shadow-inner">
                      <p className="text-[9px] font-black text-indigo-400 uppercase tracking-widest">Uplink</p>
                      <p className="text-sm font-black text-indigo-900 uppercase tracking-tight truncate">{campaign.buttonDetails.linkText}</p>
                      <p className="text-[10px] font-bold text-indigo-500/60 truncate">{campaign.buttonDetails.linkUrl}</p>
                    </div>
                  )}
                  {campaign.buttonDetails.callText && (
                    <div className="bg-emerald-50/50 border border-emerald-100/50 rounded-[2rem] p-8 space-y-3 shadow-inner">
                      <p className="text-[9px] font-black text-emerald-400 uppercase tracking-widest">Voice Terminal</p>
                      <p className="text-sm font-black text-emerald-900 uppercase tracking-tight truncate">{campaign.buttonDetails.callText}</p>
                      <p className="text-[10px] font-bold text-emerald-500/60 truncate">{campaign.buttonDetails.callNumber}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-10 border-t border-white/20 bg-white/40 flex justify-between items-center">
          <div className="flex items-center gap-3">
             <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
             <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">System Standby</span>
          </div>
          <button 
            onClick={onClose}
            className="px-10 py-4 bg-slate-900 hover:bg-black text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-2xl shadow-xl transition-all active:scale-[0.98]"
          >
            Terminal Shutdown
          </button>
        </div>

        <AnimatePresence>
          {previewFile && <MediaPreviewModal file={previewFile} onClose={() => setPreviewFile(null)} />}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};
