/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useDeferredValue, useRef } from 'react';
import { 
  LayoutDashboard, 
  History, 
  Clock, 
  PlusCircle, 
  MousePointer2, 
  Users, 
  PhoneOff, 
  ShieldCheck, 
  Settings, 
  MapPin, 
  ShieldAlert, 
  ArrowLeft,
  ArrowLeftRight,
  ArrowUp,
  ArrowDown, 
  RotateCcw,
  FileText,
  LogOut,
  Rocket,
  Menu,
  MessageCircle,
  Server,
  X,
  Plus,
  Search,
  Upload,
  Send,
  Trash2,
  FileUp,
  Image as ImageIcon,
  Video as VideoIcon,
  File as FileIcon,
  Globe,
  ChevronRight,
  MoreVertical,
  User as UserIcon,
  Mail,
  Phone,
  Percent,
  Lock,
  UserPlus,
  RefreshCw,
  ChevronUp,
  ChevronDown,
  CheckCircle,
  Check,
  Eye,
  EyeOff,
  Download,
  Star,
  Pencil,
  Bell,
  XCircle,
  QrCode,
  Code,
  Play,
  Smartphone,
  AlertCircle,
  Clock3,
  CalendarDays,
  CreditCard,
  Sparkles,
  Layers,
  Zap,
  Activity,
  PieChart,
  Fingerprint,
  Target,
  Copy,
  Archive,
  Info,
  Link as LinkIcon,
  WifiOff,
  Power,
  ClipboardList,
  Radio,
  AlertTriangle,
  PencilLine,
  Package,
  KeyRound,
  Hash,
  MoreHorizontal,
  CircleOff,
  Minus,
  Shield,
  Cpu,
  HardDrive,
  Terminal
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { 
  Page, 
  Toast, 
  PrivateSenderMessage, 
  FilterMode, 
  Campaign, 
  UploadedFile, 
  User, 
  Transaction, 
  NumberSearchRecord, 
  AdminStaff, 
  Channel 
} from './types';
import { RunCampaignModal } from './components/RunCampaignModal';
import { CampaignDetailsModal, MediaPreviewModal } from './components/CampaignDetailsModal';
import { CampaignTable } from './components/CampaignTable';

// --- Global Constants ---
const PRIVATE_SENDER_API_BASE = (import.meta as any).env?.VITE_PRIVATE_SENDER_API_URL || '/api/private-sender';

const countries = [
  { name: 'India', flag: '🇮🇳', prefix: '+91' },
  { name: 'Indonesia', flag: '🇮🇩', prefix: '+62' },
  { name: 'UAE', flag: '🇦🇪', prefix: '+971' },
];

const safeLocalStorage = {
  internalStore: {} as Record<string, string>,
  getItem(key: string): string | null {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      console.warn('localStorage.getItem is restricted/unavailable, using memory fallback.', e);
      return this.internalStore[key] || null;
    }
  },
  setItem(key: string, value: string): void {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.warn('localStorage.setItem is restricted/unavailable, using memory fallback.', e);
      this.internalStore[key] = value;
    }
  },
  removeItem(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.warn('localStorage.removeItem is restricted/unavailable, using memory fallback.', e);
      delete this.internalStore[key];
    }
  }
};

// --- Types imported from types.ts ---


const ADMIN_MODULES = [
  'Admin Staff', 'Users', 'Campaign', 'Campaign Config', 'City', 'State',
  'Credit Details', 'Pending Campaign', 'Finished Campaign', 'Credit Transactions',
  'White Listing', 'Non-Whatsapp No.', 'Scheduled Campaign', 'White Listing DB',
  'Campaign Button', 'Campaign Numbers', 'Countries', 'Int Credit Details',
  'Button Credit Details', 'Int Credit Transactions', 'Button Credit Transactions',
  'API Campaign', 'Manage Credits', 'Demo Server'
];

// --- Components ---

const LoginPage = ({ users, onLogin }: { users: User[], onLogin: (user: User) => void }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedUsername = username.trim();
    const user = users.find(u => u.username === trimmedUsername && u.password === password);
    if (user) {
      if (user.status !== 'Active') {
        setError(`Account is ${user.status} ❌`);
        return;
      }
      onLogin(user);
    } else {
      setError('Invalid credentials ❌');
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#020617] items-center justify-center relative overflow-hidden">
      {/* Dynamic Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/20 rounded-full blur-[120px]" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-teal-500/20 rounded-full blur-[120px]" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 w-full max-w-md p-1"
      >
        <div className="bg-slate-900/40 backdrop-blur-2xl border border-white/10 rounded-[2.5rem] p-10 shadow-2xl flex flex-col items-center">
          <motion.div 
            whileHover={{ rotate: 15 }}
            className="w-20 h-20 bg-gradient-to-tr from-emerald-500 to-teal-400 rounded-3xl flex items-center justify-center shadow-lg shadow-emerald-500/20 mb-8"
          >
            <Rocket className="text-white w-10 h-10" />
          </motion.div>
          
          <h1 className="text-4xl font-black text-white mb-2 tracking-tight">WhatsAppWide</h1>
          <p className="text-slate-400 text-center mb-10 font-medium max-w-sm">Simplifying your business reach with high-impact WhatsApp campaigns</p>
          
          <form onSubmit={handleSubmit} className="w-full space-y-5">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Login Identity</label>
              <div className="relative group">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 transition-colors group-focus-within:text-emerald-400">
                  <UserIcon size={18} />
                </div>
                <input 
                  type="text" 
                  placeholder="Username" 
                  value={username || ''}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-slate-800/40 border border-white/5 rounded-2xl pl-12 pr-4 py-4 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 transition-all font-medium"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Secure Key</label>
              <div className="relative group">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 transition-colors group-focus-within:text-emerald-400">
                  <Lock size={18} />
                </div>
                <input 
                  type="password" 
                  placeholder="Password" 
                  value={password || ''}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-800/40 border border-white/5 rounded-2xl pl-12 pr-4 py-4 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 transition-all font-medium"
                />
              </div>
            </div>
            
            {error && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-3 rounded-2xl text-sm font-bold text-center"
              >
                {error}
              </motion.div>
            )}
            
            <button 
              type="submit"
              className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-bold py-4 rounded-2xl shadow-xl shadow-emerald-500/20 transition-all active:scale-[0.97] mt-4 flex items-center justify-center gap-2"
            >
              Login
              <ChevronRight size={20} />
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

const RunningNotification = ({ message }: { message: string }) => {
  return (
    <div className="bg-white border-y border-slate-100 py-2 overflow-hidden whitespace-nowrap relative z-10 shadow-sm">
      <motion.div
        animate={{ x: ['100%', '-100%'] }}
        transition={{ 
          repeat: Infinity, 
          duration: 25, 
          ease: "linear" 
        }}
        className="inline-block text-[#00796B] font-bold text-sm px-4"
      >
        {message}
      </motion.div>
    </div>
  );
};

const SidebarItem = React.memo(({ 
  icon: Icon, 
  label, 
  active, 
  onClick,
  isOpen
}: { 
  icon: any, 
  label: Page, 
  active: boolean, 
  onClick: () => void,
  isOpen: boolean
}) => (
  <motion.li 
    whileHover={{ x: isOpen ? 4 : 0 }}
    className={`py-1 list-none transition-all duration-500 ${isOpen ? 'px-4' : 'px-2'}`}
  >
    <button 
      onClick={onClick}
      className={`w-full flex items-center rounded-2xl transition-all relative group cursor-pointer ${
        isOpen ? 'gap-4 px-5 py-4 justify-start' : 'p-4 justify-center'
      } ${
        active 
          ? 'bg-emerald-500 text-white shadow-[0_10px_30px_-5px_rgba(16,185,129,0.3)] scale-[1.02]' 
          : 'text-slate-400 hover:text-white hover:bg-white/5'
      }`}
    >
      <Icon size={20} className={`flex-shrink-0 transition-all duration-300 ${active ? 'scale-110' : 'group-hover:scale-110'}`} />
      <span className={`text-[11px] font-black uppercase tracking-widest whitespace-nowrap transition-all duration-500 overflow-hidden ${isOpen ? 'max-w-xs opacity-100' : 'max-w-0 opacity-0 w-0'}`}>
        {label}
      </span>
      {active && (
        <motion.div 
          layoutId="sidebar-accent"
          className="absolute -right-1 top-1/2 -translate-y-1/2 w-1.5 h-8 bg-emerald-400 rounded-l-full shadow-[0_0_15px_rgba(52,211,153,0.5)]"
        />
      )}
    </button>
  </motion.li>
));

const ToastContainer = ({ toasts, removeToast }: { toasts: Toast[], removeToast: (id: string) => void }) => {
  return (
    <div className="fixed top-8 right-8 z-[1000] flex flex-col gap-4 pointer-events-none w-full max-w-[380px]">
      <AnimatePresence mode="popLayout">
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            layout
            initial={{ opacity: 0, x: 100, scale: 0.9, filter: 'blur(10px)' }}
            animate={{ opacity: 1, x: 0, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, scale: 0.8, x: 50, filter: 'blur(10px)', transition: { duration: 0.2 } }}
            className="pointer-events-auto relative group"
          >
            {/* Status Glow Aura */}
            <div className={`absolute -inset-1 blur-xl opacity-20 transition-opacity group-hover:opacity-40 ${
              toast.type === 'success' ? 'bg-emerald-500' :
              toast.type === 'error' ? 'bg-rose-500' :
              toast.type === 'warning' ? 'bg-amber-500' :
              'bg-indigo-500'
            }`} />
            
            <div className="relative overflow-hidden bg-slate-950/90 border border-white/10 backdrop-blur-2xl rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex items-stretch">
              {/* Type Indicator Bar */}
              <div className={`w-1.5 shrink-0 ${
                toast.type === 'success' ? 'bg-emerald-500' :
                toast.type === 'error' ? 'bg-rose-500' :
                toast.type === 'warning' ? 'bg-amber-500' :
                'bg-indigo-500'
              }`} />

              <div className="flex-1 flex items-center gap-4 py-4 px-5">
                <div className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center shadow-inner ${
                  toast.type === 'success' ? 'bg-emerald-500/10 text-emerald-400' :
                  toast.type === 'error' ? 'bg-rose-500/10 text-rose-400' :
                  toast.type === 'warning' ? 'bg-amber-500/10 text-amber-400' :
                  'bg-indigo-500/10 text-indigo-400'
                }`}>
                  {toast.type === 'success' && <CheckCircle size={22} strokeWidth={2.5} />}
                  {toast.type === 'error' && <XCircle size={22} strokeWidth={2.5} />}
                  {toast.type === 'warning' && <AlertCircle size={22} strokeWidth={2.5} />}
                  {toast.type === 'info' && <Bell size={22} strokeWidth={2.5} />}
                </div>

                <div className="flex-1 min-w-0 pr-4">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className={`text-[9px] font-black uppercase tracking-[0.2em] ${
                      toast.type === 'success' ? 'text-emerald-500' :
                      toast.type === 'error' ? 'text-rose-500' :
                      toast.type === 'warning' ? 'text-amber-500' :
                      'text-indigo-500'
                    }`}>
                      {toast.type || 'SYSTEM'} NOTIFICATION
                    </span>
                    <div className="h-px flex-1 bg-white/5" />
                  </div>
                  <p className="text-[13px] font-bold text-white leading-snug tracking-tight">
                    {toast.message}
                  </p>
                </div>

                <button 
                  onClick={() => removeToast(toast.id)}
                  className="shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-slate-500 hover:text-white hover:bg-white/5 transition-all"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Progress Scanline */}
              <motion.div 
                initial={{ scaleX: 1 }}
                animate={{ scaleX: 0 }}
                transition={{ duration: 4, ease: "linear" }}
                className={`absolute bottom-0 left-0 right-0 h-[3px] origin-left ${
                  toast.type === 'success' ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' :
                  toast.type === 'error' ? 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.5)]' :
                  toast.type === 'warning' ? 'bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)]' :
                  'bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]'
                }`}
              />
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};

const ReportModal = ({ campaign, onClose, isAdmin, onUpdateCampaign, whitelistNumbers, showToast, channels = [] }: { 
  campaign: Campaign, 
  onClose: () => void, 
  isAdmin?: boolean,
  onUpdateCampaign?: (campaign: Campaign) => void,
  whitelistNumbers?: string[],
  showToast: (message: string, type?: Toast['type']) => void,
  channels?: Channel[]
}) => {
  const [activeTab, setActiveTab] = useState('User Report');
  const [showOverride, setShowOverride] = useState(false);
  const [overridePercent, setOverridePercent] = useState<string>('0');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleManualCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onUpdateCampaign) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const csvStr = event.target?.result as string;
      const lines = csvStr.split('\n');
      const updatedReportData = [...reportData];
      
      lines.forEach(line => {
        const parts = line.split(',').map(p => p.trim());
        if (parts.length >= 2) {
          const number = parts[0].replace(/\D/g, '').slice(-10);
          const status = parts[1];
          const idx = updatedReportData.findIndex(d => d.number.replace(/\D/g, '').slice(-10) === number);
          if (idx !== -1) {
            updatedReportData[idx] = { ...updatedReportData[idx], status, isOverridden: true };
          }
        }
      });

      onUpdateCampaign({
        ...campaign,
        reportData: updatedReportData,
        sentCount: updatedReportData.filter(d => d.status === 'sent').length
      });
      showToast('Manual report updated from CSV', 'success');
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    reader.readAsText(file);
  };

  const applyOverride = (mode: 'increase' | 'decrease') => {
    if (!onUpdateCampaign) return;
    const percentNum = Number(overridePercent) || 0;

    const whitelistSet = new Set((whitelistNumbers || []).map(n => n.replace(/\D/g, '').slice(-10)));
    
    // We use current reportData as base
    const baseData = [...reportData];
    
    // Identify valid numbers for override (not Invalid, not Duplicate)
    const availableIndices: number[] = [];
    const currentNonWAIndices: number[] = [];
    const currentSentIndices: number[] = [];

    baseData.forEach((d, idx) => {
      const clean = d.number.replace(/\D/g, '').slice(-10);
      const isWhitelisted = whitelistSet.has(clean);
      const isSpecial = d.status === 'Invalid' || d.status === 'Duplicate';
      const statusLower = d.status.toLowerCase();
      
      if (!isWhitelisted && !isSpecial) {
        availableIndices.push(idx);
        if (statusLower === 'non-whatsapp' || statusLower === 'non-wa') {
          currentNonWAIndices.push(idx);
        } else if (statusLower === 'sent' || statusLower === 'delivered' || statusLower === 'success') {
          currentSentIndices.push(idx);
        }
      }
    });

    const poolSize = availableIndices.length;
    let delta = Math.round((percentNum / 100) * poolSize);
    if (percentNum > 0 && delta === 0 && poolSize > 0) {
      delta = 1;
    }
    
    if (mode === 'increase') {
      // Increase Non-WhatsApp: Pick from current 'sent' and make them 'Non-WhatsApp'
      const shuffledSent = [...currentSentIndices].sort(() => 0.5 - Math.random());
      const toChange = shuffledSent.slice(0, delta);
      
      const updatedReportData = baseData.map((d, idx) => {
        if (toChange.includes(idx)) {
          return { ...d, status: 'Non-WhatsApp', isOverridden: true };
        }
        return d;
      });

      onUpdateCampaign({ ...campaign, reportData: updatedReportData, sentCount: updatedReportData.filter(d => d.status.toLowerCase() === 'sent' || d.status.toLowerCase() === 'delivered' || d.status.toLowerCase() === 'success').length });
      showToast(`Increased Non-WhatsApp by ${percentNum}%`, 'success');
    } else {
      // Decrease Non-WhatsApp: Pick from current 'Non-WhatsApp' and make them 'sent'
      const shuffledNonWA = [...currentNonWAIndices].sort(() => 0.5 - Math.random());
      const toChange = shuffledNonWA.slice(0, delta);
      
      const updatedReportData = baseData.map((d, idx) => {
        if (toChange.includes(idx)) {
          return { ...d, status: 'sent', isOverridden: true };
        }
        return d;
      });

      onUpdateCampaign({ ...campaign, reportData: updatedReportData, sentCount: updatedReportData.filter(d => d.status.toLowerCase() === 'sent' || d.status.toLowerCase() === 'delivered' || d.status.toLowerCase() === 'success').length });
      showToast(`Decreased Non-WhatsApp by ${percentNum}%`, 'success');
    }

    setShowOverride(false);
  };

  const resetReport = () => {
    if (!onUpdateCampaign) return;
    
    // Reset reportData to essentially "undo" overrides.
    // We can clear reportData entirely or just filter out overridden ones if we were confident which was which.
    // Clearing it forces a recalculation from campaign.originalNumbers/campaign.numbers in the useMemo.
    onUpdateCampaign({
      ...campaign,
      reportData: [],
      sentCount: campaign.totalCount // Assume original sent state
    });
    
    showToast('Report reset to original state', 'info');
    setShowOverride(false);
  };
  
  const reportData = useMemo<{ number: string, status: string, isOverridden?: boolean, senderName?: string, senderNumber?: string }[]>(() => {
    // If we have original numbers, we should build the report from them to ensure "all numbers" are present
    if (campaign.originalNumbers && campaign.originalNumbers.length > 0) {
      const processedReportMap = new Map<string, { status: string, isOverridden?: boolean, senderName?: string, senderNumber?: string }>();
      if (campaign.reportData) {
        campaign.reportData.forEach(d => {
          // Store status by number. Note: if multiple with same number are processed (unlikely), last one wins
          processedReportMap.set(d.number.replace(/\D/g, '').slice(-10), { status: d.status, isOverridden: d.isOverridden, senderName: d.senderName, senderNumber: d.senderNumber });
        });
      }

      const seen = new Set();
      return campaign.originalNumbers.map(rawNum => {
        const digits = rawNum.replace(/\D/g, '');
        const cleanNum = digits.slice(-10);
        
        // Check Validity (simplified version of handleSendCampaign logic)
        const isAllSame = digits.length >= 10 && digits.split('').every(d => d === digits[0]);
        const isValid = digits.length >= 10 && digits.length <= 15 && !isAllSame;
        
        if (!isValid) return { number: rawNum, status: 'Invalid' };
        if (seen.has(cleanNum)) return { number: rawNum, status: 'Duplicate' };
        
        seen.add(cleanNum);
        
        // If it was processed, get its status (sent, Skipped, Non-WhatsApp, etc)
        const processed = processedReportMap.get(cleanNum);
        let finalStatus = processed?.status || (campaign.status === 'Completed' ? 'sent' : 'pending');

        // Check if the sender used for this record is currently restricted in channels
        const senderNum = processed?.senderNumber;
        if (senderNum) {
          const matchingChannel = (channels || []).find((ch: any) => ch.number === senderNum || ch.number === senderNum.replace(/\D/g, ''));
          if (matchingChannel?.isRestricted) {
            finalStatus = 'Restricted';
          }
        } else if (campaign.assignedServerId) {
          const matchingChannel = (channels || []).find((ch: any) => ch.id === campaign.assignedServerId);
          if (matchingChannel?.isRestricted) {
            finalStatus = 'Restricted';
          }
        }
        
        return { 
          number: rawNum, 
          status: finalStatus,
          isOverridden: processed?.isOverridden,
          senderName: processed?.senderName,
          senderNumber: processed?.senderNumber
        };
      });
    }

    if (campaign.reportData && campaign.reportData.length > 0) {
      return campaign.reportData.map(d => {
        let finalStatus = d.status;
        const senderNum = d.senderNumber;
        if (senderNum) {
          const matchingChannel = (channels || []).find((ch: any) => ch.number === senderNum || ch.number === senderNum.replace(/\D/g, ''));
          if (matchingChannel?.isRestricted) {
            finalStatus = 'Restricted';
          }
        } else if (campaign.assignedServerId) {
          const matchingChannel = (channels || []).find((ch: any) => ch.id === campaign.assignedServerId);
          if (matchingChannel?.isRestricted) {
            finalStatus = 'Restricted';
          }
        }
        return { ...d, status: finalStatus };
      });
    }
    if (campaign.numbers && campaign.numbers.length > 0) {
      return campaign.numbers.map(num => ({
        number: num,
        status: campaign.status === 'Completed' ? 'sent' : 'pending'
      }));
    }
    const fallbackNumbers = [
      '7002740347', '7099445486', '7002119664', '8731888190', '9436540978',
      '8787842190', '9862796215', '9366947125', '9862781860', '9366028380'
    ];
    return fallbackNumbers.map(num => ({ number: num, status: 'pending' }));
  }, [campaign, channels]);

  const adminReportData = useMemo(() => {
    return reportData.map(d => ({
      number: d.number,
      status: d.status === 'Skipped' ? 'Skipped' : (d.status === 'Restricted' ? 'Restricted' : ((campaign.assignedServerId || campaign.isDemo) ? (d.status === 'sent' ? 'Delivered' : 'Failed') : 'Failed')),
      senderName: d.senderName,
      senderNumber: d.senderNumber
    }));
  }, [reportData, campaign.assignedServerId, campaign.isDemo]);

  const currentViewData = useMemo(() => {
    return activeTab === 'User Report' ? reportData : adminReportData;
  }, [activeTab, reportData, adminReportData]);

const nonWhatsappCount = reportData.filter(d => d.status === 'Non-WhatsApp').length;
  const skippedCount = reportData.filter(d => d.status === 'Skipped').length;
  const successCount = reportData.filter(d => d.status === 'sent').length;
  const restrictedCount = reportData.filter(d => d.status === 'Restricted').length;

  const downloadCSV = () => {
    const dataToDownload = activeTab === 'User Report' ? reportData : adminReportData;
    const csvContent = [['Number', 'Status'], ...dataToDownload.map(d => [d.number, d.status])].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    link.setAttribute("href", URL.createObjectURL(blob));
    link.setAttribute("download", `${activeTab.replace(/\s+/g, '_')}_${campaign.name.replace(/\s+/g, '_')}.csv`);
    link.click();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[300] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="glass rounded-[3rem] shadow-2xl w-full max-w-5xl overflow-hidden flex flex-col max-h-[90vh] border border-white/40"
      >
        <div className="p-10 border-b border-white/20 flex justify-between items-center bg-white/40 shadow-sm">
          <div className="space-y-1">
            <h3 className="text-xl font-bold text-slate-900 uppercase tracking-tight flex items-center gap-3">
              <PieChart size={24} className="text-indigo-600" />
              Campaign Delivery Report
            </h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">{campaign.name} | Professional Statistics Overview</p>
          </div>
          <button onClick={onClose} className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group border border-white/40">
            <X size={24} className="group-hover:rotate-90 transition-transform" />
          </button>
        </div>
        
        <div className="px-10 pt-8 bg-white/10">
          <div className="flex gap-4 p-2 bg-white/40 rounded-[2rem] border border-white/60 w-fit shadow-inner">
            <button 
              className={`px-10 py-4 text-[10px] font-bold uppercase tracking-[0.2em] transition-all rounded-[1.5rem] ${activeTab === 'User Report' ? 'bg-slate-900 text-white shadow-xl scale-[1.05]' : 'text-slate-400 hover:bg-white/40'}`}
              onClick={() => setActiveTab('User Report')}
            >
              User Report
            </button>
            {isAdmin && (
              <button 
                className={`px-10 py-4 text-[10px] font-bold uppercase tracking-[0.2em] transition-all rounded-[1.5rem] ${activeTab === 'Admin Report' ? 'bg-slate-900 text-white shadow-xl scale-[1.05]' : 'text-slate-400 hover:bg-white/40'}`}
                onClick={() => setActiveTab('Admin Report')}
              >
                System Logs (Admin)
              </button>
            )}
          </div>
        </div>

        <div className="p-10 flex-1 overflow-y-auto custom-scrollbar bg-white/10 space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
             {[
               { label: 'Total Messages', val: reportData.length, icon: Radio, color: 'text-indigo-600' },
               { label: 'Success (Delivered)', val: successCount, icon: CheckCircle, color: 'text-emerald-500' },
               { label: 'Non-WhatsApp', val: nonWhatsappCount, icon: ShieldAlert, color: 'text-amber-500' },
               { label: 'Restricted (463)', val: restrictedCount, icon: ShieldAlert, color: 'text-rose-500' },
               { label: 'Skipped/Manual', val: skippedCount, icon: EyeOff, color: 'text-slate-400' },
             ].map((stat, i) => (
               <div key={i} className="glass p-6 rounded-3xl border border-white/40 flex flex-col gap-4 shadow-lg group hover:scale-[1.02] transition-all">
                  <div className={`p-3 w-fit rounded-2xl bg-white/40 border border-white/60 shadow-sm ${stat.color}`}>
                     <stat.icon size={20} />
                  </div>
                  <div>
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{stat.label}</p>
                    <p className="text-2xl font-bold text-slate-900 tracking-tighter">{stat.val}</p>
                  </div>
               </div>
             ))}
          </div>

          <div className="space-y-6">
            <div className="flex flex-wrap justify-end items-center gap-4 px-2">
              <h4 className="text-[10px] font-bold text-slate-900 uppercase tracking-[0.3em] mr-auto">
                Live Delivery Stream
              </h4>

              {isAdmin && (
                <div className="flex items-center gap-4 bg-white/40 p-2 rounded-2xl border border-white/60 shadow-inner">
                  {showOverride ? (
                    <div className="flex items-center gap-3 px-3">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest whitespace-nowrap">Non-WA %</label>
                       <input 
                        type="number" 
                        min="0" 
                        max="100"
                        value={overridePercent || ''}
                        onChange={(e) => setOverridePercent(e.target.value)}
                        className="w-20 bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                       />
                       <button 
                        onClick={() => applyOverride('increase')}
                        className="px-4 py-2 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-indigo-700 transition-colors shadow-lg active:scale-95 flex items-center gap-2"
                       >
                        <ArrowUp size={12} />
                        Increase
                       </button>
                       <button 
                        onClick={() => applyOverride('decrease')}
                        className="px-4 py-2 bg-rose-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-rose-700 transition-colors shadow-lg active:scale-95 flex items-center gap-2"
                       >
                        <ArrowDown size={12} />
                        Decrease
                       </button>
                       <button 
                        onClick={resetReport}
                        className="px-4 py-2 bg-slate-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-slate-700 transition-colors shadow-lg active:scale-95 flex items-center gap-2"
                       >
                        <RotateCcw size={12} />
                        Reset
                       </button>
                       <button 
                        onClick={() => setShowOverride(false)}
                        className="px-4 py-2 bg-slate-200 text-slate-600 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-slate-300 transition-colors active:scale-95"
                       >
                        Cancel
                       </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => setShowOverride(true)}
                        className="px-6 py-4 bg-amber-500 hover:bg-amber-600 text-white text-[10px] font-bold uppercase tracking-widest rounded-[1.5rem] shadow-xl shadow-amber-500/20 transition-all active:scale-[0.98] flex items-center gap-3"
                      >
                        <Percent size={14} />
                        Change Report
                      </button>
                      <input 
                        type="file" 
                        ref={fileInputRef}
                        onChange={handleManualCSVUpload}
                        accept=".csv"
                        className="hidden"
                      />
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="px-6 py-4 bg-indigo-500 hover:bg-indigo-600 text-white text-[10px] font-bold uppercase tracking-widest rounded-[1.5rem] shadow-xl shadow-indigo-500/20 transition-all active:scale-[0.98] flex items-center gap-3"
                      >
                        <Upload size={14} />
                        Manual Update
                      </button>
                    </div>
                  )}
                </div>
              )}

              <button 
                onClick={downloadCSV}
                className="px-8 py-4 bg-emerald-500 hover:bg-emerald-600 text-white text-[10px] font-bold uppercase tracking-widest rounded-2xl shadow-xl shadow-emerald-500/20 transition-all active:scale-[0.98] flex items-center gap-3"
              >
                <Download size={14} />
                Export CSV
              </button>
            </div>

            <div className="glass rounded-[2rem] border border-white/40 overflow-hidden shadow-2xl bg-white/40">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-white/60 border-b border-white/20">
                    <th className="py-6 px-10 text-[9px] font-bold text-slate-400 uppercase tracking-widest">Recipient Number</th>
                    <th className="py-6 px-10 text-[9px] font-bold text-slate-400 uppercase tracking-widest text-right">Delivery Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10">
                  {currentViewData.map((data, idx) => (
                    <tr key={idx} className="hover:bg-white/60 transition-all group">
                      <td className="py-5 px-10 text-sm font-semibold text-slate-900 tracking-tight">
                        <span className="block">{data.number}</span>
                        {data.senderName && (
                          <span className="inline-flex mt-1 items-center gap-1 text-[8px] font-black text-indigo-600 bg-indigo-50 border border-indigo-100 rounded px-1.5 py-0.5 uppercase tracking-wider">
                            VIA: {data.senderName} ({data.senderNumber})
                          </span>
                        )}
                      </td>
                      <td className="py-5 px-10 text-right">
                        <span className={`px-4 py-2 rounded-xl text-[9px] uppercase font-bold tracking-widest shadow-sm border ${
                          data.status.toLowerCase() === 'sent' || data.status.toLowerCase() === 'delivered'
                            ? 'bg-emerald-500/20 text-emerald-700 border-emerald-500/30'
                            : data.status.toLowerCase() === 'skipped'
                              ? 'bg-slate-500/20 text-slate-700 border-slate-500/30'
                              : (data.status.toLowerCase() === 'failed' || data.status.toLowerCase() === 'non-whatsapp' || data.status.toLowerCase() === 'invalid')
                                ? 'bg-rose-500/20 text-rose-700 border-rose-500/30'
                                : data.status.toLowerCase() === 'duplicate'
                                  ? 'bg-amber-500/20 text-amber-700 border-amber-500/30'
                                  : 'bg-slate-200/50 text-slate-600 border-slate-300'
                        }`}>
                          {data.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};


const EditMessageModal = ({ campaign, onClose, onSave }: { campaign: Campaign, onClose: () => void, onSave: (id: string, message: string, files: UploadedFile[]) => void }) => {
  const [message, setMessage] = useState(campaign.message || '');
  const [files, setFiles] = useState<UploadedFile[]>(campaign.files || []);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const type = file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'pdf';
        const base64Url = await fileToBase64(file);
        const newFile: UploadedFile = {
          id: Math.random().toString(36).substr(2, 9),
          name: file.name,
          type: type as any,
          url: base64Url
        };
        setFiles(prev => {
          if (prev.length < 4) {
            return [...prev, newFile];
          }
          return prev;
        });
        e.target.value = '';
      } catch (err) {
        console.error('Failed to convert file to base64:', err);
      }
    }
  };

  const removeFile = (id: string) => {
    setFiles(files.filter(f => f.id !== id));
  };

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="glass rounded-[3rem] shadow-2xl w-full max-w-xl overflow-hidden border border-white/40 flex flex-col"
      >
        <div className="p-10 border-b border-white/20 bg-white/40 shadow-sm flex justify-between items-center">
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-4">
              <PencilLine size={24} className="text-indigo-600" />
              Override Payload
            </h3>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Modifying mission data | {campaign.id.substring(0, 8)}</p>
          </div>
          <button onClick={onClose} className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group border border-white/40">
            <X size={24} className="group-hover:rotate-90 transition-transform" />
          </button>
        </div>

        <div className="p-10 space-y-10 bg-white/10 max-h-[70vh] overflow-y-auto custom-scrollbar">
          <div className="space-y-3">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Context Reference</label>
            <div className="glass px-8 py-5 rounded-2xl text-slate-900 text-sm border border-white/40 font-black tracking-tight bg-white/40 shadow-inner">
              {campaign.name}
            </div>
          </div>

          <div className="space-y-3 group">
            <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 group-focus-within:text-indigo-600 transition-colors">Campaign Message</label>
            <textarea 
              value={message || ''}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full bg-white/40 border border-white/60 rounded-[2.5rem] px-8 py-8 text-sm font-bold text-slate-800 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all min-h-[220px] resize-none shadow-inner"
              placeholder="Enter your campaign message here..."
            />
          </div>

          <div className="space-y-5">
            <div className="flex justify-between items-center px-1">
              <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Campaign Attachments</label>
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest bg-white/40 px-3 py-1 rounded-full border border-white/60 shadow-sm">{files.length}/4 Files</span>
            </div>
            
            <div className="flex flex-wrap gap-5">
              {files.map((file) => (
                <div key={file.id} className="relative group w-24 h-24 rounded-3xl bg-white/40 border border-white/60 flex items-center justify-center overflow-hidden shadow-lg hover:scale-105 transition-all">
                  {file.type === 'image' ? (
                    <img src={file.url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="flex flex-col items-center gap-2">
                      <Package size={24} className="text-slate-900" />
                      <span className="text-[7px] font-black text-slate-900 uppercase tracking-tighter truncate w-16 text-center px-2">{file.name}</span>
                    </div>
                  )}
                  <button 
                    onClick={() => removeFile(file.id)}
                    className="absolute top-2 right-2 bg-rose-500 text-white rounded-xl p-1.5 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg active:scale-90"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
              {files.length < 4 && (
                <label className="w-24 h-24 rounded-3xl border-2 border-dashed border-white/60 flex flex-col items-center justify-center text-slate-400 hover:border-slate-900 hover:text-slate-900 cursor-pointer transition-all bg-white/20 hover:bg-white/40 shadow-inner group">
                  <Plus size={24} className="group-hover:scale-125 transition-transform" />
                  <span className="text-[8px] font-black uppercase mt-2 tracking-widest">Link</span>
                  <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*,video/*,application/pdf"
                    onChange={handleFileChange}
                  />
                </label>
              )}
            </div>
            <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100/50 flex items-center gap-3">
               <ShieldCheck size={16} className="text-indigo-400" />
               <p className="text-[9px] font-black text-indigo-400 uppercase tracking-[0.15em]">Enhanced encryption active for all binary uploads</p>
            </div>
          </div>
        </div>

        <div className="p-10 bg-white/40 border-t border-white/20 flex flex-col gap-6">
           <button 
            onClick={() => onSave(campaign.id, message, files)}
            className="w-full py-6 bg-slate-900 hover:bg-black text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98] flex items-center justify-center gap-4"
          >
            <Zap size={16} className="text-amber-400" />
            Commit Override Stream
          </button>
          <button 
            onClick={onClose}
            className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] hover:text-slate-900 transition-colors text-center"
          >
            Cancel Changes
          </button>
        </div>
      </motion.div>
    </div>

  );
};

const ProfileSettingsModal = ({ 
  user, 
  onClose, 
  onSave,
  currentUserRole
}: { 
  user: User, 
  onClose: () => void, 
  onSave: (updatedUser: User) => void,
  currentUserRole?: string
}) => {
  const [username, setUsername] = useState(user.username);
  const [password, setPassword] = useState(user.password);
  const [name, setName] = useState(user.name);
  const [role, setRole] = useState(user.role);
  const [planExpiry, setPlanExpiry] = useState(() => {
    if (user.planExpiryDate) {
      return user.planExpiryDate.split('T')[0];
    }
    const d = new Date();
    d.setFullYear(d.getFullYear() + 1);
    return d.toISOString().split('T')[0];
  });
  const [campaignApproved, setCampaignApproved] = useState(user.campaignApproved !== false);
  const [error, setError] = useState('');

  const handleSave = () => {
    if (!username || !password || !name) {
      setError('All fields are required');
      return;
    }
    onSave({ 
      ...user, 
      username, 
      password, 
      name, 
      role,
      planExpiryDate: new Date(planExpiry).toISOString(),
      campaignApproved
    });
  };

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="glass rounded-[3rem] shadow-2xl w-full max-w-md overflow-hidden border border-white/40 flex flex-col max-h-[90vh]"
      >
        <div className="p-10 border-b border-white/20 bg-white/40 shadow-sm flex justify-between items-center flex-shrink-0">
          <div className="flex items-center gap-5">
             <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center font-black text-white border border-white/20 shadow-xl text-xl tracking-tighter">
               {name.charAt(0).toUpperCase()}
             </div>
             <div className="space-y-1">
               <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">User Identity</h3>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Profile Configuration</p>
             </div>
          </div>
          <button onClick={onClose} className="w-10 h-10 bg-white/60 hover:bg-white rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group border border-white/40">
            <X size={20} className="group-hover:rotate-90 transition-transform" />
          </button>
        </div>
        
        <div className="p-10 space-y-8 bg-white/10 overflow-y-auto custom-scrollbar flex-1">
           <div className="space-y-3 group">
            <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 group-focus-within:text-indigo-600 transition-colors">Operational Handle</label>
            <div className="relative">
              <UserIcon className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                value={name || ''}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-white/40 border border-white/60 rounded-[1.5rem] pl-14 pr-6 py-5 text-sm font-bold text-slate-800 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                placeholder="Full Identifier Name"
              />
            </div>
          </div>

          <div className="space-y-3 group">
            <label className="text-[10px] font-bold text-slate-900 uppercase tracking-widest ml-1 group-focus-within:text-indigo-600 transition-colors">Client ID</label>
            <div className="relative">
              <Fingerprint className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                value={username || ''}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-white/40 border border-white/60 rounded-[1.5rem] pl-14 pr-6 py-5 text-sm font-bold text-slate-800 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all font-mono shadow-inner"
                placeholder="Unique Login Channel"
              />
            </div>
          </div>

          <div className="space-y-3 group">
            <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 group-focus-within:text-indigo-600 transition-colors">Authentication Token</label>
            <div className="relative">
              <KeyRound className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="password" 
                value={password || ''}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/40 border border-white/60 rounded-[1.5rem] pl-14 pr-6 py-5 text-sm font-bold text-slate-800 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all font-mono shadow-inner"
                placeholder="Security Passphrase"
              />
            </div>
          </div>

          {currentUserRole === 'Admin' && user.role !== 'Admin' && (
            <div className="space-y-4">
              <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 font-mono">Access Tier</label>
              <div className="flex bg-slate-950/5 p-1 rounded-[1.25rem]">
                {(user.role === 'User' ? (['User'] as const) : (['User', 'Reseller'] as const)).map((r) => (
                  <button
                    key={r}
                    onClick={() => setRole(r)}
                    className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${
                      role === r ? 'bg-white text-slate-900 shadow-lg' : 'text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Admin Managed: Panel Expiration and Campaign Approval */}
          {(currentUserRole === 'Admin' || currentUserRole === 'Reseller') && user.role !== 'Admin' && (
            <div className="space-y-6 border-t border-slate-100 pt-6">
              <h5 className="text-[10px] font-black text-rose-500 uppercase tracking-[0.2em] mb-4">Admin Controls</h5>
              
              <div className="space-y-3 group flex flex-col">
                <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Panel plan expiry date</label>
                <div className="relative">
                  <CalendarDays className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="date" 
                    value={planExpiry || ''}
                    onChange={(e) => setPlanExpiry(e.target.value)}
                    className="w-full bg-white/40 border border-white/60 rounded-[1.5rem] pl-14 pr-6 py-5 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner cursor-pointer"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-slate-950/5 rounded-2xl border border-slate-200">
                <div className="space-y-1 pr-4">
                  <p className="text-xs font-bold text-slate-900 uppercase tracking-tight">Campaign transmission</p>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Allow campaigns & demo campaigns</p>
                </div>
                <button
                  type="button"
                  onClick={() => setCampaignApproved(!campaignApproved)}
                  className={`px-5 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all cursor-pointer ${
                    campaignApproved 
                      ? 'bg-emerald-500 text-white shadow-lg' 
                      : 'bg-rose-500 text-white shadow-lg'
                  }`}
                >
                  {campaignApproved ? 'APPROVED' : 'BLOCKED'}
                </button>
              </div>
            </div>
          )}

          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-rose-500/10 border border-rose-500/20 p-4 rounded-2xl flex items-center gap-3"
            >
              <AlertCircle size={16} className="text-rose-500" />
              <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest">{error}</p>
            </motion.div>
          )}
        </div>

        <div className="p-10 bg-white/40 border-t border-white/20 flex flex-col gap-6 flex-shrink-0">
          <button 
            onClick={handleSave}
            className="w-full py-6 bg-slate-900 hover:bg-black text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98] flex items-center justify-center gap-4 cursor-pointer"
          >
            <ShieldCheck size={16} className="text-emerald-400" />
            Update Security Profile
          </button>
          <button 
            onClick={onClose}
            className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] hover:text-slate-900 transition-colors text-center cursor-pointer"
          >
            Keep Existing Parameters
          </button>
        </div>
      </motion.div>
    </div>
  );
};


const DigitalClock = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <span className="text-xs font-bold text-slate-700">
      {time.toLocaleTimeString('en-US', { 
        timeZone: 'Asia/Kolkata', 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true
      })}
    </span>
  );
};

const Dashboard = ({ 
  currentUser, 
  setCurrentUser,
  users, 
  setUsers, 
  campaigns,
  setCampaigns,
  transactions,
  setTransactions,
  onLogout,
  showToast,
  cities,
  setCities,
  mockDb,
  setMockDb,
  nonWaDb,
  setNonWaDb,
  whitelistRecords,
  setWhitelistRecords,
  nonWhatsappRecords,
  setNonWhatsappRecords,
  adminStaff,
  setAdminStaff,
  generalConfigs,
  setGeneralConfigs,
  domesticConfigs,
  setDomesticConfigs,
  internationalConfigs,
  setInternationalConfigs,
  buttonConfigs,
  setButtonConfigs
}: { 
  currentUser: User, 
  setCurrentUser: React.Dispatch<React.SetStateAction<User | null>>,
  users: User[], 
  setUsers: React.Dispatch<React.SetStateAction<User[]>>,
  campaigns: Campaign[],
  setCampaigns: React.Dispatch<React.SetStateAction<Campaign[]>>,
  transactions: Transaction[],
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>,
  onLogout: () => void,
  showToast: (message: string, type?: Toast['type']) => void,
  cities: string[],
  setCities: React.Dispatch<React.SetStateAction<string[]>>,
  mockDb: string[],
  setMockDb: React.Dispatch<React.SetStateAction<string[]>>,
  nonWaDb: string[],
  setNonWaDb: React.Dispatch<React.SetStateAction<string[]>>,
  whitelistRecords: NumberSearchRecord[],
  setWhitelistRecords: React.Dispatch<React.SetStateAction<NumberSearchRecord[]>>,
  nonWhatsappRecords: NumberSearchRecord[],
  setNonWhatsappRecords: React.Dispatch<React.SetStateAction<NumberSearchRecord[]>>,
  adminStaff: AdminStaff[],
  setAdminStaff: React.Dispatch<React.SetStateAction<AdminStaff[]>>,
  generalConfigs: any[],
  setGeneralConfigs: React.Dispatch<React.SetStateAction<any[]>>,
  domesticConfigs: any[],
  setDomesticConfigs: React.Dispatch<React.SetStateAction<any[]>>,
  internationalConfigs: any[],
  setInternationalConfigs: React.Dispatch<React.SetStateAction<any[]>>,
  buttonConfigs: any[],
  setButtonConfigs: React.Dispatch<React.SetStateAction<any[]>>
}) => {
  const [currentPage, setCurrentPage] = useState<Page>('Dashboard');
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [editingCampaign, setEditingCampaign] = useState<Campaign | null>(null);
  const [reportingCampaign, setReportingCampaign] = useState<Campaign | null>(null);

  const downloadCampaignDeliveryReport = (campaign: Campaign) => {
    let reportData: { number: string, status: string }[] = [];
    if (campaign.originalNumbers && campaign.originalNumbers.length > 0) {
      const processedReportMap = new Map<string, { status: string }>();
      if (campaign.reportData) {
        campaign.reportData.forEach(d => {
          processedReportMap.set(d.number.replace(/\D/g, '').slice(-10), { status: d.status });
        });
      }

      const seen = new Set();
      reportData = campaign.originalNumbers.map(rawNum => {
        const digits = rawNum.replace(/\D/g, '');
        const cleanNum = digits.slice(-10);
        
        const isAllSame = digits.length >= 10 && digits.split('').every(d => d === digits[0]);
        const isValid = digits.length >= 10 && digits.length <= 15 && !isAllSame;
        
        if (!isValid) return { number: rawNum, status: 'Invalid' };
        if (seen.has(cleanNum)) return { number: rawNum, status: 'Duplicate' };
        
        seen.add(cleanNum);
        
        const processed = processedReportMap.get(cleanNum);
        const finalStatus = processed?.status || (campaign.status === 'Completed' ? 'sent' : 'pending');
        return { 
          number: rawNum, 
          status: finalStatus
        };
      });
    } else if (campaign.reportData && campaign.reportData.length > 0) {
      reportData = campaign.reportData.map(d => ({ number: d.number, status: d.status }));
    } else if (campaign.numbers && campaign.numbers.length > 0) {
      reportData = campaign.numbers.map(num => ({
        number: num,
        status: campaign.status === 'Completed' ? 'sent' : 'pending'
      }));
    } else {
      const fallbackNumbers = [
        '7002740347', '7099445486', '7002119664', '8731888190', '9436540978',
        '8787842190', '9862796215', '9366947125', '9862781860', '9366028380'
      ];
      reportData = fallbackNumbers.map(num => ({ number: num, status: 'pending' }));
    }

    const csvContent = [['Number', 'Status'], ...reportData.map(d => [d.number, d.status])].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    link.setAttribute("href", URL.createObjectURL(blob));
    link.setAttribute("download", `User_Report_${campaign.name.replace(/\s+/g, '_')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCampaignReportClick = (campaign: Campaign) => {
    if (currentUser.role === 'Admin' || currentUser.role === 'Reseller') {
      setReportingCampaign(campaign);
    } else {
      downloadCampaignDeliveryReport(campaign);
      showToast('Downloading campaign delivery report... 📥', 'success');
    }
  };

  const handleCSVDownload = (campaign: Campaign) => {
    const csvContent = (campaign.numbers || []).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `${campaign.name}_numbers.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleWhitelistingDownload = (campaign: Campaign) => {
    const csvContent = (campaign.numbers || []).map(n => `${n},Whitelisted`).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `${campaign.name}_whitelisting.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleWhitelistingCommonDownload = (campaign: Campaign) => {
    const whitelistSet = new Set(mockDb.map(n => n.replace(/\D/g, '').slice(-10)));
    const nonWaSet = new Set(nonWaDb.map(n => n.replace(/\D/g, '').slice(-10)));
    const otherCampaignsNumbers = (campaigns || [])
      .filter(c => c.id !== campaign.id)
      .flatMap(c => c.numbers || []);
    const otherSet = new Set(otherCampaignsNumbers.map(n => n.replace(/\D/g, '').slice(-10)));

    const csvRows = (campaign.numbers || []).map(n => {
      const cleanNum = n.replace(/\D/g, '').slice(-10);
      
      const isWhitelisted = cleanNum.length >= 10 && whitelistSet.has(cleanNum);
      const isCommon = cleanNum.length >= 10 && otherSet.has(cleanNum);
      const isNonWa = cleanNum.length >= 10 && nonWaSet.has(cleanNum);
      
      let status = '';
      if (isNonWa) status = 'Non-WhatsApp';
      else if (isWhitelisted && isCommon) status = 'Whitelisted & Common';
      else if (isWhitelisted) status = 'Whitelisted';
      else if (isCommon) status = 'Common';
      
      return `${n},${status}`;
    });

    const csvContent = csvRows.join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `${campaign.name}_whitelisting_common.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const [selectedUserForCampaigns, setSelectedUserForCampaigns] = useState<User | null>(null);
  const [rejectingCampaignId, setRejectingCampaignId] = useState<string | null>(null);
  const [finishedTab, setFinishedTab] = useState<'Completed' | 'Rejected'>('Completed');
  const [userBeingEdited, setUserBeingEdited] = useState<User | null>(null);
  const [openUserDropdownId, setOpenUserDropdownId] = useState<string | null>(null);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);

  // Channel Management State
  const [channels, setChannels] = useState<Channel[]>([]);
  const demoChannels = useMemo(() => 
    channels.filter(ch => !ch.id.startsWith('private_')),
    [channels]
  );
  const [isAddChannelModalOpen, setIsAddChannelModalOpen] = useState(false);
  const [newChannelName, setNewChannelName] = useState('');
  const [qrStep, setQrStep] = useState<'name' | 'qr' | 'success'>('name');
  const [generatedQr, setGeneratedQr] = useState<string | null>(null);

  // Send Message State
  const [isSendMessageModalOpen, setIsSendMessageModalOpen] = useState(false);
  const [selectedChannelForMessage, setSelectedChannelForMessage] = useState<Channel | null>(null);
  const [testMessage, setTestMessage] = useState({ number: '', text: '', files: [] as UploadedFile[] });

  const handleTestMessage = (c: Campaign) => {
    setSelectedChannelForMessage(channels.find(ch => ch.status === 'Connected') || null);
    setTestMessage(prev => ({ ...prev, text: c.message, files: c.files || [] }));
    setIsSendMessageModalOpen(true);
  };
  const [isSending, setIsSending] = useState(false);
  const [waStatus, setWaStatus] = useState<{ status: string, qr: string | null, user: any }>({ status: 'close', qr: null, user: null });
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [deletingSessionId, setDeletingSessionId] = useState<string | null>(null);

  // Transaction Management State
  const [transactionSearchQuery, setTransactionSearchQuery] = useState('');
  const [transactionTypeFilter, setTransactionTypeFilter] = useState<'All' | 'domestic' | 'international' | 'button'>('All');
  const [transactionActionFilter, setTransactionActionFilter] = useState<'All' | 'Added' | 'Deducted'>('All');
  const [showRefundAnalytics, setShowRefundAnalytics] = useState(false);

  // Helper for safe JSON fetching
  const safeFetchJson = async (url: string, options?: RequestInit) => {
    try {
      const res = await fetch(url, options);
      const contentType = res.headers.get('content-type');
      
      if (!res.ok) {
        let errorMsg = `Server error: ${res.status}`;
        if (contentType && contentType.includes('application/json')) {
          const errData = await res.json();
          errorMsg = errData.error || errorMsg;
        }
        throw new Error(errorMsg);
      }
      
      if (!contentType || !contentType.includes('application/json')) {
        // Log it but don't strictly throw if we don't expect a body
        if (res.status === 204 || res.status === 200) return {};
        throw new Error('Server returned an invalid format (not JSON)');
      }
      
      return await res.json();
    } catch (err: any) {
      // Only log network errors if they are not "Failed to fetch" (which is common during restarts)
      if (err.message !== 'Failed to fetch') {
        console.error(`Fetch failure for ${url}:`, err);
      }
      throw err;
    }
  };

  // Calculate Credit-based stats for Dashboard
  const userCampaigns = useMemo(() => {
    if (!currentUser) return [];
    return campaigns.filter(c => c.userId === currentUser.id);
  }, [campaigns, currentUser]);

  const totalCreditsUsed = useMemo(() => 
    userCampaigns.reduce((acc, c) => acc + (c.creditsUsed || 0), 0),
    [userCampaigns]
  );

  const creditStats = useMemo(() => {
    if (totalCreditsUsed === 0) {
      return {
        completed: 0,
        pending: 0,
        active: 0,
        rejected: 0
      };
    }

    const getPercentage = (status: string) => {
      const credits = userCampaigns
        .filter(c => c.status === status)
        .reduce((acc, c) => acc + (c.creditsUsed || 0), 0);
      return parseFloat(((credits / totalCreditsUsed) * 100).toFixed(1));
    };

    return {
      completed: getPercentage('Completed'),
      pending: getPercentage('Pending'),
      active: getPercentage('Active'),
      rejected: getPercentage('Rejected')
    };
  }, [userCampaigns, totalCreditsUsed]);

  const topSpentUsers = useMemo(() => {
    if (!currentUser || currentUser.role !== 'Admin') return [];
    
    const userMap: Record<string, { id: string, name: string, totalSpent: number, campaignCount: number }> = {};
    
    campaigns.forEach(c => {
      if (!c.userId) return;
      const uid = c.userId;
      if (!userMap[uid]) {
        userMap[uid] = { 
          id: uid, 
          name: c.userName || 'Unknown User', 
          totalSpent: 0, 
          campaignCount: 0 
        };
      }
      userMap[uid].totalSpent += (c.creditsUsed || 0);
      userMap[uid].campaignCount += 1;
    });

    return Object.values(userMap)
      .sort((a, b) => b.totalSpent - a.totalSpent)
      .slice(0, 10);
  }, [campaigns, currentUser?.role]);

  // Protect Admin Pages
  useEffect(() => {
    if (!currentUser) return;
    const adminOnlyPages: Page[] = [
      'Demo Server', 'Pending Campaign', 'Finished Campaign', 
      'Non Whatsapp Number', 'White Listing Number', 'Campaign Config', 
      'Cities', 'Admin Staff', 'Private Subscriptions'
    ];
    if (currentUser.role !== 'Admin' && adminOnlyPages.includes(currentPage)) {
      setCurrentPage('Dashboard');
    }
  }, [currentPage, currentUser?.role]);

  // Polling for WhatsApp Status
  useEffect(() => {
    let interval: any;
    let privateInterval: any;
    const hasPendingCampaigns = campaigns.some(c => c.status === 'Pending' && (c.isDemo || c.assignedServerId));
    let isFetching = false;
    let isPrivateFetching = false;
    
    if (currentPage === 'Demo Server' || isAddChannelModalOpen || hasPendingCampaigns) {
      const checkStatus = async () => {
        if (isFetching) return;
        isFetching = true;
        try {
          const data = await safeFetchJson('/api/whatsapp/status');
          
          if (data && Array.isArray(data.sessions)) {
            // Update all channels based on server sessions
            const updatedChannels: Channel[] = data.sessions.map((s: any) => ({
              id: s.id,
              name: s.name,
              number: s.user ? s.user.id.split(':')[0] : undefined,
              status: s.status === 'open' ? 'Connected' : 
                      s.status === 'connecting' ? 'Connecting' : 
                      s.status === 'loggedOut' ? 'Logged Out' : 'Disconnected',
              lastUsed: 'Just now',
              isRestricted: s.isRestricted || false
            }));
            setChannels(updatedChannels);

            // If we are in the middle of adding a channel, check its specific status
            if (currentSessionId) {
              const currentSession = data.sessions.find((s: any) => s.id === currentSessionId);
              if (currentSession) {
                if (currentSession.status === 'open' && qrStep === 'qr') {
                  setQrStep('success');
                  setCurrentSessionId(null);
                  setGeneratedQr(null);
                } else if (currentSession.qr) {
                  setGeneratedQr(currentSession.qr);
                }
              }
            }
            
            // For backward compatibility or general status display
            const mainSession = data.sessions[0] || { status: 'close', qr: null, user: null };
            setWaStatus({
              status: mainSession.status,
              qr: mainSession.qr,
              user: mainSession.user
            });
          }
        } catch (err) {
          // console.error('Failed to fetch WA status', err);
        } finally {
          isFetching = false;
        }
      };

      checkStatus();
      interval = setInterval(checkStatus, 5000);
    }

    if (currentPage === 'Private Sender' && currentUser) {
      const checkPrivateStatus = async () => {
        if (isPrivateFetching) return;
        isPrivateFetching = true;
        try {
          const url = `${PRIVATE_SENDER_API_BASE}/status`;
          const data = await safeFetchJson(url);
          
          if (data && Array.isArray(data.sessions)) {
            const privId = `private_${currentUser.id}`;
            const privSession = data.sessions.find((s: any) => s.id === privId);
            if (privSession) {
              setPrivateSenderSession(privSession);
              if (privSession.qr) {
                setPrivateSenderQr(privSession.qr);
              } else if (privSession.status === 'open') {
                setPrivateSenderQr(null);
              }
              if (privSession.messages && !isSending) {
                setPrivateSenderMessages(privSession.messages);
              }
            } else {
              setPrivateSenderSession(null);
              setPrivateSenderQr(null);
            }
          }
        } catch (err) {
          // console.error('Failed to fetch Private Sender status', err);
        } finally {
          isPrivateFetching = false;
        }
      };

      checkPrivateStatus();
      privateInterval = setInterval(checkPrivateStatus, 5000);
    }

    return () => {
      if (interval) clearInterval(interval);
      if (privateInterval) clearInterval(privateInterval);
    };
  }, [currentPage, isAddChannelModalOpen, qrStep, newChannelName, currentSessionId, campaigns, currentUser, isSending]);

  // Process Demo Campaigns
  const processingCampaigns = React.useRef<Set<string>>(new Set());

  useEffect(() => {
    const processDemoCampaigns = async () => {
      const pendingDemoCampaigns = campaigns.filter(c => 
        ((c.status === 'Pending' || c.status === 'Active') && (c.isDemo || c.assignedServerId)) && 
        c.numbers && 
        c.numbers.length > 0 &&
        !c.isPaused &&
        !processingCampaigns.current.has(c.id)
      );
      
      if (pendingDemoCampaigns.length === 0) return;
      
      for (const campaign of pendingDemoCampaigns) {
        if (processingCampaigns.current.has(campaign.id)) continue;
        
        const isDividedPool = campaign.assignedServerId === 'divide_all' || 
          (campaign.assignedServerId && campaign.assignedServerId.startsWith('divide_selected:')) ||
          (!campaign.assignedServerId && demoChannels.filter(ch => ch.status === 'Connected' && !ch.isRestricted).length > 1);
        let connectedChannel = null;

        if (isDividedPool) {
          let activeChannels = demoChannels.filter(ch => ch.status === 'Connected' && !ch.isRestricted);
          if (campaign.assignedServerId && campaign.assignedServerId.startsWith('divide_selected:')) {
            const selectedIds = campaign.assignedServerId.split(':')[1].split(',');
            activeChannels = activeChannels.filter(ch => selectedIds.includes(ch.id));
          }
          if (activeChannels.length === 0) {
            console.log(`[Campaign Engine] Campaign ${campaign.name} waiting: Divided pool active but no connected and non-restricted channels found.`);
            continue;
          }
          connectedChannel = activeChannels[0]; // placeholder for initiating sequence
        } else {
          connectedChannel = campaign.assignedServerId 
            ? demoChannels.find(ch => ch.id === campaign.assignedServerId && ch.status === 'Connected' && !ch.isRestricted)
            : demoChannels.find(ch => ch.status === 'Connected' && !ch.isRestricted);
        }

        if (!connectedChannel) {
          console.log(`[Campaign Engine] Campaign ${campaign.name} waiting: No connected and non-restricted channels found for target: ${campaign.assignedServerId || 'auto'}`);
          continue;
        }
        
        processingCampaigns.current.add(campaign.id);
        console.log(`Starting campaign: ${campaign.name} (${campaign.id}) ${isDividedPool ? '(Divided Pool)' : ''}`);
        
        // Apply Filter Mode logic
        const filteredSet = (() => {
          if (!campaign.filterMode || campaign.filterMode === 'all') return new Set(campaign.numbers || []);
          
          const whitelistSet = new Set(mockDb.map(n => n.replace(/\D/g, '').slice(-10)));
          const otherCampaignsNumbers = campaigns
            .filter(c => c.id !== campaign.id)
            .flatMap(c => c.numbers || []);
          const otherCampaignsSet = new Set(otherCampaignsNumbers.map(n => n.replace(/\D/g, '').slice(-10)));
          
          const filtered = (campaign.numbers || []).filter(n => {
            const cleanNum = n.replace(/\D/g, '').slice(-10);
            if (campaign.filterMode === 'whitelisted') return whitelistSet.has(cleanNum);
            if (campaign.filterMode === 'common') return otherCampaignsSet.has(cleanNum);
            if (campaign.filterMode === 'both') return whitelistSet.has(cleanNum) || otherCampaignsSet.has(cleanNum);
            if (campaign.filterMode === 'agent') return true; // Placeholder for Agent logic
            return true;
          });
          return new Set(filtered);
        })();

        // Mark as Active while sending
        setCampaigns(prev => prev.map(c => c.id === campaign.id ? { ...c, status: 'Active', sentCount: 0, reportData: [], totalCount: (campaign.numbers || []).length } : c));
        
        try {
          let currentSent = 0;
          const currentReport: { number: string, status: string, senderName?: string, senderNumber?: string }[] = [];
          let numberIndex = 0;
          let isAborted = false;

          for (const number of (campaign.numbers || [])) {
            let currentStatus = 'sent';
            let currentChannel = connectedChannel;

            if (isDividedPool) {
              let activePool = demoChannels.filter(ch => ch.status === 'Connected' && !ch.isRestricted);
              if (campaign.assignedServerId && campaign.assignedServerId.startsWith('divide_selected:')) {
                const selectedIds = campaign.assignedServerId.split(':')[1].split(',');
                activePool = activePool.filter(ch => selectedIds.includes(ch.id));
              }
              if (activePool.length === 0) {
                throw new Error('All WhatsApp sender accounts in the pool are disconnected or Restricted! ❌');
              }
              currentChannel = activePool[numberIndex % activePool.length];
            }

            if (!filteredSet.has(number)) {
              currentStatus = 'Skipped';
            } else {
              console.log(`Campaign: Sending to ${number} via ${currentChannel.name}`);
              
              const files = campaign.files || [];
              
              try {
                // 1. Check if number exists on WhatsApp
                const checkData = await safeFetchJson('/api/whatsapp/check', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ sessionId: currentChannel.id, number })
                });
                
                if (!checkData.exists) {
                  currentStatus = 'Non-WhatsApp';
                } else {
                  // 2. Send messages
                  if (files.length > 0) {
                    for (let i = 0; i < files.length; i++) {
                      const file = files[i];
                      let mediaData = '';
                      try {
                        if (file.url.startsWith('data:')) {
                          mediaData = file.url;
                        } else {
                          const response = await fetch(file.url);
                          const blob = await response.blob();
                          mediaData = await fileToBase64(blob as File);
                        }
                      } catch (err) {
                        console.error('Failed to convert file to base64:', err);
                        currentStatus = 'Non-WhatsApp'; // Label as non-whatsapp for demo if failure
                        continue;
                      }

                      const res = await fetch('/api/whatsapp/send', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          sessionId: currentChannel.id,
                          to: number,
                          message: i === 0 ? campaign.message : '',
                          mediaType: file.type,
                          mediaData: mediaData,
                          fileName: file.name
                        })
                      });

                      if (!res.ok) {
                        try {
                          const errData = await res.json();
                          if (errData.code === 463 || errData.isRestricted) {
                            currentStatus = 'Restricted';
                          } else {
                            currentStatus = 'Non-WhatsApp';
                          }
                        } catch (e) {
                          currentStatus = 'Non-WhatsApp';
                        }
                      }
                      await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                  } else {
                    const res = await fetch('/api/whatsapp/send', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        sessionId: currentChannel.id,
                        to: number,
                        message: campaign.message
                      })
                    });

                    if (!res.ok) {
                      try {
                        const errData = await res.json();
                        if (errData.code === 463 || errData.isRestricted) {
                          currentStatus = 'Restricted';
                        } else {
                          currentStatus = 'Non-WhatsApp';
                        }
                      } catch (e) {
                        currentStatus = 'Non-WhatsApp';
                      }
                    }
                  }
                }
              } catch (err: any) {
                console.error('Process failed for number:', number, err);
                const isRestrictedMsg = err.message && (
                  err.message.includes('463') || 
                  err.message.toLowerCase().includes('restricted') || 
                  err.message.toLowerCase().includes('tctoken')
                );
                if (isRestrictedMsg) {
                  currentStatus = 'Restricted';
                } else {
                  currentStatus = 'Non-WhatsApp';
                }
              }
            }
            
            if (currentStatus === 'sent') currentSent++;
            currentReport.push({ 
              number, 
              status: currentStatus,
              senderName: currentChannel?.name,
              senderNumber: currentChannel?.number
            });
            
            setCampaigns(prev => prev.map(c => c.id === campaign.id ? { 
              ...c, 
              sentCount: currentSent,
              reportData: [...currentReport]
            } : c));

            if (currentStatus === 'Restricted') {
              if (isDividedPool) {
                // Mark this channel as restricted locally to exclude from active list in future iterations
                setChannels(prev => prev.map(ch => ch.id === currentChannel.id ? { ...ch, isRestricted: true } : ch));
                showToast(`Channel ${currentChannel.name} is Restricted and excluded from active pool. ⚠️`, 'warning');
              } else {
                // Pause campaign immediately and set status back to Pending or Rejected/Restricted
                isAborted = true;
                setCampaigns(prev => prev.map(c => c.id === campaign.id ? { 
                  ...c, 
                  status: 'Rejected',
                  rejectionReason: 'Campaign stopped: WhatsApp Sender Account is Restricted (Error 463).' 
                } : c));
                showToast('Campaign stopped: WhatsApp Sender Account is Restricted.', 'error');
                break; // Abort sending loop
              }
            }
            
            // Only delay if we actually sent something or tried to
            if (currentStatus !== 'Skipped') {
              numberIndex++;
              await new Promise(resolve => setTimeout(resolve, 2000));
            }
          }
          
          if (!isAborted) {
            console.log(`Demo campaign finished: ${campaign.name}`);
            // Mark as Completed
            setCampaigns(prev => prev.map(c => c.id === campaign.id ? { ...c, status: 'Completed' } : c));
          }
        } catch (error) {
          console.error('Error sending demo campaign:', error);
          // Revert to Pending if failed so it can try again
          setCampaigns(prev => prev.map(c => c.id === campaign.id ? { ...c, status: 'Pending' } : c));
        } finally {
          processingCampaigns.current.delete(campaign.id);
        }
      }
    };

    // Run immediately and also on interval as fallback
    processDemoCampaigns();
    const interval = setInterval(processDemoCampaigns, 5000);
    return () => clearInterval(interval);
  }, [campaigns, channels]);

  const handleSendMessage = async () => {
    if (!testMessage.number || !testMessage.text || !selectedChannelForMessage) return;
    setIsSending(true);
    try {
      const files = testMessage.files || [];
      const isPrivateChannel = selectedChannelForMessage.id.startsWith('private_');
      const sendEndpoint = isPrivateChannel ? `${PRIVATE_SENDER_API_BASE}/send` : '/api/whatsapp/send';
      
      if (files.length > 0) {
        // Logic: First media file with text message as caption, 
        // then remaining media files as single messages
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          let mediaData = '';
          try {
            if (file.url.startsWith('data:')) {
              mediaData = file.url;
            } else {
              const response = await fetch(file.url);
              const blob = await response.blob();
              mediaData = await fileToBase64(blob as File);
            }
          } catch (err) {
            console.error('Failed to convert file to base64:', err);
            continue;
          }

          await safeFetchJson(sendEndpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              id: selectedChannelForMessage.id,
              sessionId: selectedChannelForMessage.id,
              to: testMessage.number,
              message: i === 0 ? testMessage.text : '', // Only first media gets the caption
              mediaType: file.type,
              mediaData: mediaData,
              fileName: file.name
            })
          });
          
          if (i < files.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
        }
      } else {
        // Simple text message
        await safeFetchJson(sendEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: selectedChannelForMessage.id,
            sessionId: selectedChannelForMessage.id,
            to: testMessage.number,
            message: testMessage.text
          })
        });
      }
      
      setIsSendMessageModalOpen(false);
      setTestMessage({ number: '', text: '', files: [] });
      showToast('Message sent successfully!');
    } catch (err) {
      console.error('Failed to send message', err);
      showToast('Failed to send message. Please check connection.', 'error');
    } finally {
      setIsSending(false);
    }
  };

  const handleAddChannel = async () => {
    if (!newChannelName.trim()) return;
    try {
      const data = await safeFetchJson('/api/whatsapp/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newChannelName })
      });
      setCurrentSessionId(data.id);
      setQrStep('qr');
    } catch (err) {
      console.error('Failed to create session', err);
      showToast('Failed to initiate QR generation. Please try again.', 'error');
    }
  };

  const handleLogoutWA = async (sessionId?: string) => {
    const id = sessionId || (selectedChannelForMessage?.id);
    if (!id) return;

    setDeletingSessionId(id);
    try {
      await safeFetchJson('/api/whatsapp/logout', { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: id })
      });
      
      setChannels(prev => prev.filter(c => c.id !== id));
      if (selectedChannelForMessage?.id === id) {
        setIsSendMessageModalOpen(false);
      }
      showToast('Channel logged out and deleted');
    } catch (err: any) {
      console.error('Failed to logout', err);
      showToast('Failed to delete channel: ' + (err.message || 'Please try again.'), 'error');
    } finally {
      setDeletingSessionId(null);
    }
  };

  const handleDeleteChannel = (id: string) => {
    setChannels(channels.filter(c => c.id !== id));
  };

  const handleFinishCampaign = (id: string, serverId?: string, filterMode: FilterMode = 'all') => {
    const campaign = campaigns.find(c => c.id === id);
    if (!campaign) return;

    // If it's a demo campaign (<= 10 numbers), it already uses the auto-run logic
    // If it's > 10 numbers and admin is running it, we mark it as Pending and set the serverId
    // to trigger the processDemoCampaigns loop which handles sending.
    
    if (serverId) {
      setCampaigns(prev => prev.map(c => c.id === id ? { ...c, assignedServerId: serverId, filterMode, isPaused: false } : c));
    } else {
      // Direct completion for non-server runs (legacy behavior)
      const totalCount = campaign.numbers?.length || 0;
      setCampaigns(prev => prev.map(c => c.id === id ? { 
        ...c, 
        status: 'Active', 
        isPaused: false,
        sentCount: totalCount,
        totalCount: totalCount
      } : c));
      setTimeout(() => {
        setCampaigns(prev => prev.map(c => c.id === id ? { ...c, status: 'Completed' } : c));
      }, 2000);
    }
    setRunningCampaignId(null);
  };

  const handleUpdateCampaignMessage = (id: string, newMessage: string, newFiles: UploadedFile[]) => {
    const campaign = campaigns.find(c => c.id === id);
    const isOwner = campaign?.userId === currentUser.id;
    const isPending = campaign?.status === 'Pending';

    if (currentUser.role !== 'Admin' && !(isOwner && isPending)) {
      showToast('Only administrators or the campaign owner (if pending) can edit.', 'warning');
      return;
    }
    setCampaigns(prev => prev.map(c => c.id === id ? { ...c, message: newMessage, files: newFiles } : c));
    showToast('Campaign message updated');
    setEditingCampaign(null);
  };

  const handleRejectCampaign = (reason: string) => {
    if (!rejectingCampaignId) return;
    const campaignToReject = campaigns.find(c => c.id === rejectingCampaignId);
    
    if (campaignToReject && campaignToReject.userId && campaignToReject.creditsUsed) {
      const userId = campaignToReject.userId;
      const creditsToRefund = campaignToReject.creditsUsed;
      const type = campaignToReject.type;

      const newTransaction: Transaction = {
        id: Math.random().toString(36).substr(2, 9),
        userId: userId,
        amount: creditsToRefund,
        type: type === 'Button' ? 'button' : (type === 'International' ? 'international' : 'domestic'),
        date: new Date().toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }),
        note: `Refund for rejected campaign: ${campaignToReject.name}`,
        action: 'Added'
      };
      setTransactions([newTransaction, ...transactions]);

      setUsers(prevUsers => prevUsers.map(u => {
        if (u.id === userId) {
          const updatedUser = {
            ...u,
            domCredits: type === 'Standard' ? u.domCredits + creditsToRefund : u.domCredits,
            btnCredits: type === 'Button' ? u.btnCredits + creditsToRefund : u.btnCredits,
            intCredits: type === 'International' ? u.intCredits + creditsToRefund : u.intCredits
          };
          // Update currentUser if it's the same person
          if (currentUser.id === userId) {
            setCurrentUser(updatedUser);
          }
          return updatedUser;
        }
        return u;
      }));
    }

    setCampaigns(prev => prev.map(c => c.id === rejectingCampaignId ? { ...c, status: 'Rejected', rejectionReason: reason, isPaused: false } : c));
    setRejectingCampaignId(null);
    showToast('Campaign rejected successfully', 'warning');
  };

  const handleRestoreCampaign = (id: string) => {
    const campaignToRestore = campaigns.find(c => c.id === id);
    if (!campaignToRestore || !campaignToRestore.userId) return;

    const userId = campaignToRestore.userId;
    const creditsToDeduct = campaignToRestore.creditsUsed || 0;
    const type = campaignToRestore.type;
    const isDemo = !!campaignToRestore.isDemo;

    // Find the user to check credits (skip check for demo)
    if (!isDemo) {
      const user = users.find(u => u.id === userId);
      if (!user) return;

      // Check if user has enough credits
      const available = type === 'Standard' ? user.domCredits : (type === 'International' ? user.intCredits : user.btnCredits);
      if (available < creditsToDeduct) {
        showToast(`User has insufficient ${type} Credits! ❌`, 'error');
        return;
      }

      setUsers(users.map(u => {
        if (u.id === userId) {
          const updatedUser = {
            ...u,
            domCredits: type === 'Standard' ? u.domCredits - creditsToDeduct : u.domCredits,
            btnCredits: type === 'Button' ? u.btnCredits - creditsToDeduct : u.btnCredits,
            intCredits: type === 'International' ? u.intCredits - creditsToDeduct : u.intCredits
          };
          if (currentUser?.id === userId) {
            setCurrentUser(updatedUser);
          }
          return updatedUser;
        }
        return u;
      }));
    }

    setCampaigns(prev => prev.map(c => c.id === id ? { 
      ...c, 
      status: 'Pending', 
      sentCount: 0, 
      rejectionReason: undefined, 
      reportData: undefined,
      assignedServerId: undefined,
      filterMode: undefined,
      isPaused: false,
      totalCount: (c.numbers || []).length
    } : c));
    showToast('Campaign restored to Pending 🔄');
  };

  const handleResetCampaign = (id: string) => {
    console.log('Resetting campaign:', id);
    setCampaigns(prev => prev.map(c => c.id === id ? { 
      ...c, 
      status: 'Pending', 
      isPaused: true,
      sentCount: 0, 
      rejectionReason: undefined, 
      reportData: undefined,
      assignedServerId: undefined,
      filterMode: undefined,
      totalCount: (c.numbers || []).length
    } : c));
    showToast('Campaign reset successfully');
  };

  const handleCampaignScanned = (id: string) => {
    setCampaigns(prev => prev.map(c => c.id === id ? { ...c, isScanned: true } : c));
  };

  const handleDirectFinish = (id: string) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id === id) {
        const count = c.numbers?.length || c.totalCount || 0;
        return { ...c, status: 'Completed', sentCount: count, totalCount: count };
      }
      return c;
    }));
    showToast('Campaign finished manually');
    setRunningCampaignId(null);
  };

  const parseCampaignDate = (dateStr: string): Date => {
    try {
      const standardDate = new Date(dateStr);
      if (!isNaN(standardDate.getTime())) return standardDate;

      const parts = dateStr.split(',');
      const datePart = parts[0].trim();
      const timePart = parts[1] ? parts[1].trim() : '';

      const dateSubparts = datePart.split(/[\/\-]/);
      if (dateSubparts.length === 3) {
        const day = parseInt(dateSubparts[0], 10);
        const month = parseInt(dateSubparts[1], 10) - 1;
        const year = parseInt(dateSubparts[2], 10);

        let hours = 0;
        let minutes = 0;
        let seconds = 0;

        if (timePart) {
          const matches = timePart.match(/(\d+):(\d+):?(\d+)?\s*(am|pm)?/i);
          if (matches) {
            hours = parseInt(matches[1], 10);
            minutes = parseInt(matches[2], 10);
            seconds = matches[3] ? parseInt(matches[3], 10) : 0;
            const ampm = matches[4] ? matches[4].toLowerCase() : '';
            if (ampm === 'pm' && hours < 12) hours += 12;
            if (ampm === 'am' && hours === 12) hours = 0;
          }
        }
        return new Date(year, month, day, hours, minutes, seconds);
      }
    } catch (e) {
      console.error("Error parsing campaign date:", dateStr, e);
    }
    return new Date();
  };

  const pending48HrRefundCampaigns = useMemo(() => {
    return campaigns.filter(c => {
      if (c.status !== 'Completed' || c.isRefunded) return false;
      const ageInHours = (new Date().getTime() - parseCampaignDate(c.date).getTime()) / (1000 * 60 * 60);
      return ageInHours >= 48;
    });
  }, [campaigns]);

  const handleProcessBulk48HrRefunds = () => {
    if (pending48HrRefundCampaigns.length === 0) {
      showToast('No pending 48-hour campaign refunds found!', 'info');
      return;
    }

    // Group the campaigns by userId and campaign type
    // type determines whether the transaction should be 'domestic', 'international', or 'button'
    const groups: Record<string, {
      userId: string;
      type: 'domestic' | 'international' | 'button';
      campaigns: Campaign[];
      totalCredits: number;
    }> = {};

    let totalRefundedOverall = 0;
    const campaignsToMarkRefunded: string[] = [];

    pending48HrRefundCampaigns.forEach(c => {
      const reportData = c.reportData || [];
      const nonWACount = reportData.filter(d => d.status === 'Non-WhatsApp').length;
      campaignsToMarkRefunded.push(c.id);

      if (nonWACount > 0) {
        const userId = c.userId;
        const type = c.type === 'Button' ? 'button' : (c.type === 'International' ? 'international' : 'domestic');
        const key = `${userId}_${type}`;

        if (!groups[key]) {
          groups[key] = {
            userId,
            type,
            campaigns: [],
            totalCredits: 0
          };
        }
        groups[key].campaigns.push(c);
        groups[key].totalCredits += nonWACount;
        totalRefundedOverall += nonWACount;
      }
    });

    const newTransactions: Transaction[] = [];
    const userCreditUpdates: Record<string, { dom: number; int: number; btn: number }> = {};

    // Process each group and create a single combined transaction
    Object.values(groups).forEach(g => {
      if (g.totalCredits === 0) return;

      const campaignNames = g.campaigns.map(c => c.name);
      // We truncate the list of campaign names if it's too long
      const campaignNamesStr = campaignNames.length > 3
        ? `${campaignNames.slice(0, 3).join(', ')} and ${campaignNames.length - 3} others`
        : campaignNames.join(', ');

      const newTransaction: Transaction = {
        id: Math.random().toString(36).substr(2, 9),
        userId: g.userId,
        amount: g.totalCredits,
        type: g.type,
        date: new Date().toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }),
        note: `Combined 48-Hour Non-WhatsApp Refund for ${g.campaigns.length} campaigns: ${campaignNamesStr}`,
        action: 'Added'
      };

      newTransactions.push(newTransaction);

      if (!userCreditUpdates[g.userId]) {
        userCreditUpdates[g.userId] = { dom: 0, int: 0, btn: 0 };
      }
      if (g.type === 'domestic') userCreditUpdates[g.userId].dom += g.totalCredits;
      if (g.type === 'international') userCreditUpdates[g.userId].int += g.totalCredits;
      if (g.type === 'button') userCreditUpdates[g.userId].btn += g.totalCredits;
    });

    // Update transactions state
    if (newTransactions.length > 0) {
      setTransactions(prev => [...newTransactions, ...prev]);
    }

    // Update users and current user state
    setUsers(prevUsers => prevUsers.map(u => {
      const update = userCreditUpdates[u.id];
      if (update) {
        const updatedUser = {
          ...u,
          domCredits: u.domCredits + update.dom,
          intCredits: u.intCredits + update.int,
          btnCredits: u.btnCredits + update.btn
        };
        if (currentUser.id === u.id) {
          setCurrentUser(updatedUser);
        }
        return updatedUser;
      }
      return u;
    }));

    // Update campaigns state
    setCampaigns(prev => prev.map(c => 
      campaignsToMarkRefunded.includes(c.id) ? { ...c, isRefunded: true } : c
    ));

    showToast(`Successfully processed bulk refunds for ${pending48HrRefundCampaigns.length} campaigns. Total ${totalRefundedOverall} credits refunded in combined entries.`, 'success');
  };

  const handleRefundNonWA = (campaignId: string) => {
    const campaign = campaigns.find(c => c.id === campaignId);
    if (!campaign || !campaign.userId) return;

    if (campaign.isRefunded) {
      showToast('This campaign has already been processed for refunds!', 'warning');
      return;
    }

    // Calculate non-whatsapp count from report data
    const reportData = campaign.reportData || [];
    const nonWACount = reportData.filter(d => d.status === 'Non-WhatsApp').length;
    
    if (nonWACount === 0) {
      showToast('System found 0 Non-WhatsApp targets. No refund applicable.', 'info');
      return;
    }

    const userId = campaign.userId;
    const creditsToRefund = nonWACount;
    const type = campaign.type || 'Standard';

    const newTransaction: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      userId: userId,
      amount: creditsToRefund,
      type: type === 'Button' ? 'button' : (type === 'International' ? 'international' : 'domestic'),
      date: new Date().toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }),
      note: `Non-WhatsApp Refund for campaign: ${campaign.name}`,
      action: 'Added'
    };
    
    setTransactions([newTransaction, ...transactions]);
    
    setUsers(prevUsers => prevUsers.map(u => {
      if (u.id === userId) {
        const updatedUser = {
          ...u,
          domCredits: type === 'Standard' ? u.domCredits + creditsToRefund : u.domCredits,
          intCredits: (type as string) === 'International' ? u.intCredits + creditsToRefund : u.intCredits,
          btnCredits: type === 'Button' ? u.btnCredits + creditsToRefund : u.btnCredits
        };
        if (currentUser.id === userId) setCurrentUser(updatedUser);
        return updatedUser;
      }
      return u;
    }));

    setCampaigns(prev => prev.map(c => c.id === campaignId ? { ...c, isRefunded: true } : c));
    showToast(`Successfully refunded ${creditsToRefund} intelligence units for Non-WhatsApp signals.`, 'success');
  };
  const transactionStats = useMemo(() => {
    const refunds = transactions.filter(t => t.note.toLowerCase().includes('refund') || t.note.toLowerCase().includes('non-whatsapp'));
    const totalRefunded = refunds.reduce((acc, curr) => acc + curr.amount, 0);
    const totalUsers = new Set(refunds.map(t => t.userId)).size;
    
    return {
      refundsCount: refunds.length,
      totalRefunded,
      totalUsers
    };
  }, [transactions]);

  const userRefundAnalytics = useMemo(() => {
    const userRefunds: Record<string, { total: number, count: number, lastDate: string }> = {};
    transactions
      .filter(t => t.note.toLowerCase().includes('refund') || t.note.toLowerCase().includes('non-whatsapp'))
      .forEach(t => {
        if (!userRefunds[t.userId]) {
          userRefunds[t.userId] = { total: 0, count: 0, lastDate: t.date };
        }
        userRefunds[t.userId].total += t.amount;
        userRefunds[t.userId].count += 1;
        if (new Date(t.date) > new Date(userRefunds[t.userId].lastDate)) {
          userRefunds[t.userId].lastDate = t.date;
        }
      });

    return Object.entries(userRefunds)
      .sort((a, b) => b[1].total - a[1].total);
  }, [transactions]);

  const userDashboardStats = useMemo(() => {
    if (!currentUser) return { total: 0, completed: 0, pending: 0 };
    const userCamps = campaigns.filter(c => c.userId === currentUser.id);
    return {
      total: userCamps.length,
      completed: userCamps.filter(c => c.status === 'Completed').length,
      pending: userCamps.filter(c => c.status === 'Pending').length
    };
  }, [campaigns, currentUser?.id]);

  const recentUserTransactions = useMemo(() => {
    if (!currentUser) return [];
    return transactions
      .filter(t => t.userId === currentUser.id)
      .slice(0, 5);
  }, [transactions, currentUser?.id]);

  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  // Demo Server Selection for Pending Campaigns
  const [runningCampaignId, setRunningCampaignId] = useState<string | null>(null);
  const [selectedServerForRun, setSelectedServerForRun] = useState<string>('');
  
  // My Campaign Search
  const [searchQuery, setSearchQuery] = useState('');
  const deferredSearchQuery = useDeferredValue(searchQuery);

  // Create Campaign Form State
  const [campaignTitle, setCampaignTitle] = useState('');
  const [campaignOption, setCampaignOption] = useState<'Domestic' | 'International'>('Domestic');
  const [selectedCountry, setSelectedCountry] = useState('India');
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [numberFormat, setNumberFormat] = useState<'Manual' | 'CSV' | 'Excel'>('Manual');
  const [mobileNumbers, setMobileNumbers] = useState('');
  const [uploadedImages, setUploadedImages] = useState<UploadedFile[]>([]);
  const [uploadedVideos, setUploadedVideos] = useState<UploadedFile[]>([]);
  const [uploadedPDFs, setUploadedPDFs] = useState<UploadedFile[]>([]);

  // Button Campaign State
  const [btnCampaignTitle, setBtnCampaignTitle] = useState('');
  const [btnCampaignOption, setBtnCampaignOption] = useState<'Domestic' | 'International'>('Domestic');
  const [btnSelectedCountry, setBtnSelectedCountry] = useState('India');
  const [isBtnCountryDropdownOpen, setIsBtnCountryDropdownOpen] = useState(false);
  const [btnMessage, setBtnMessage] = useState('');
  const [btnLinkText, setBtnLinkText] = useState('Visit Now');
  const [btnLinkUrl, setBtnLinkUrl] = useState('https://example.com');
  const [btnCallText, setBtnCallText] = useState('Call Now');
  const [btnCallNumber, setBtnCallNumber] = useState('');
  const [btnMedia, setBtnMedia] = useState<UploadedFile[]>([]);
  const [btnNumberFormat, setBtnNumberFormat] = useState<'Manual' | 'CSV' | 'Excel'>('Manual');
  const [btnMobileNumbers, setBtnMobileNumbers] = useState('');

  // User Management State
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const deferredUserSearchQuery = useDeferredValue(userSearchQuery);
  const [userStatusTab, setUserStatusTab] = useState<'Active' | 'Suspended' | 'Deleted'>('Active');
  const [userRoleFilter, setUserRoleFilter] = useState<'All' | 'User' | 'Reseller'>('All');
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  
  // Add User Form State
  const [newUser, setNewUser] = useState<Partial<User>>({
    name: '',
    username: '',
    password: '',
    mobile: '',
    email: '',
    role: 'User',
    status: 'Active',
    location: 'Delhi',
    domCredits: 0,
    intCredits: 0,
    btnCredits: 0,
    cuttingPercentage: '0'
  });

  const handleFileUpload = (file: File, isButton = false) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      // Simple parser for CSV/Text
      const lines = text.split(/\r?\n/);
      const numbers: string[] = [];
      lines.forEach(line => {
        const cleaned = line.replace(/[^\d]/g, '').trim();
        if (cleaned.length >= 10) numbers.push(cleaned);
      });
      
      if (numbers.length > 0) {
        const finalString = numbers.join('\n');
        if (isButton) {
          setBtnMobileNumbers(finalString);
        } else {
          setMobileNumbers(finalString);
        }
        showToast(`${numbers.length} numbers ingested from ${file.name}`);
      } else {
        showToast(`No valid numbers found in ${file.name}`, 'error');
      }
    };
    reader.readAsText(file);
  };

  const handleAddUser = () => {
    if (!newUser.name || !newUser.username || !newUser.password) {
      showToast('Name, Identity (Username), and Authorization Key (Password) are required! ❌', 'error');
      return;
    }
    
    // Check if username already exists
    if (users.some(u => u.username === newUser.username)) {
      showToast('Username already exists in the system! ❌', 'error');
      return;
    }

    // Credit validation for resellers
    if (currentUser.role === 'Reseller') {
      const dom = newUser.domCredits || 0;
      const btn = newUser.btnCredits || 0;
      const int = newUser.intCredits || 0;

      if (currentUser.domCredits < dom || currentUser.btnCredits < btn || currentUser.intCredits < int) {
        showToast('Insufficient Resource Allocation in your Hub! ❌', 'error');
        return;
      }

      // Subtract from current user
      const updatedCurrentUser = {
        ...currentUser,
        domCredits: currentUser.domCredits - dom,
        btnCredits: currentUser.btnCredits - btn,
        intCredits: currentUser.intCredits - int
      };
      setCurrentUser(updatedCurrentUser);
      setUsers(prev => prev.map(u => u.id === currentUser.id ? updatedCurrentUser : u));
    }
    
    const oneYearFromNow = new Date();
    oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() + 1);

    const user: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: newUser.name || '',
      username: (newUser.username || '').trim(),
      password: newUser.password || '',
      mobile: newUser.mobile || '',
      email: newUser.email || '',
      role: newUser.role as any || 'User',
      status: 'Active',
      location: newUser.location || 'Delhi',
      uplink: currentUser.role === 'Admin' ? 'admin' : currentUser.id,
      domCredits: newUser.domCredits || 0,
      intCredits: newUser.intCredits || 0,
      btnCredits: newUser.btnCredits || 0,
      cuttingPercentage: newUser.cuttingPercentage || '0',
      createdAt: new Date().toISOString(),
      planExpiryDate: oneYearFromNow.toISOString(),
      campaignApproved: true
    };
    
    setUsers(prev => [user, ...prev]);
    setIsAddUserModalOpen(false);
    showToast(`User ${user.name} added successfully`);
    setNewUser({
      name: '',
      username: '',
      password: '',
      mobile: '',
      email: '',
      role: 'User',
      status: 'Active',
      location: 'Delhi',
      domCredits: 0,
      intCredits: 0,
      btnCredits: 0,
      cuttingPercentage: '0'
    });
  };

  const handleDeleteUser = (user: User) => {
    if (user.status === 'Deleted') {
      // Permanent delete
      setUsers(prev => prev.filter(u => u.id !== user.id));
      showToast('User permanently deleted', 'error');
    } else {
      // Move to deleted status
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, status: 'Deleted' } : u));
      showToast('User moved to trash', 'warning');
    }
  };

  // Non Whatsapp & Whitelisting State
  const [searchNumber, setSearchNumber] = useState('');
  const [searchOption, setSearchOption] = useState<'Domestic' | 'International'>('Domestic');
  const [searchCountry, setSearchCountry] = useState('+91 India');

  // Reset search country & selection when switching between Domestic/International
  useEffect(() => {
    if (searchOption === 'International') {
      if (searchCountry.includes('India')) {
        setSearchCountry('+62 Indonesia');
      }
    } else {
      setSearchCountry('+91 India');
    }
  }, [searchOption]);

  useEffect(() => {
    if (campaignOption === 'International') {
      if (selectedCountry === 'India') {
        setSelectedCountry('Indonesia');
      }
    } else {
      setSelectedCountry('India');
    }
  }, [campaignOption]);

  useEffect(() => {
    if (btnCampaignOption === 'International') {
      if (btnSelectedCountry === 'India') {
        setBtnSelectedCountry('Indonesia');
      }
    } else {
      setBtnSelectedCountry('India');
    }
  }, [btnCampaignOption]);

  // Campaign Config State
  const [configTab, setConfigTab] = useState<'General' | 'Domestic' | 'International' | 'Button'>('General');
  const [isUpdateConfigModalOpen, setIsUpdateConfigModalOpen] = useState(false);

  const [domesticMessages, setDomesticMessages] = useState({
    maxAllowed: '15 Campaign allowed in a day. Please try tomorrow.',
    limitExceeded: 'Your daily limit is exceeded...'
  });

  const [internationalMessages, setInternationalMessages] = useState({
    maxAllowed: '15 Campaign allowed in a day. Please try tomorrow.',
    limitExceeded: 'Your daily limit is exceeded...'
  });

  const [buttonMessages, setButtonMessages] = useState({
    maxAllowed: '15 Button Campaign allowed in a day. Please try tomorrow.',
    limitExceeded: 'Your daily Button Campaign limit is exceeded...'
  });

  // Private Sender State
  const [privateSenderSession, setPrivateSenderSession] = useState<any>(null);
  const [privateSenderQr, setPrivateSenderQr] = useState<string | null>(null);
  const [privateSenderLoading, setPrivateSenderLoading] = useState(false);
  const [privateSenderMessages, setPrivateSenderMessages] = useState<PrivateSenderMessage[]>([]);
  const [privateSenderTo, setPrivateSenderTo] = useState('');
  const [privateSenderCampaignName, setPrivateSenderCampaignName] = useState('');
  const [privateSenderSelectedCampaign, setPrivateSenderSelectedCampaign] = useState<string | null>(null);
  const [privateSenderMsg, setPrivateSenderMsg] = useState('');
  const [privateSenderMode, setPrivateSenderMode] = useState<'normal' | 'dynamic'>('normal');
  const [showDynamicPreviewModal, setShowDynamicPreviewModal] = useState(false);
  const [privateSenderFile, setPrivateSenderFile] = useState<UploadedFile | null>(null);
  const [privateSenderDpLoading, setPrivateSenderDpLoading] = useState(false);
  const [isPrivateSenderSubscribing, setIsPrivateSenderSubscribing] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState({ name: 'Standard', price: 2999, duration: 1, unit: 'month' });
  const [showPrivateSenderReports, setShowPrivateSenderReports] = useState(false);

  useEffect(() => {
    if (currentPage !== 'Private Sender') {
      setShowPrivateSenderReports(false);
    }
  }, [currentPage]);

  const downloadPrivateSenderCampaignCSV = (campaignName: string | null) => {
    const filtered = privateSenderMessages.filter(m => 
      campaignName ? (m.campaignName || 'Quick Sends') === campaignName : true
    );

    if (filtered.length === 0) {
      showToast('No logs to download!', 'error');
      return;
    }

    // Define headers
    const headers = ['Sr. No.', 'Recipient', 'Status', 'Timestamp', 'Date', 'Time (Kolkata)', 'Message', 'Campaign Name'];
    
    const csvRows = [headers.join(',')];
    filtered.forEach((msg, index) => {
      const dStr = new Date(msg.timestamp).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' });
      const tStr = new Date(msg.timestamp).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: true });
      
      const row = [
        index + 1,
        `"${(msg.to || '').replace(/"/g, '""')}"`,
        `"${(msg.status || '').replace(/"/g, '""')}"`,
        msg.timestamp || '',
        `"${dStr}"`,
        `"${tStr}"`,
        `"${(msg.text || 'Media Message').replace(/"/g, '""')}"`,
        `"${(msg.campaignName || 'Quick Sends').replace(/"/g, '""')}"`
      ];
      csvRows.push(row.join(','));
    });

    const csvString = csvRows.join('\r\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    const fileName = campaignName 
      ? `Campaign_Report_${campaignName.replace(/[^a-zA-Z0-9]/g, '_')}.csv` 
      : 'Transmission_Ledger_All.csv';
    link.setAttribute("download", fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('Report Downloaded Successfully! 📥', 'success');
  };

  const deletePrivateSenderCampaign = async (campaignName: string) => {
    if (!privateSenderSession) {
      showToast('No active WhatsApp sender session connected.', 'error');
      return;
    }
    let confirmed = true;
    try {
      confirmed = window.confirm(`Are you sure you want to delete all reports for campaign "${campaignName}"? This action cannot be undone.`);
    } catch (e) {
      console.warn('window.confirm is restricted in this sandboxed environment.', e);
    }
    if (!confirmed) {
      return;
    }
    try {
      const res = await safeFetchJson(`${PRIVATE_SENDER_API_BASE}/delete-campaign`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          sessionId: privateSenderSession.id,
          campaignName
        })
      });
      if (res && Array.isArray(res.messages)) {
        setPrivateSenderMessages(res.messages);
      } else {
        const d = await safeFetchJson(`${PRIVATE_SENDER_API_BASE}/status`);
        if (d && Array.isArray(d.sessions)) {
          const s = d.sessions.find((sess: any) => sess.id === privateSenderSession.id);
          if (s) setPrivateSenderMessages(s.messages || []);
        }
      }
      showToast(`Campaign "${campaignName}" logs deleted successfully! 🗑️`, 'success');
      if (privateSenderSelectedCampaign === campaignName) {
        setPrivateSenderSelectedCampaign(null);
      }
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Failed to delete campaign reports.', 'error');
    }
  };

  const downloadPrivateSenderSampleCSV = () => {
    const content = "Phone,Name,Amount,Status\n919999999999,Rajesh,1500,due tomorrow\n918888888888,John,2500,due today\n917777777777,Amit,3200,paid";
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", "dynamic_recipients_sample.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Sample dynamic CSV downloaded! 📥", "success");
  };

  const handlePrivateSenderCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split('\n')
        .map(line => line.trim())
        .filter(line => line.length > 0);
      
      // Let's check if the first line is header (usually contains "phone" or "name")
      let sliceStart = 0;
      if (lines.length > 0) {
        const firstLineLower = lines[0].toLowerCase();
        if (firstLineLower.includes('phone') || firstLineLower.includes('name') || firstLineLower.includes('mobile') || firstLineLower.includes('var')) {
          sliceStart = 1; // skip header line
        }
      }
      
      const cleanedText = lines.slice(sliceStart).join('\n');
      setPrivateSenderTo(cleanedText);
      showToast(`Loaded ${cleanedText.split('\n').filter(Boolean).length} dynamic rows successfully! 🚀` + (sliceStart > 0 ? " (Header line skipped)" : ""), 'success');
    };
    reader.readAsText(file);
  };

  const [editConfig, setEditConfig] = useState<Record<string, string>>({});
  const [editDomesticMessages, setEditDomesticMessages] = useState({
    maxAllowed: '',
    limitExceeded: ''
  });
  const [editInternationalMessages, setEditInternationalMessages] = useState({
    maxAllowed: '',
    limitExceeded: ''
  });
  const [editButtonMessages, setEditButtonMessages] = useState({
    maxAllowed: '',
    limitExceeded: ''
  });

  const handleOpenUpdateModal = () => {
    const initialValues: Record<string, string> = {};
    generalConfigs.forEach(c => {
      initialValues[c.name] = c.size;
    });
    domesticConfigs.forEach(c => {
      initialValues[c.name] = c.size;
    });
    internationalConfigs.forEach(c => {
      initialValues[c.name] = c.size;
    });
    buttonConfigs.forEach(c => {
      initialValues[c.name] = c.size;
    });
    setEditConfig(initialValues);
    setEditDomesticMessages(domesticMessages);
    setEditInternationalMessages(internationalMessages);
    setEditButtonMessages(buttonMessages);
    setIsUpdateConfigModalOpen(true);
  };

  const handleUpdateConfig = () => {
    const updatedGeneral = generalConfigs.map(c => ({
      ...c,
      size: editConfig[c.name] || c.size
    }));
    const updatedDomestic = domesticConfigs.map(c => ({
      ...c,
      size: editConfig[c.name] || c.size
    }));
    const updatedInternational = internationalConfigs.map(c => ({
      ...c,
      size: editConfig[c.name] || c.size
    }));
    const updatedButton = buttonConfigs.map(c => ({
      ...c,
      size: editConfig[c.name] || c.size
    }));
    setGeneralConfigs(updatedGeneral);
    setDomesticConfigs(updatedDomestic);
    setInternationalConfigs(updatedInternational);
    setButtonConfigs(updatedButton);
    setDomesticMessages(editDomesticMessages);
    setInternationalMessages(editInternationalMessages);
    setButtonMessages(editButtonMessages);
    setIsUpdateConfigModalOpen(false);
  };

  // Mock Database for testing status and results using props

  const handleNumberAction = (action: 'search' | 'add' | 'delete', isWhitelist: boolean) => {
    if (!searchNumber.trim()) return;
    
    // Get prefix from searchCountry state (e.g. "+91 India")
    const searchPrefix = searchCountry.split(' ')[0].replace('+', '');
    const cleanNumber = searchNumber.replace(/\D/g, '');
    
    // Prepend prefix if it's missing for international or if it's domestic (server adds 91 for 10 digits though)
    const formattedNumForStorage = cleanNumber.startsWith(searchPrefix) ? cleanNumber : searchPrefix + cleanNumber;
    
    const db = isWhitelist ? mockDb : nonWaDb;
    const setDb = isWhitelist ? setMockDb : setNonWaDb;
    const exists = db.includes(formattedNumForStorage);
    
    let status = 'Completed';
    let result = '';

    if (action === 'search') {
      result = exists ? 'Found in database' : 'Number not found in database';
      status = exists ? 'Found' : 'Not Found';
    } else if (action === 'add') {
      if (exists) {
        showToast(`Number already exists in ${isWhitelist ? 'Whitelist' : 'Non-WhatsApp'} database! ⚠️`, 'info');
        setSearchNumber('');
        return;
      }
      result = 'Added successfully';
      status = 'Success';
      setDb(prev => [...prev, formattedNumForStorage]);
    } else if (action === 'delete') {
      result = exists ? 'Deleted from database' : 'Number not found in database';
      status = exists ? 'Deleted' : 'Not Found';
      if (exists) {
        setDb(prev => prev.filter(n => n !== formattedNumForStorage));
      }
    }

    const newRecord: NumberSearchRecord = {
      id: Math.random().toString(36).substr(2, 9),
      number: '+' + formattedNumForStorage,
      status: status,
      result: result
    };

    if (isWhitelist) {
      setWhitelistRecords([newRecord, ...whitelistRecords]);
    } else {
      setNonWhatsappRecords([newRecord, ...nonWhatsappRecords]);
    }
    setSearchNumber('');
  };

  const handleBulkUpload = (file: File, isWhitelist: boolean) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const lines = text.split('\n').map(l => l.trim()).filter(l => l !== '');
      const searchPrefix = searchCountry.split(' ')[0].replace('+', '');
      
      const db = isWhitelist ? mockDb : nonWaDb;
      const uniqueNumbersSet = new Set<string>();

      lines.forEach(line => {
        // Handle CSV with multiple columns or just plain text
        const num = line.split(',')[0].replace(/\D/g, '');
        if (num.length >= 10) {
          const formatted = num.startsWith(searchPrefix) ? num : searchPrefix + num;
          uniqueNumbersSet.add(formatted);
        }
      });

      const allParsedNumbers = Array.from(uniqueNumbersSet);
      // Filter out numbers that already exist in database to prevent duplicates and load
      const newlyAddedNumbers = allParsedNumbers.filter(n => !db.includes(n));

      if (newlyAddedNumbers.length === 0) {
        if (allParsedNumbers.length > 0) {
          showToast('All numbers in this file already exist in the database! ℹ️', 'info');
        } else {
          showToast('No valid numbers found in the file! ⚠️', 'warning');
        }
        return;
      }

      const setDb = isWhitelist ? setMockDb : setNonWaDb;
      setDb(prev => {
        const newDb = [...prev];
        newlyAddedNumbers.forEach(n => {
          if (!newDb.includes(n)) newDb.push(n);
        });
        return newDb;
      });

      const newRecords: NumberSearchRecord[] = newlyAddedNumbers.map(n => ({
        id: Math.random().toString(36).substr(2, 9),
        number: '+' + n,
        status: 'Success',
        result: `Bulk Added (${newlyAddedNumbers.length} numbers)`
      }));

      if (isWhitelist) {
        setWhitelistRecords(prev => [...newRecords.slice(0, 50), ...prev]); // Show only first 50 in history to avoid lag
      } else {
        setNonWhatsappRecords(prev => [...newRecords.slice(0, 50), ...prev]);
      }
      showToast(`Successfully added ${newlyAddedNumbers.length} new numbers to database! 🚀`);
    };
    reader.readAsText(file);
  };

  const handleSendCampaign = (isButtonCampaign = false) => {
    // Expiry and Approval Verification Block
    if (currentUser.role !== 'Admin') {
      const planExpiryStr = currentUser.planExpiryDate;
      const planExpiry = planExpiryStr ? new Date(planExpiryStr) : null;
      
      if (planExpiry && planExpiry < new Date()) {
        showToast('Your user panel limit has expired (1 year limit). Please contact Admin to reactivate your plan! ❌', 'error');
        return;
      }
      
      if (currentUser.campaignApproved === false) {
        showToast('Your campaign sending privilege is not approved. Please request Admin approval. ❌', 'error');
        return;
      }
    }

    const title = isButtonCampaign ? btnCampaignTitle : campaignTitle;
    const msg = isButtonCampaign ? btnMessage : message;
    const files = isButtonCampaign ? btnMedia : [...uploadedImages, ...uploadedVideos, ...uploadedPDFs];
    const creditsToDeduct = isButtonCampaign ? btnCampaignStats.valid : campaignStats.valid;
    const option = isButtonCampaign ? btnCampaignOption : campaignOption; 

    if (!title.trim()) {
      showToast('Campaign Error: Missing Title! ❌', 'error');
      return;
    }
    
    if (title.length > 20) {
      showToast('Campaign Title must be 20 characters or less! ❌', 'error');
      return;
    }

    if (creditsToDeduct === 0) {
      showToast('No valid numbers found in the campaign! ❌', 'error');
      return;
    }

    // Check credits
    if (isButtonCampaign) {
      if (currentUser.btnCredits < creditsToDeduct) {
        showToast('Insufficient Button Credits! ❌', 'error');
        return;
      }
    } else if (option === 'Domestic') {
      if (currentUser.domCredits < creditsToDeduct) {
        showToast('Insufficient Domestic Credits! ❌', 'error');
        return;
      }
    } else if (option === 'International') {
      if (currentUser.intCredits < creditsToDeduct) {
        showToast('Insufficient International Credits! ❌', 'error');
        return;
      }
    }
    
    const numbers = isButtonCampaign ? btnMobileNumbers : mobileNumbers;
    const currentPrefix = (isButtonCampaign ? 
      countries.find(c => c.name === btnSelectedCountry)?.prefix : 
      countries.find(c => c.name === selectedCountry)?.prefix
    )?.replace('+', '') || '91';

    const processedNumbers: string[] = [];
    const seen = new Set<string>();

    numbers.split(/[\n,;:\s]+/)
      .map(l => l.trim())
      .filter(l => l !== '')
      .forEach(num => {
        let digits = num.replace(/\D/g, '');
        
        const isIndian = (digits.startsWith('91') && digits.length === 12) || (digits.length === 10 && /^[6-9]/.test(digits));
        
        // Prefix handling and strict division validation
        if (option === 'Domestic' || isButtonCampaign) {
          // Domestic Campaign: must be an Indian number
          if (!isIndian) {
            return; // Skip non-Indian numbers in domestic/button campaign
          }
          // Strip 91 if it's 12 digits to keep it as 10 digits as requested for domestic
          if (digits.startsWith('91') && digits.length === 12) {
            digits = digits.substring(2);
          }
        } else {
          // International Campaign
          const targetCountry = isButtonCampaign ? btnSelectedCountry : selectedCountry;
          if (targetCountry !== 'India' && isIndian) {
            return; // Skip Indian numbers in International campaign targeting other countries (e.g. Indonesia)
          }
          
          // International Prefixing
          // If the digits don't already start with the country prefix, prepend it
          if (!digits.startsWith(currentPrefix)) {
            digits = currentPrefix + digits;
          }
        }

        const isAllSame = digits.length >= 10 && digits.split('').every(d => d === digits[0]);
        const isValid = digits.length >= 10 && digits.length <= 15 && !isAllSame;
        
        if (isValid && !seen.has(digits)) {
          seen.add(digits);
          processedNumbers.push(digits);
        }
      });

    const isDemo = !isButtonCampaign && processedNumbers.length <= 10;
    const rawInputNumbers = numbers.split(/[\n,;:\s]+/).map(l => l.trim()).filter(l => l !== '');
    
    const newCamp: Campaign = {
      id: Math.random().toString(36).substr(2, 9),
      name: title,
      status: 'Pending',
      date: new Date().toLocaleString('en-IN', { 
        timeZone: 'Asia/Kolkata',
        year: 'numeric', 
        month: '2-digit', 
        day: '2-digit', 
        hour: '2-digit', 
        minute: '2-digit', 
        hour12: true 
      }),
      message: msg,
      files: files,
      type: isButtonCampaign ? 'Button' : (option === 'International' ? 'International' : 'Standard'),
      userId: currentUser.id,
      userName: currentUser.name,
      creditsUsed: creditsToDeduct,
      isDemo: isDemo,
      numbers: processedNumbers,
      originalNumbers: rawInputNumbers,
      sentCount: 0,
      totalCount: processedNumbers.length,
      buttonDetails: isButtonCampaign ? {
        linkText: btnLinkText,
        linkUrl: btnLinkUrl,
        callText: btnCallText,
        callNumber: btnCallNumber
      } : undefined
    };

    // Deduct credits
    const updatedUser: User = {
      ...currentUser,
      domCredits: (isButtonCampaign || option === 'International') ? currentUser.domCredits : currentUser.domCredits - creditsToDeduct,
      btnCredits: isButtonCampaign ? currentUser.btnCredits - creditsToDeduct : currentUser.btnCredits,
      intCredits: (!isButtonCampaign && option === 'International') ? currentUser.intCredits - creditsToDeduct : currentUser.intCredits
    };

    setUsers(prevUsers => prevUsers.map(u => u.id === currentUser.id ? updatedUser : u));
    setCurrentUser(updatedUser);
    setCampaigns([newCamp, ...campaigns]);
    showToast('Campaign created successfully! 🚀');

    const newTransaction: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      amount: creditsToDeduct,
      type: isButtonCampaign ? 'button' : (option === 'International' ? 'international' : 'domestic'),
      date: new Date().toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }),
      note: `Campaign created: ${title}`,
      action: 'Deducted'
    };
    setTransactions([newTransaction, ...transactions]);

    // Auto Whitelist for Demo Campaigns
    if (isDemo) {
      // Find numbers that are NOT already whitelisted to prevent duplicate database entries and logs
      // Normalize by comparing the last 10 digits
      const newlyWhitelisted = processedNumbers.filter(num => {
        const cleanNum = num.replace(/\D/g, '').slice(-10);
        return !mockDb.some(dbNum => dbNum.replace(/\D/g, '').slice(-10) === cleanNum);
      });

      if (newlyWhitelisted.length > 0) {
        setMockDb(prev => {
          const newDb = [...prev];
          newlyWhitelisted.forEach(num => {
            const formattedNum = num.startsWith(currentPrefix) ? num : currentPrefix + num;
            if (!newDb.some(dbNum => dbNum.replace(/\D/g, '').slice(-10) === formattedNum.replace(/\D/g, '').slice(-10))) {
              newDb.push(formattedNum);
            }
          });
          return newDb;
        });

        // Add to whitelist history ONLY for the newly whitelisted numbers
        const newRecords: NumberSearchRecord[] = newlyWhitelisted.map(num => {
          const formattedNum = num.startsWith(currentPrefix) ? num : currentPrefix + num;
          return {
            id: Math.random().toString(36).substr(2, 9),
            number: '+' + formattedNum,
            status: 'Success',
            result: 'Auto-whitelisted via Demo Campaign'
          };
        });
        setWhitelistRecords(prev => [...newRecords, ...prev]);
      }
    }
    
    // Reset forms
    if (isButtonCampaign) {
      setBtnCampaignTitle('');
      setBtnMessage('');
      setBtnMobileNumbers('');
      setBtnMedia([]);
    } else {
      setCampaignTitle('');
      setMessage('');
      setMobileNumbers('');
      setUploadedImages([]);
      setUploadedVideos([]);
      setUploadedPDFs([]);
    }
    
    setCurrentPage('My Campaigns');
  };

  const handleMediaUpload = async (type: 'image' | 'video' | 'pdf', file: File) => {
    try {
      const base64Url = await fileToBase64(file);
      const newFile: UploadedFile = {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        type,
        url: base64Url
      };

      if (type === 'image') {
        setUploadedImages(prev => {
          if (prev.length < 2) {
            return [...prev, newFile];
          }
          return prev;
        });
      } else if (type === 'video') {
        setUploadedVideos(prev => {
          if (prev.length < 1) {
            return [...prev, newFile];
          }
          return prev;
        });
      } else if (type === 'pdf') {
        setUploadedPDFs(prev => {
          if (prev.length < 1) {
            return [...prev, newFile];
          }
          return prev;
        });
      }
    } catch (err) {
      console.error('Failed to convert file to base64:', err);
    }
  };

  const removeFile = (id: string, type: 'image' | 'video' | 'pdf') => {
    if (type === 'image') setUploadedImages(uploadedImages.filter(f => f.id !== id));
    if (type === 'video') setUploadedVideos(uploadedVideos.filter(f => f.id !== id));
    if (type === 'pdf') setUploadedPDFs(uploadedPDFs.filter(f => f.id !== id));
  };

  const campaignStats = useMemo(() => {
    const lines = mobileNumbers.split(/[\n,;:\s]+/).map(l => l.trim()).filter(l => l !== '');
    const total = lines.length;
    const seen = new Set<string>();
    let valid = 0;
    let invalid = 0;
    let duplicates = 0;

    lines.forEach(num => {
      // Strip non-digits for validation
      let digits = num.replace(/\D/g, '');
      
      const isIndian = (digits.startsWith('91') && digits.length === 12) || (digits.length === 10 && /^[6-9]/.test(digits));
      
      if (campaignOption === 'Domestic') {
        // Must be Indian
        if (!isIndian) {
          invalid++;
          return;
        }
        // Strip 91 if it's 12 digits for consistent counting
        if (digits.startsWith('91') && digits.length === 12) {
          digits = digits.substring(2);
        }
      } else {
        // International
        if (selectedCountry !== 'India' && isIndian) {
          invalid++;
          return;
        }
      }
      
      // Check if all digits are the same (e.g., 9999999999)
      const isAllSame = digits.length >= 10 && digits.split('').every(d => d === digits[0]);
      
      // Validation criteria:
      // 1. 10 to 15 digits (to allow country codes)
      // 2. Not all same digits
      const isValid = digits.length >= 10 && digits.length <= 15 && !isAllSame;
      
      if (isValid) {
        if (seen.has(digits)) {
          duplicates++;
        } else {
          valid++;
          seen.add(digits);
        }
      } else {
        invalid++;
      }
    });

    return { total, valid, invalid, duplicates };
  }, [mobileNumbers, campaignOption, selectedCountry]);

  const btnCampaignStats = useMemo(() => {
    const lines = btnMobileNumbers.split(/[\n,;:\s]+/).map(l => l.trim()).filter(l => l !== '');
    const total = lines.length;
    const seen = new Set<string>();
    let valid = 0;
    let invalid = 0;
    let duplicates = 0;

    lines.forEach(num => {
      let digits = num.replace(/\D/g, '');
      
      const isIndian = (digits.startsWith('91') && digits.length === 12) || (digits.length === 10 && /^[6-9]/.test(digits));
      
      if (btnCampaignOption === 'Domestic') {
        if (!isIndian) {
          invalid++;
          return;
        }
        // Strip 91 if it's 12 digits for consistent counting
        if (digits.startsWith('91') && digits.length === 12) {
          digits = digits.substring(2);
        }
      } else {
        if (btnSelectedCountry !== 'India' && isIndian) {
          invalid++;
          return;
        }
      }
      
      const isAllSame = digits.length >= 10 && digits.split('').every(d => d === digits[0]);
      const isValid = digits.length >= 10 && digits.length <= 15 && !isAllSame;
      
      if (isValid) {
        if (seen.has(digits)) {
          duplicates++;
        } else {
          valid++;
          seen.add(digits);
        }
      } else {
        invalid++;
      }
    });

    return { total, valid, invalid, duplicates };
  }, [btnMobileNumbers, btnCampaignOption, btnSelectedCountry]);

  const cleanupNumbers = (isButtonCampaign = false) => {
    const numbers = isButtonCampaign ? btnMobileNumbers : mobileNumbers;
    const lines = numbers.split(/[\n,;:\s]+/).map(l => l.trim()).filter(l => l !== '');
    const seen = new Set<string>();
    const validLines: string[] = [];

    const option = isButtonCampaign ? btnCampaignOption : campaignOption;
    const targetCountry = isButtonCampaign ? btnSelectedCountry : selectedCountry;

    lines.forEach(num => {
      let digits = num.replace(/\D/g, '');
      
      const isIndian = (digits.startsWith('91') && digits.length === 12) || (digits.length === 10 && /^[6-9]/.test(digits));
      
      if (option === 'Domestic') {
        if (!isIndian) return;
        // Strip 91 if it's 12 digits to keep it as 10 digits as requested
        if (digits.startsWith('91') && digits.length === 12) {
          digits = digits.substring(2);
        }
      } else {
        if (targetCountry !== 'India' && isIndian) return;
      }

      const isAllSame = digits.length >= 10 && digits.split('').every(d => d === digits[0]);
      const isValid = digits.length >= 10 && digits.length <= 15 && !isAllSame;
      
      if (isValid && !seen.has(digits)) {
        seen.add(digits);
        validLines.push(digits);
      }
    });

    if (isButtonCampaign) {
      setBtnMobileNumbers(validLines.join('\n'));
    } else {
      setMobileNumbers(validLines.join('\n'));
    }
  };

  const isPrivateSenderActive = useMemo(() => {
    if (!currentUser) return false;
    if (currentUser.role === 'Admin') return true;
    if (currentUser.privateSenderSubscription !== 'approved') return false;
    if (!currentUser.privateSenderExpiry) return false;
    return new Date(currentUser.privateSenderExpiry) > new Date();
  }, [currentUser]);

  const menuItems = useMemo(() => {
    const adminItems: { label: Page; icon: any }[] = [
      { label: 'Dashboard', icon: LayoutDashboard },
      { label: 'Private Sender', icon: Smartphone },
      { label: 'Demo Server', icon: Server },
      { label: 'My Campaigns', icon: History },
      { label: 'Pending Campaign', icon: Clock },
      { label: 'Finished Campaign', icon: CheckCircle },
      { label: 'Create Campaign', icon: PlusCircle },
      { label: 'Create Button Campaign', icon: MousePointer2 },
      { label: 'Non Whatsapp Number', icon: PhoneOff },
      { label: 'White Listing Number', icon: ShieldCheck },
      { label: 'Campaign Config', icon: Settings },
      { label: 'User Management', icon: Users },
      { label: 'Cities', icon: MapPin },
      { label: 'Admin Staff', icon: ShieldAlert },
      { label: 'Private Subscriptions', icon: CreditCard },
      { label: 'Manage Transactions', icon: ArrowLeftRight },
      { label: 'Terms & Conditions', icon: FileText },
    ];

    const userItems: { label: Page; icon: any }[] = [
      { label: 'Dashboard', icon: LayoutDashboard },
      { label: 'Private Sender', icon: Smartphone },
      { label: 'Create Campaign', icon: Send },
      { label: 'Create Button Campaign', icon: MousePointer2 },
      { label: 'My Campaigns', icon: History },
      { label: 'Terms & Conditions', icon: FileText },
      { label: 'Manage Transactions', icon: History },
    ];

    const resellerItems: { label: Page; icon: any }[] = [
      { label: 'Dashboard', icon: LayoutDashboard },
      { label: 'Private Sender', icon: Smartphone },
      { label: 'Create Campaign', icon: Send },
      { label: 'Create Button Campaign', icon: MousePointer2 },
      { label: 'My Campaigns', icon: History },
      { label: 'Terms & Conditions', icon: FileText },
      { label: 'Manage Transactions', icon: History },
      { label: 'User Management', icon: Users },
    ];

    if (!currentUser) return [];
    if (currentUser.role === 'Admin') return adminItems;
    if (currentUser.role === 'Reseller') return resellerItems;
    return userItems;
  }, [currentUser?.role]);

  const [isAddCityModalOpen, setIsAddCityModalOpen] = useState(false);
  const [newCityName, setNewCityName] = useState('');

  const handleAddCity = () => {
    if (newCityName.trim()) {
      setCities([...cities, newCityName.trim()]);
      setNewCityName('');
      setIsAddCityModalOpen(false);
    }
  };

  const handleDeleteCity = (cityToDelete: string) => {
    setCities(cities.filter(city => city !== cityToDelete));
  };

  const [isEditAdminModalOpen, setIsEditAdminModalOpen] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<AdminStaff | null>(null);
  const [adminForm, setAdminForm] = useState({
    name: '',
    email: '',
    password: '',
    status: 'Active' as 'Active' | 'Inactive',
    accesses: {} as { [key: string]: boolean }
  });

  const handleEditAdmin = (admin: AdminStaff) => {
    setEditingAdmin(admin);
    setAdminForm({
      name: admin.name,
      email: admin.email,
      password: '',
      status: admin.status,
      accesses: { ...admin.accesses }
    });
    setIsEditAdminModalOpen(true);
  };

  const handleSaveAdmin = () => {
    if (editingAdmin) {
      setAdminStaff(adminStaff.map(a => a.id === editingAdmin.id ? {
        ...a,
        name: adminForm.name,
        email: adminForm.email,
        status: adminForm.status,
        accesses: adminForm.accesses
      } : a));
    } else {
      const newAdmin: AdminStaff = {
        id: Math.random().toString(36).substr(2, 9),
        name: adminForm.name,
        email: adminForm.email,
        status: adminForm.status,
        accesses: adminForm.accesses
      };
      setAdminStaff([...adminStaff, newAdmin]);
    }
    setIsEditAdminModalOpen(false);
  };

  const [termsContent, setTermsContent] = useState(`# WhatsApp Campaign Terms & Conditions

## WhatsApp Campaign Limitations:

1. All WhatsApp Campaigns sent may not be visible on Web WhatsApp.
2. WhatsApp Campaign may not reach iPhones all the time, due to iPhone security issues.
3. Every number sent from our Panel will show as SENT only always in reports.
4. The delivery success ratio will be approximately 60% to 80%, because 20%-40% may not get delivered or may show waiting for message, due to channel (WhatsApp number) Ban issues in WhatsApp.
5. Buttons Campaign will be allowed with 01 Media Only (01 image or 01 video or 01 PDF).
6. Buttons Campaigns are available for INDIA only.
7. Button Campaign may take a minimum of 30-240 minutes to deliver.
8. No Elections Campaigns allowed for Button Campaign.
9. Max Allowed size for image/video/pdf is 5MB each only.
10. Max up to 02 Lacs numbers can be sent in a single campaign.
11. Delivery time 02-04 Hrs.
12. Can be sent Monday to Saturday between 10 am to 06 pm IST only.
13. Max 03 Demo campaigns (less than 10 numbers) allowed in a day.
14. Max 10 campaigns allowed in a day.
15. All non-WhatsApp number credits would be refunded after 48 Hrs.

Note: Before pushing anything in bulk, please test by sending to your own 5-10 numbers to ensure everything is fine because once sent cannot be undone.`);

  const [isManagingTerms, setIsManagingTerms] = useState(false);
  const [managingCreditsUser, setManagingCreditsUser] = useState<User | null>(null);
  const [creditAmount, setCreditAmount] = useState<string>('');
  const [creditType, setCreditType] = useState<'Domestic' | 'Button' | 'International'>('Domestic');
  const [creditAction, setCreditAction] = useState<'Add' | 'Remove'>('Add');

  const handleUpdateCredits = () => {
    if (!managingCreditsUser || !creditAmount) return;
    const amount = parseInt(creditAmount);
    if (isNaN(amount)) return;

    // If reseller is adding, check their own balance
    if (currentUser.role === 'Reseller' && creditAction === 'Add') {
      if (creditType === 'Domestic' && currentUser.domCredits < amount) {
        showToast('Insufficient Domestic credits!', 'error');
        return;
      }
      if (creditType === 'Button' && currentUser.btnCredits < amount) {
        showToast('Insufficient Button credits!', 'error');
        return;
      }
      if (creditType === 'International' && currentUser.intCredits < amount) {
        showToast('Insufficient International credits!', 'error');
        return;
      }

      // Deduct from reseller
      const updatedReseller = {
        ...currentUser,
        domCredits: creditType === 'Domestic' ? currentUser.domCredits - amount : currentUser.domCredits,
        btnCredits: creditType === 'Button' ? currentUser.btnCredits - amount : currentUser.btnCredits,
        intCredits: creditType === 'International' ? currentUser.intCredits - amount : currentUser.intCredits
      };
      setUsers(prev => prev.map(u => u.id === currentUser.id ? updatedReseller : u));
      setCurrentUser(updatedReseller);
    }

    const updatedUser = {
      ...managingCreditsUser,
      domCredits: creditType === 'Domestic' 
        ? (creditAction === 'Add' ? managingCreditsUser.domCredits + amount : Math.max(0, managingCreditsUser.domCredits - amount))
        : managingCreditsUser.domCredits,
      btnCredits: creditType === 'Button'
        ? (creditAction === 'Add' ? managingCreditsUser.btnCredits + amount : Math.max(0, managingCreditsUser.btnCredits - amount))
        : managingCreditsUser.btnCredits,
      intCredits: creditType === 'International'
        ? (creditAction === 'Add' ? managingCreditsUser.intCredits + amount : Math.max(0, managingCreditsUser.intCredits - amount))
        : managingCreditsUser.intCredits
    };

    setUsers(prev => prev.map(u => u.id === managingCreditsUser.id ? updatedUser : u));
    if (currentUser.id === managingCreditsUser.id) {
      setCurrentUser(updatedUser);
    }

    const newTransaction: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      userId: managingCreditsUser.id,
      amount: amount,
      type: creditType === 'Button' ? 'button' : (creditType === 'International' ? 'international' : 'domestic'),
      date: new Date().toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }),
      note: `${creditAction === 'Add' ? 'Credits added' : 'Credits removed'} by ${currentUser.role}`,
      action: creditAction === 'Add' ? 'Added' : 'Deducted'
    };
    setTransactions([newTransaction, ...transactions]);
    showToast(`${creditAmount} ${creditType} credits ${creditAction === 'Add' ? 'added to' : 'removed from'} ${managingCreditsUser.name}`);

    setManagingCreditsUser(null);
    setCreditAmount('');
  };
  const [manageTermsTab, setManageTermsTab] = useState<'Edit' | 'Preview' | 'History'>('Edit');
  const [lastUpdatedTerms, setLastUpdatedTerms] = useState('7/3/2025 at 8:55:44 AM');
  const [termsHistory, setTermsHistory] = useState([
    { version: 2, lastUpdated: '7/3/2025 8:55:44 AM', updatedBy: 'Admin', content: '...' },
    { version: 1, lastUpdated: '4/5/2025 6:09:01 PM', updatedBy: 'System', content: '...' }
  ]);
  const [editTermsContent, setEditTermsContent] = useState(termsContent);

  const handleSaveTerms = () => {
    const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
    const dateStr = now.toLocaleDateString('en-IN') + ' at ' + now.toLocaleTimeString('en-IN', { hour12: true });
    setTermsContent(editTermsContent);
    setLastUpdatedTerms(dateStr);
    showToast('Terms & Conditions updated');
    setTermsHistory([
      { 
        version: termsHistory.length + 1, 
        lastUpdated: dateStr, 
        updatedBy: 'Admin', 
        content: editTermsContent.substring(0, 100) + '...' 
      },
      ...termsHistory
    ]);
    setIsManagingTerms(false);
  };

  const filteredUsers = useMemo(() => {
    if (!currentUser) return [];
    return (users || [])
      .filter(u => {
        if (currentUser.role === 'Admin') return true;
        // Backward compatibility for Name or ID
        return u.uplink === currentUser.id || u.uplink === currentUser.name;
      })
      .filter(u => u.status === userStatusTab)
      .filter(u => userRoleFilter === 'All' ? true : u.role === userRoleFilter)
      .filter(u => {
        const searchTerm = deferredUserSearchQuery.toLowerCase();
        return (u.name?.toLowerCase().includes(searchTerm)) || 
               (u.username?.toLowerCase().includes(searchTerm)) || 
               (u.mobile?.toLowerCase().includes(searchTerm));
      })
      .sort((a, b) => {
        if (a.role === 'Admin' && b.role !== 'Admin') return -1;
        if (a.role !== 'Admin' && b.role === 'Admin') return 1;
        return (a.name || '').localeCompare(b.name || '');
      });
  }, [users, currentUser?.id, currentUser?.name, currentUser?.role, userStatusTab, userRoleFilter, deferredUserSearchQuery]);

  const stats = useMemo(() => {
    if (!currentUser) return { total: 0, active: 0, completed: 0, pending: 0 };
    const filteredCampaigns = currentUser.role === 'Admin' 
      ? campaigns.filter(c => c.userId !== currentUser.id)
      : campaigns.filter(c => c.userId === currentUser.id);

    return {
      total: filteredCampaigns.length,
      active: filteredCampaigns.filter(c => c.status === 'Active').length,
      completed: filteredCampaigns.filter(c => c.status === 'Completed').length,
      pending: filteredCampaigns.filter(c => c.status === 'Pending').length,
    };
  }, [campaigns, currentUser?.role, currentUser?.id]);

  const activeFilteredCampaigns = useMemo(() => {
    if (!currentUser) return [];
    return campaigns.filter(c => 
      c.userId === currentUser.id && 
      c.name.toLowerCase().includes(deferredSearchQuery.toLowerCase())
    );
  }, [campaigns, currentUser?.id, deferredSearchQuery]);

  const pendingFilteredCampaigns = useMemo(() => {
    if (!currentUser) return [];
    return campaigns.filter(c => 
      c.status === 'Pending' && 
      (currentUser.role === 'Admin' || currentUser.role === 'Reseller' ? c.userId !== currentUser.id : c.userId === currentUser.id) &&
      c.name.toLowerCase().includes(deferredSearchQuery.toLowerCase())
    );
  }, [campaigns, currentUser, deferredSearchQuery]);

  const finishedFilteredCampaigns = useMemo(() => {
    if (!currentUser) return [];
    return campaigns.filter(c => 
      c.status === finishedTab && 
      (currentUser.role === 'Admin' || currentUser.role === 'Reseller' ? c.userId !== currentUser.id : c.userId === currentUser.id) &&
      c.name.toLowerCase().includes(deferredSearchQuery.toLowerCase())
    );
  }, [campaigns, currentUser, deferredSearchQuery, finishedTab]);

  interface ExpiryNotification {
    id: string;
    userId: string;
    userName: string;
    userRole: string;
    type: 'soon_expiry' | 'expired';
    daysLeft: number;
    expiryDate: string;
  }

  const systemNotifications = useMemo<ExpiryNotification[]>(() => {
    if (!currentUser || !users) return [];
    const list: ExpiryNotification[] = [];
    const now = new Date();

    if (currentUser.role === 'Admin' || currentUser.role === 'Reseller') {
      // Admin/Reseller can view alerts for all standard users/resellers
      users.forEach(u => {
        if (u.role === 'Admin') return;
        if (!u.planExpiryDate) return;

        const expiry = new Date(u.planExpiryDate);
        const diffMs = expiry.getTime() - now.getTime();
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays <= 5) {
          list.push({
            id: `expiry-${u.id}-${diffDays}`,
            userId: u.id,
            userName: u.name,
            userRole: u.role,
            type: diffDays <= 0 ? 'expired' : 'soon_expiry',
            daysLeft: diffDays,
            expiryDate: u.planExpiryDate
          });
        }
      });
    } else {
      // Normal user can only view their own subscription alerts
      if (currentUser.planExpiryDate) {
        const expiry = new Date(currentUser.planExpiryDate);
        const diffMs = expiry.getTime() - now.getTime();
        const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

        if (diffDays <= 5) {
          list.push({
            id: `expiry-self-${diffDays}`,
            userId: currentUser.id,
            userName: currentUser.name,
            userRole: currentUser.role,
            type: diffDays <= 0 ? 'expired' : 'soon_expiry',
            daysLeft: diffDays,
            expiryDate: currentUser.planExpiryDate
          });
        }
      }
    }

    return list.sort((a, b) => a.daysLeft - b.daysLeft);
  }, [users, currentUser]);

  const selectedCountryData = countries.find(c => c.name === selectedCountry) || countries[0];

  return (
    <div className="flex h-screen bg-[#fcfcfd] overflow-hidden text-slate-900">
      {/* Sidebar - Connections */}
      <aside className={`bg-slate-900 text-white transition-all duration-500 ease-in-out flex-shrink-0 overflow-y-auto overflow-x-hidden scrollbar-hide border-r border-white/10 shadow-[20px_0_60px_-15px_rgba(0,0,0,0.1)] relative z-[120] pointer-events-auto ${isSidebarOpen ? 'w-80' : 'w-0 lg:w-24'}`}>
        <div className={`flex items-center border-b border-white/5 bg-slate-950/50 backdrop-blur-md transition-all duration-500 ${isSidebarOpen ? 'p-8 gap-5 justify-start' : 'py-8 px-4 justify-center'}`}>
          <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.4)] flex-shrink-0 group">
            <Rocket size={24} className="text-white group-hover:scale-110 transition-transform" />
          </div>
          <div className={`overflow-hidden transition-all duration-500 ${isSidebarOpen ? 'max-w-[200px] opacity-100' : 'max-w-0 opacity-0'}`}>
            <span className="font-black text-lg tracking-tighter uppercase ml-1 whitespace-nowrap truncate block max-w-[170px]" title={currentUser?.name || 'Guest'}>
              {currentUser?.name || 'Guest'}
            </span>
          </div>
        </div>
        
        <div className={`py-10 space-y-2 transition-all duration-500 ${isSidebarOpen ? 'px-4' : 'px-2'}`}>
          {menuItems.map((item) => (
            <SidebarItem 
              key={item.label}
              icon={item.icon}
              label={item.label}
              active={currentPage === item.label}
              isOpen={isSidebarOpen}
              onClick={() => setCurrentPage(item.label)}
            />
          ))}
        </div>

        {/* Sidebar Footer - Removed blocking div */}
      </aside>

        {/* Global Main Terminal */}
        <main className="flex-1 flex flex-col overflow-hidden relative">
          {/* Topbar - Command Interface */}
          <header className="h-24 bg-white/80 backdrop-blur-xl border-b border-slate-100 flex items-center justify-between px-10 flex-shrink-0 z-50">
            <div className="flex items-center gap-8">
              <button 
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="w-12 h-12 bg-slate-100 hover:bg-slate-200 rounded-2xl flex items-center justify-center transition-all text-slate-600 hover:text-slate-900 group"
              >
                <Menu size={22} className="group-hover:rotate-180 transition-transform duration-500" />
              </button>
              <div className="flex flex-col">
                <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight">
                  {currentPage}
                </h2>
                <div className="flex items-center gap-2">
                   <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                   <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Active System</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-6">
              <div className="hidden xl:flex items-center gap-4 pr-6 border-r border-slate-100">
                 <div className="flex flex-col items-end">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">System Time</span>
                    <DigitalClock />
                 </div>
              </div>

              {(currentUser.role === 'Admin' || currentUser.role === 'Reseller') && (
                <div className="relative">
                  <button 
                    onClick={() => setIsNotificationOpen(!isNotificationOpen)}
                    className="w-12 h-12 bg-slate-50 hover:bg-slate-100 border border-slate-100 rounded-2xl flex items-center justify-center transition-all relative group cursor-pointer"
                  >
                    <Bell size={20} className={`${systemNotifications.length > 0 ? 'text-slate-900 animate-pulse' : 'text-slate-400'} group-hover:text-slate-900 transition-colors`} />
                    {systemNotifications.length > 0 && (
                      <>
                        <span className="absolute top-2 right-2 w-5 h-5 bg-rose-500 rounded-full border-2 border-white text-[9px] font-black text-white flex items-center justify-center shadow-lg">
                          {systemNotifications.length}
                        </span>
                      </>
                    )}
                  </button>

                  {isNotificationOpen && (
                    <div className="absolute right-0 mt-3 w-80 bg-white border border-slate-200 rounded-[1.5rem] shadow-2xl z-[150] overflow-hidden flex flex-col">
                      <div className="p-5 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                        <span className="text-[10px] font-black text-slate-900 uppercase tracking-widest">
                          Alert Panel ({systemNotifications.length})
                        </span>
                        {systemNotifications.length > 0 && (
                          <span className="w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping" />
                        )}
                      </div>
                      
                      <div className="max-h-[300px] overflow-y-auto divide-y divide-slate-100">
                        {systemNotifications.length === 0 ? (
                          <div className="p-8 text-center text-slate-400">
                            <Bell size={24} className="mx-auto mb-2 opacity-30 stroke-[1.5]" />
                            <p className="text-[9px] font-black uppercase tracking-wider">No active alerts</p>
                            <p className="text-[8px] text-slate-400 mt-1 uppercase font-bold">All user plans are secure & active</p>
                          </div>
                        ) : (
                          systemNotifications.map(notif => (
                            <div 
                              key={notif.id}
                              className={`p-4 transition-colors text-left flex gap-3 ${
                                notif.type === 'expired' ? 'bg-rose-500/5 hover:bg-rose-500/10' : 'bg-amber-500/5 hover:bg-amber-500/10'
                              }`}
                            >
                              <div className="mt-1 flex-shrink-0">
                                {notif.type === 'expired' ? (
                                  <AlertTriangle className="text-rose-500" size={14} />
                                ) : (
                                  <ShieldAlert className="text-amber-500" size={14} />
                                )}
                              </div>
                              <div className="flex-1 space-y-1">
                                <p className="text-[10px] font-black text-slate-900 uppercase tracking-tight">
                                  {notif.userName} ({notif.userRole})
                                </p>
                                <p className="text-[9px] text-slate-600 font-bold leading-normal uppercase">
                                  {notif.daysLeft <= 0 
                                    ? 'Plan subscription has EXPIRED! ❌' 
                                    : `Expires in ${notif.daysLeft} day${notif.daysLeft > 1 ? 's' : ''} (5 Days left warning) ⚠️`}
                                </p>
                                <div className="text-[8px] text-slate-400 font-bold uppercase tracking-widest flex justify-between pt-1">
                                  <span>Expiry: {new Date(notif.expiryDate).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}</span>
                                  {(currentUser.role === 'Admin' || currentUser.role === 'Reseller') && (
                                    <button
                                      onClick={() => {
                                        const oneYr = new Date();
                                        oneYr.setFullYear(oneYr.getFullYear() + 1);
                                        const updated = { 
                                          ...users.find(usr => usr.id === notif.userId)!, 
                                          planExpiryDate: oneYr.toISOString(),
                                          campaignApproved: true
                                        };
                                        setUsers(prev => prev.map(user => user.id === notif.userId ? updated : user));
                                        showToast(`Plan for ${notif.userName} successfully renewed till ${oneYr.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })} ✅`);
                                        setIsNotificationOpen(false);
                                      }}
                                      className="text-emerald-600 hover:text-emerald-700 underline font-extrabold lowercase tracking-none cursor-pointer"
                                    >
                                      Renew
                                    </button>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}
              
              <div className="flex items-center gap-4 bg-slate-50 p-2 rounded-[1.5rem] border border-slate-100 shadow-inner">
                <div className="hidden md:flex flex-col items-end px-3">
                  <span className="text-[10px] font-black text-slate-900 uppercase tracking-tight leading-none mb-1">{currentUser.name}</span>
                  <span className="text-[8px] font-black text-emerald-500 uppercase tracking-widest leading-none">{currentUser.role}</span>
                </div>
                <button 
                  onClick={() => setUserBeingEdited(currentUser)}
                  className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-white font-black text-lg shadow-xl hover:scale-105 transition-all group relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  {currentUser.name.charAt(0).toUpperCase()}
                </button>
              </div>

              <button 
                onClick={onLogout}
                className="w-12 h-12 bg-rose-500/10 hover:bg-rose-500 text-rose-500 hover:text-white rounded-2xl flex items-center justify-center transition-all border border-rose-500/20 group"
                title="Terminate Session"
              >
                <Power size={20} className="group-hover:rotate-90 transition-transform duration-500" />
              </button>
            </div>
          </header>

          {currentUser.role !== 'Admin' && (
            (() => {
              const planExpiry = currentUser.planExpiryDate ? new Date(currentUser.planExpiryDate) : null;
              const isExpired = planExpiry ? planExpiry < new Date() : false;
              const isNotApproved = currentUser.campaignApproved === false;
              
              if (isExpired) {
                return (
                  <div className="bg-rose-500 text-white font-black text-[10px] uppercase tracking-widest py-4 px-10 text-center select-none flex items-center justify-center gap-3 shadow-lg z-30">
                    <AlertTriangle size={16} className="animate-bounce flex-shrink-0" />
                    <span>Your 1-Year Panel Plan Has Expired. Please contact the administrator to renew your plan! ❌</span>
                  </div>
                );
              } else if (isNotApproved) {
                return (
                  <div className="bg-amber-500 text-white font-black text-[10px] uppercase tracking-widest py-4 px-10 text-center select-none flex items-center justify-center gap-3 shadow-lg z-30">
                    <ShieldAlert size={16} className="animate-pulse flex-shrink-0" />
                    <span>Your campaign sending privilege is pending admin approval. Please contact the administrator! ⚠️</span>
                  </div>
                );
              }
              return null;
            })()
          )}

          {/* Running Notification */}
          <RunningNotification 
            message={(generalConfigs || []).find(c => c.name === 'Running Message')?.size || 'Welcome to Campaign Pro!'} 
          />

          {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="w-full mx-auto"
            >
              {currentPage === 'Private Sender' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 animate-in fade-in duration-500">
                  <div className="px-4 flex flex-col md:flex-row md:items-center justify-between gap-6">
                     <div>
                       <h3 className="text-4xl font-black text-slate-900 tracking-tight uppercase">
                         {showPrivateSenderReports ? 'PRIVATE SENDER REPORTS' : 'PRIVATE SENDER'}
                       </h3>
                       <p className="text-slate-500 font-medium mt-1">
                         {showPrivateSenderReports 
                           ? 'Track and inspect your live and historic private campaign delivery statuses.' 
                           : 'Scan your private number and dispatch messages with high delivery rates and full logs.'}
                       </p>
                     </div>
                     <div className="flex items-center justify-center gap-4">
                        {showPrivateSenderReports ? (
                          <button 
                            onClick={() => {
                              setShowPrivateSenderReports(false);
                              setPrivateSenderSelectedCampaign(null);
                            }}
                            className="flex items-center justify-center gap-3 bg-slate-900 text-white font-black text-xs uppercase tracking-[0.2em] px-8 py-4 rounded-2xl shadow-[0_20px_50px_rgba(15,23,42,0.2)] hover:bg-black transition-all transform active:scale-95 cursor-pointer"
                          >
                            <ArrowLeft size={18} />
                            BACK TO SENDER
                          </button>
                        ) : (
                          <>
                            {isPrivateSenderActive && (
                              <button 
                                onClick={() => setShowPrivateSenderReports(true)}
                                className="flex items-center justify-center gap-3 bg-emerald-600 text-white font-black text-xs uppercase tracking-[0.2em] px-8 py-4 rounded-2xl shadow-[0_20px_50px_rgba(16,185,129,0.2)] hover:bg-emerald-700 transition-all transform active:scale-95 cursor-pointer"
                              >
                                <FileText size={18} />
                                REPORT
                              </button>
                            )}
                            {!isPrivateSenderActive && (
                              currentUser.privateSenderSubscription === 'pending' ? (
                                <span className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-2xl text-[9px] font-black text-amber-600 bg-white/60 border border-white/85 uppercase tracking-[0.15em] shadow-sm animate-pulse">
                                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                                  Awaiting Admin Approval ⏳
                                </span>
                              ) : (
                                <button 
                                  onClick={() => setIsPrivateSenderSubscribing(true)}
                                  className="bg-slate-900 text-white text-[10px] font-black uppercase tracking-[0.2em] px-10 py-5 rounded-[2rem] hover:scale-105 transition-all shadow-2xl active:scale-95 flex items-center gap-2"
                                >
                                  <CreditCard size={16} />
                                  Buy Subscription
                                </button>
                              )
                            )}
                          </>
                        )}
                     </div>
                  </div>

                  {!isPrivateSenderActive ? (
                    <div className="px-4">
                      <div className="glass rounded-[3rem] p-16 lg:p-20 text-center flex flex-col items-center gap-10 border border-white/40 shadow-2xl bg-white/10 backdrop-blur-md">
                        <div className="w-24 h-24 bg-amber-500/10 text-amber-500 rounded-[2rem] flex items-center justify-center shadow-inner border border-amber-500/20">
                          {currentUser.privateSenderSubscription === 'pending' ? (
                            <Clock className="animate-pulse" size={44} />
                          ) : (
                            <Lock size={44} />
                          )}
                        </div>
                        <div className="space-y-4">
                          <h4 className="text-3xl font-black text-slate-900 uppercase tracking-tight">
                            {currentUser.privateSenderSubscription === 'pending'
                              ? 'AWAITING_INITIALIZATION: APPROVAL_REQUIRED'
                              : currentUser.privateSenderExpiry 
                                ? 'DECRYPT_FAILURE: SESSION_EXPIRED' 
                                : 'ENCRYPTION_LOCKED: PAYWALL_ACTIVE'}
                          </h4>
                          <p className="text-slate-500 max-w-lg mx-auto font-semibold text-sm leading-relaxed">
                            {currentUser.privateSenderSubscription === 'pending'
                              ? "Your premium private subscription request has been submitted to the Administrator. Once approved, your Private Messaging Hub will go live immediately. Thank you for your patience."
                              : currentUser.privateSenderExpiry 
                                ? `Your subscription expired on ${new Date(currentUser.privateSenderExpiry).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}. Renew your subscription to restore your private transmission channel.`
                                : "To activate the Private Sender, a subscription is required. This establishes a dedicated connection for unmetered messaging."}
                          </p>
                        </div>
                        {currentUser.privateSenderSubscription !== 'pending' && (
                          <button 
                            onClick={() => setIsPrivateSenderSubscribing(true)}
                            className="bg-slate-900 hover:scale-105 text-white font-black px-12 py-5 rounded-[2rem] shadow-2xl transition-all active:scale-95 uppercase text-[10px] tracking-[0.2em] flex items-center gap-2"
                          >
                            {currentUser.privateSenderExpiry ? 'Initialize Renewal' : 'Authorize Access'}
                          </button>
                        )}
                      </div>
                    </div>
                  ) : (
                    <>
                      {!showPrivateSenderReports ? (
                        <>
                          {/* Server Stats */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4 animate-in fade-in duration-500">
                         <div className="glass p-10 rounded-[2.5rem] border border-white/40 shadow-2xl flex flex-col gap-6 relative overflow-hidden group">
                            <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity"><Activity size={80} /></div>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Core Status</span>
                            <div className="flex items-center gap-4">
                               <div className={`w-4 h-4 rounded-full shadow-[0_0_15px] ${privateSenderSession?.status === 'open' ? 'bg-emerald-500 shadow-emerald-500/50' : 'bg-rose-500 shadow-rose-500/50 animate-pulse'}`} />
                               <span className="text-3xl font-black text-slate-900 uppercase tracking-tighter">
                                 {privateSenderSession?.status === 'open' ? 'Online' : privateSenderSession?.status === 'connecting' ? 'Linking...' : 'Disconnected'}
                               </span>
                            </div>
                         </div>
                         <div className="glass p-10 rounded-[2.5rem] border border-white/40 shadow-2xl flex flex-col gap-6">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Synced</span>
                            <span className="text-5xl font-black text-slate-900 tracking-tighter">
                              {privateSenderSession?.status === 'open' ? 1 : 0}
                            </span>
                         </div>
                         <div className="glass p-10 rounded-[2.5rem] border border-white/40 shadow-2xl flex flex-col gap-6">
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Processor Load</span>
                            <span className="text-5xl font-black text-slate-900 tracking-tighter">18%</span>
                         </div>
                      </div>

                      {/* Add Private Sender Card block (retains the "Add number" or Connected session options in the exact Image 1 layout) */}
                      <div className="glass rounded-[3rem] border border-white/40 shadow-2xl overflow-hidden mx-4">
                        <div className="p-10 lg:p-12 space-y-10">
                           <div className="flex items-center justify-between">
                              <h4 className="text-2xl font-black text-slate-900 uppercase tracking-tight">ADD SENDER</h4>
                              <div className="px-4 py-1.5 bg-slate-900 rounded-full text-[9px] font-black text-white uppercase tracking-widest">
                                {privateSenderSession?.status === 'open' ? 1 : 0} Registered
                              </div>
                           </div>

                           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                             {/* If session exists, we render its card */}
                             {privateSenderSession && (
                               <div className="bg-white/40 border-2 border-white/80 rounded-[2.5rem] p-8 hover:bg-white transition-all group relative overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1">
                                 <div className="flex items-start justify-between mb-8">
                                   <div className="w-14 h-14 rounded-2xl bg-slate-900 text-white flex items-center justify-center overflow-hidden shadow-2xl transition-colors">
                                     {privateSenderSession.profilePic ? (
                                       <img 
                                         src={privateSenderSession.profilePic} 
                                         alt="Profile" 
                                         className="w-full h-full object-cover" 
                                         referrerPolicy="no-referrer"
                                       />
                                     ) : (
                                       <Smartphone size={28} />
                                     )}
                                   </div>
                                   <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm ${
                                     privateSenderSession.status === 'open' ? 'bg-emerald-500 text-white' : 
                                     privateSenderSession.status === 'close' ? 'bg-rose-500 text-white' : 'bg-amber-500 text-white'
                                   }`}>
                                     {privateSenderSession.status === 'open' ? 'Connected' : privateSenderSession.status}
                                   </span>
                                 </div>
                                 
                                 <div className="mb-10">
                                   <h5 className="font-black text-slate-900 text-lg uppercase tracking-tight mb-1">
                                     {`Private-${currentUser.name}`}
                                   </h5>
                                   <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">
                                     {privateSenderSession.user?.id?.split(':')[0] || 'Unlinked'}
                                   </p>
                                   {privateSenderSession.isRestricted && (
                                     <div className="mt-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl text-[10px] font-bold leading-normal uppercase select-none flex items-start gap-2">
                                       <ShieldAlert size={14} className="flex-shrink-0 mt-0.5" />
                                       <span>Sender Restricted (463): WhatsApp rate-limited or blocked new message actions using this account.</span>
                                     </div>
                                   )}
                                 </div>

                                 <div className="flex flex-col gap-3">
                                   <div className="flex items-center gap-3">
                                     <button 
                                       onClick={() => {
                                         setSelectedChannelForMessage({
                                           id: privateSenderSession.id,
                                           name: privateSenderSession.name || 'Private Sender',
                                           number: privateSenderSession.number || '',
                                           status: privateSenderSession.status === 'open' ? 'Connected' : 'Disconnected',
                                           isRestricted: privateSenderSession.isRestricted
                                         } as any);
                                         setTestMessage({
                                           number: '',
                                           text: 'Test message transmission from private console! Connected successfully. ✅',
                                           files: []
                                         });
                                         setIsSendMessageModalOpen(true);
                                         return;
                                         const testTo = '';
                                         if (!testTo) return;
                                         
                                         setPrivateSenderLoading(true);
                                         safeFetchJson(`${PRIVATE_SENDER_API_BASE}/send`, {
                                           method: 'POST',
                                           headers: { 'Content-Type': 'application/json' },
                                           body: JSON.stringify({
                                             id: privateSenderSession.id,
                                             to: testTo.trim(),
                                             sessionId: privateSenderSession.id, message: 'Test message transmission from private console! Connected successfully. ✅'
                                           })
                                         }).then(() => {
                                           showToast('Test message dispatched successfully! ✅', 'success');
                                         }).catch((err) => {
                                           console.error(err);
                                           showToast(err.message || 'Failed to dispatch test transmission. ❌', 'error');
                                         }).finally(() => {
                                           setPrivateSenderLoading(false);
                                         });
                                       }}
                                       className="flex-1 bg-slate-900 hover:bg-black text-white text-[10px] font-black uppercase tracking-[0.2em] py-4 rounded-2xl transition-all shadow-xl active:scale-95 cursor-pointer"
                                     >
                                       Test Link
                                     </button>
                                     <button 
                                       onClick={async () => {
                                         const sid = privateSenderSession?.id || `private_${currentUser.id}`;
                                         try {
                                           await safeFetchJson(`${PRIVATE_SENDER_API_BASE}/logout`, { 
                                             method: 'POST',
                                             headers: { 'Content-Type': 'application/json' },
                                             body: JSON.stringify({ sessionId: sid })
                                           });
                                           showToast('Session deactivated.', 'info');
                                           setPrivateSenderSession(null);
                                           setPrivateSenderQr(null);
                                         } catch (e) {
                                           console.error(e);
                                           showToast('Deactivation request failed', 'error');
                                         }
                                       }}
                                       className="w-14 h-14 flex items-center justify-center rounded-2xl bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white transition-all shrink-0 cursor-pointer"
                                     >
                                       <Trash2 size={18} />
                                     </button>
                                   </div>
                                   
                                   <label className="flex items-center justify-center gap-2 py-3 border border-dashed border-indigo-500/30 bg-white/20 rounded-xl cursor-pointer hover:bg-white/50 hover:border-indigo-500/50 transition-all text-[9.5px] font-black uppercase tracking-[0.05em] text-indigo-600 mt-2">
                                     <input 
                                       type="file" 
                                       className="hidden" 
                                       accept="image/*"
                                       disabled={privateSenderDpLoading}
                                       onChange={(e) => {
                                         const file = e.target.files?.[0];
                                         if (!file) return;
                                         
                                         const reader = new FileReader();
                                         reader.onload = async (event) => {
                                           const base64 = event.target?.result as string;
                                           setPrivateSenderDpLoading(true);
                                           try {
                                             const res = await safeFetchJson(`${PRIVATE_SENDER_API_BASE}/update-dp`, {
                                               method: 'POST',
                                               headers: { 'Content-Type': 'application/json' },
                                               body: JSON.stringify({ 
                                                 sessionId: privateSenderSession.id, 
                                                 imageData: base64 
                                               })
                                             });
                                             if (res.success) {
                                               showToast('WhatsApp Profile Picture Updated! ✅', 'success');
                                             }
                                           } catch (error) {
                                             console.error('DP Update failed:', error);
                                             showToast('Failed to update DP ❌', 'error');
                                           } finally {
                                             setPrivateSenderDpLoading(false);
                                           }
                                         };
                                         reader.readAsDataURL(file);
                                       }}
                                     />
                                     {privateSenderDpLoading ? <RefreshCw className="animate-spin" size={12} /> : <ImageIcon size={12} />}
                                     {privateSenderDpLoading ? 'Updating DP...' : 'Change DP'}
                                   </label>
                                 </div>
                               </div>
                             )}

                             {/* QR Scanning Card inside the grid */}
                             {privateSenderQr && privateSenderSession?.status !== 'open' && (
                               <div className="bg-white border-2 border-emerald-500/20 rounded-[2.5rem] p-8 hover:bg-white transition-all group relative overflow-hidden shadow-md text-center flex flex-col items-center gap-4">
                                 <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest flex items-center gap-1.5">
                                   <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                   QR Payload Active
                                 </span>
                                 <div className="bg-white/90 p-3 rounded-2xl border flex items-center justify-center shadow-inner">
                                   <img src={privateSenderQr} alt="QR Code" className="w-48 h-48 object-contain" />
                                 </div>
                                 <p className="text-[9px] font-black uppercase tracking-wider text-slate-500 leading-normal">
                                   Scan this QR code in WhatsApp Linked Devices to associate your private number.
                                 </p>
                                 <button 
                                   onClick={async () => {
                                     try {
                                       await safeFetchJson(`${PRIVATE_SENDER_API_BASE}/logout`, { 
                                         method: 'POST',
                                         headers: { 'Content-Type': 'application/json' },
                                         body: JSON.stringify({ sessionId: privateSenderSession?.id || `private_${currentUser.id}` })
                                       });
                                       setPrivateSenderSession(null);
                                       setPrivateSenderQr(null);
                                       showToast('QR Cancelled.', 'info');
                                     } catch (e) { console.error(e); }
                                   }}
                                   className="mt-2 bg-rose-500 hover:bg-rose-600 text-white text-[9px] font-black uppercase tracking-[0.2em] px-6 py-3 rounded-xl shadow transition-all active:scale-95 cursor-pointer"
                                 >
                                   Cancel & Reset
                                 </button>
                               </div>
                             )}

                             {/* If no session, show ADD NUMBER card */}
                             {!privateSenderQr && (!privateSenderSession || privateSenderSession.status !== 'open') && (
                               <button 
                                 onClick={async () => {
                                   setPrivateSenderLoading(true);
                                   try {
                                     const id = `private_${currentUser.id}`;
                                     await safeFetchJson(`${PRIVATE_SENDER_API_BASE}/create`, {
                                       method: 'POST',
                                       headers: { 'Content-Type': 'application/json' },
                                       body: JSON.stringify({ id, name: `Private-${currentUser.name}` })
                                     });
                                     showToast('Generating WhatsApp QR Code... ⏳', 'info');
                                   } catch (e) { 
                                     console.error(e);
                                     showToast('Failed to generate session QR.', 'error');
                                   } finally {
                                     setPrivateSenderLoading(false);
                                   }
                                 }}
                                 disabled={privateSenderLoading}
                                 className="border-4 border-dashed border-slate-900/5 rounded-[2.5rem] p-10 flex flex-col items-center justify-center gap-4 hover:border-emerald-500/20 hover:bg-emerald-500/5 transition-all group min-h-[280px] cursor-pointer"
                               >
                                 <div className="w-16 h-16 rounded-2xl bg-white shadow-xl flex items-center justify-center text-slate-300 group-hover:text-emerald-500 transition-all duration-500 group-hover:rotate-90">
                                   {privateSenderLoading ? (
                                     <RefreshCw size={32} className="animate-spin text-emerald-500" />
                                   ) : (
                                     <PlusCircle size={32} />
                                   )}
                                 </div>
                                 <span className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] group-hover:text-emerald-600 transition-colors">
                                   {privateSenderLoading ? 'Generating...' : 'add number'}
                                 </span>
                               </button>
                             )}
                           </div>
                        </div>
                      </div>

                      {/* Campaign Dispatcher / Send Section with Dark Background (identical style to API Section) */}
                      <div className="mx-4 bg-slate-900 rounded-[3rem] shadow-[0_40px_100px_rgba(0,0,0,0.3)] border border-white/5 p-12 lg:p-20 overflow-hidden relative group">
                         <div className="absolute -top-24 -right-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-[120px] group-hover:bg-emerald-500/20 transition-all duration-700" />
                         
                         <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
                            <div className="space-y-10">
                               {privateSenderMode === 'dynamic' ? (
                                 <div className="space-y-6 w-full">
                                   <div className="flex items-center gap-4 border-b border-white/5 pb-4">
                                     <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                                       <Eye size={22} />
                                     </div>
                                     <div>
                                       <h4 className="text-xl font-black text-white uppercase tracking-wider">Dynamic Preview (First 3 Messages)</h4>
                                       <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">Simulated on-the-fly variables mapping</p>
                                     </div>
                                   </div>

                                   {(() => {
                                     const lines = privateSenderTo.split('\n').map(l => l.trim()).filter(l => l);
                                     const previews: { to: string; message: string }[] = [];
                                     
                                     for (const line of lines.slice(0, 3)) {
                                       const parts = line.split(',').map(p => p.trim());
                                       const to = parts[0];
                                       if (!to) continue;
                                       
                                       let finalMsg = privateSenderMsg || '';
                                       for (let idx = 1; idx < parts.length; idx++) {
                                         finalMsg = finalMsg.replaceAll(`{${idx}}`, parts[idx]);
                                       }
                                       previews.push({ to, message: finalMsg });
                                     }

                                     if (previews.length > 0) {
                                       return (
                                         <div className="space-y-4">
                                           {previews.map((prev, i) => (
                                             <div key={i} className="bg-black/40 border border-white/5 rounded-2xl p-5 space-y-3 relative overflow-hidden group/card hover:border-emerald-500/20 transition-all duration-300">
                                               <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-wider text-slate-400">
                                                 <span className="flex items-center gap-2">
                                                   <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                                                   Preview #{i + 1}
                                                 </span>
                                                 <span className="font-mono text-emerald-400 bg-emerald-500/5 px-2.5 py-0.5 rounded border border-emerald-500/10 text-[9px]">{prev.to}</span>
                                               </div>
                                               <div className="bg-slate-950/80 border border-white/5 rounded-xl p-4 text-xs text-slate-300 font-semibold leading-relaxed font-mono whitespace-pre-wrap">
                                                 {prev.message || <span className="text-slate-600 italic">No message content filled yet.</span>}
                                               </div>
                                             </div>
                                           ))}
                                         </div>
                                       );
                                     } else {
                                       return (
                                         <div className="border border-dashed border-white/10 rounded-[2rem] p-10 flex flex-col items-center justify-center text-center gap-3 bg-black/20 min-h-[250px]">
                                           <Sparkles size={32} className="text-slate-600 animate-pulse" />
                                           <h5 className="text-xs font-black text-slate-400 uppercase tracking-widest">Awaiting Payload Details</h5>
                                           <p className="text-[10px] text-slate-500 max-w-xs leading-relaxed font-semibold italic">
                                             "Please fill in your recipient variables on the right and type your custom message with '{1}', '{2}' template formatting to generate live message previews!"
                                           </p>
                                         </div>
                                       );
                                     }
                                   })()}
                                 </div>
                               ) : (
                                 <>
                                   <div className="flex items-center gap-5">
                                      <div className="w-14 h-14 bg-emerald-500 rounded-2xl flex items-center justify-center text-white shadow-[0_10px_30px_rgba(16,185,129,0.3)]">
                                        <Rocket size={24} />
                                      </div>
                                      <h4 className="text-3xl font-black text-white uppercase tracking-tight">Campaign Dispatcher</h4>
                                   </div>
                                   <p className="text-slate-400 font-medium text-sm leading-relaxed max-w-lg italic">
                                      "Compose and send high delivery premium transmissions directly to your contacts from your connected WhatsApp account with automated logging."
                                   </p>
                                   <div className="space-y-6">
                                      <div className="flex items-center gap-4">
                                         <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                                         <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">End-to-end secure transmission</span>
                                      </div>
                                      <div className="flex items-center gap-4">
                                         <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                                         <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">High speed instant delivery</span>
                                      </div>
                                      <div className="flex items-center gap-4">
                                         <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                                         <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Unmetered Private Senders</span>
                                      </div>
                                   </div>
                                 </>
                               )}
                            </div>

                             {/* Dispatch Form in premium dark theme */}
                             <div className="space-y-6 w-full">
                               {/* Mode Selector (Normal / Dynamic Buttons) */}
                               <div className="flex bg-black/60 p-1.5 rounded-2xl border border-white/5 relative">
                                 <button 
                                   type="button"
                                   onClick={() => setPrivateSenderMode('normal')}
                                   className={`flex-1 py-3 text-[10px] font-black uppercase tracking-[0.2em] rounded-xl transition-all duration-300 cursor-pointer ${
                                     privateSenderMode === 'normal' 
                                       ? 'bg-slate-850 text-emerald-400 font-black shadow-[0_5px_15px_rgba(16,185,129,0.15)] border border-emerald-500/20' 
                                       : 'text-slate-400 hover:text-white'
                                   }`}
                                 >
                                   Normal Mode
                                 </button>
                                 <button 
                                   type="button"
                                   onClick={() => setPrivateSenderMode('dynamic')}
                                   className={`flex-1 py-3 text-[10px] font-black uppercase tracking-[0.2em] rounded-xl transition-all duration-300 cursor-pointer ${
                                     privateSenderMode === 'dynamic' 
                                       ? 'bg-slate-850 text-emerald-400 font-black shadow-[0_5px_15px_rgba(16,185,129,0.15)] border border-emerald-500/20' 
                                       : 'text-slate-400 hover:text-white'
                                   }`}
                                 >
                                   Dynamic Mode
                                 </button>
                               </div>

                               <div className="space-y-2">
                                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Account Handler / Codename</label>
                                  <input 
                                    type="text" 
                                    placeholder="e.g. PRIVATE_COMMAND_CAMPAIGN"
                                    value={privateSenderCampaignName || ''}
                                    onChange={(e) => setPrivateSenderCampaignName(e.target.value)}
                                    className="w-full bg-black/60 border border-white/10 rounded-2xl px-6 py-4.5 text-xs font-bold text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all shadow-inner font-sans"
                                  />
                               </div>

                               <div className="space-y-2">
                                  <div className="flex justify-between items-center px-1">
                                     <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                       {privateSenderMode === 'dynamic' ? 'Dynamic Recipients (phone, var1, var2...)' : 'Target Recipients'}
                                     </label>
                                     <span className="text-[10px] font-black text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full uppercase tracking-widest shadow-sm">
                                       {privateSenderMode === 'dynamic' 
                                         ? `${privateSenderTo.split('\n').map(r => r.trim()).filter(r => r).length} / 500 Lines`
                                         : `${privateSenderTo.split(/[\n,]/).map(r => r.trim()).filter(r => r).length} / 500 Detected`
                                       }
                                     </span>
                                  </div>
                                  <textarea 
                                    placeholder={privateSenderMode === 'dynamic' 
                                      ? "91XXXXXXXXXX, Rajesh, 1500, due tomorrow\n91XXXXXXXXXX, John, 2500, due today" 
                                      : "91XXXXXXXXXX, 91XXXXXXXXXX (One per line or comma separated)"
                                    }
                                    rows={3}
                                    value={privateSenderTo || ''}
                                    onChange={(e) => setPrivateSenderTo(e.target.value)}
                                    className="w-full bg-black/60 border border-white/10 rounded-[1.5rem] px-6 py-4.5 text-xs font-mono text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all shadow-inner resize-none"
                                  />
                                  
                                  {/* Dynamic CSV download / upload options */}
                                  {privateSenderMode === 'dynamic' && (
                                    <div className="flex gap-2.5 mt-2 px-1">
                                      <button
                                        type="button"
                                        onClick={downloadPrivateSenderSampleCSV}
                                        className="flex-1 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 text-[9px] font-black uppercase tracking-widest py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer duration-200"
                                      >
                                        <Download size={11} />
                                        Sample CSV File
                                      </button>
                                      <label
                                        className="flex-1 bg-blue-550/10 hover:bg-blue-550/20 text-blue-400 border border-blue-500/20 text-[9px] font-black uppercase tracking-widest py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer text-center duration-200"
                                      >
                                        <Upload size={11} />
                                        Upload Dynamic File
                                        <input
                                          type="file"
                                          accept=".csv,.txt"
                                          className="hidden"
                                          onChange={handlePrivateSenderCSVUpload}
                                        />
                                      </label>
                                    </div>
                                  )}

                                  <p className="text-[8px] font-bold text-slate-500 italic px-2 uppercase tracking-wider block mt-1.5">
                                    {privateSenderMode === 'dynamic' 
                                      ? "Each line format: phone, value1, value2... (Variables substitute {1}, {2}...)" 
                                      : "Separate numbers by comma or new line."
                                    }
                                  </p>
                               </div>
                               
                               <div className="space-y-2">
                                 <div className="flex justify-between items-center px-1">
                                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Payload Content</label>
                                   {privateSenderMode === 'dynamic' && (
                                     <span className="text-[8px] font-black text-emerald-400 bg-emerald-500/10 border border-emerald-500/25 px-2 py-0.5 rounded uppercase tracking-wider animate-pulse">
                                       Supports variables: {`{1}`}, {`{2}`}...
                                     </span>
                                   )}
                                 </div>
                                 <textarea 
                                   placeholder={privateSenderMode === 'dynamic' 
                                     ? "Hello {1}, your payment of {2} is {3}. Thanks!" 
                                     : "Type campaign message text here..."
                                   }
                                   rows={4}
                                   value={privateSenderMsg || ''}
                                   onChange={(e) => setPrivateSenderMsg(e.target.value)}
                                   className="w-full bg-black/60 border border-white/10 rounded-[1.5rem] px-6 py-4.5 text-sm font-semibold text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all shadow-inner resize-none"
                                 />

                                 {/* Quick Sample Message templates */}
                                 <div className="space-y-1.5 mt-2 px-1 bg-black/30 p-3 rounded-2xl border border-white/5">
                                   <label className="text-[8px] font-black text-slate-500 uppercase tracking-widest block mb-0.5 ml-1">
                                     💡 Quick Set Sample Message:
                                   </label>
                                   <div className="grid grid-cols-2 gap-2">
                                     <button
                                       type="button"
                                       onClick={() => {
                                         if (privateSenderMode === 'dynamic') {
                                           setPrivateSenderMsg("Hello {1}, your payment of {2} is {3}. Please clear it at your earliest convenience!");
                                           setPrivateSenderTo("919999999999, Rajesh Kumar, 1500, due tomorrow\n918888888888, John Doe, 2500, due today");
                                         } else {
                                           setPrivateSenderMsg("Hello! This is a simple premium transmission sent through standard secure channels. Have a wonderful day!");
                                         }
                                         showToast("Sample billing template loaded! Check live preview panels ⚡", "info");
                                       }}
                                       className="bg-white/5 hover:bg-emerald-500/10 hover:text-emerald-400 text-[8px] font-bold uppercase text-left tracking-wider py-1.5 px-2 rounded-lg text-slate-400 transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer border border-white/5 hover:border-emerald-500/20"
                                     >
                                       💵 {privateSenderMode === 'dynamic' ? "Billing Alert Msg" : "Friendly Greeting"}
                                     </button>
                                     <button
                                       type="button"
                                       onClick={() => {
                                         if (privateSenderMode === 'dynamic') {
                                           setPrivateSenderMsg("Hi {1}, your order ID {2} has been dispatched! Track at {3}.");
                                           setPrivateSenderTo("919999999999, Bobby, WR55091, courier.com/track?id=12\n918888888888, David, WR55092, courier.com/track?id=43");
                                         } else {
                                           setPrivateSenderMsg("System Alert: Your secure private dispatch service is active and fully optimized for broadcasts.");
                                         }
                                         showToast("Sample dispatch template loaded! Check live preview panels ⚡", "info");
                                       }}
                                       className="bg-white/5 hover:bg-emerald-500/10 hover:text-emerald-400 text-[8px] font-bold uppercase text-left tracking-wider py-1.5 px-2 rounded-lg text-slate-400 transition-all text-ellipsis overflow-hidden whitespace-nowrap cursor-pointer border border-white/5 hover:border-emerald-500/20"
                                     >
                                       📦 {privateSenderMode === 'dynamic' ? "Order Dispatch Msg" : "Broadcast Alert"}
                                     </button>
                                   </div>
                                 </div>
                               </div>

                              <div className="space-y-4">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Interactive Media Attachment</label>
                                <div className="flex items-center gap-4">
                                   {privateSenderFile ? (
                                     <div className="relative group">
                                       <div className="w-20 h-20 bg-slate-950 rounded-2xl overflow-hidden shadow-lg border border-white/10 flex items-center justify-center">
                                         {privateSenderFile.type === 'image' ? (
                                           <img src={privateSenderFile.url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                         ) : (
                                           <div className="flex flex-col items-center gap-1 text-white/40">
                                             <FileText size={20} />
                                             <span className="text-[7px] font-black uppercase truncate w-16 text-center px-1 text-white">{privateSenderFile.name}</span>
                                           </div>
                                         )}
                                       </div>
                                       <button 
                                         onClick={() => setPrivateSenderFile(null)}
                                         className="absolute -top-2 -right-2 w-6 h-6 bg-rose-500 text-white rounded-full flex items-center justify-center shadow-lg cursor-pointer hover:bg-rose-600"
                                       >
                                         <X size={12} />
                                       </button>
                                     </div>
                                   ) : (
                                     <label className="w-full h-24 border-2 border-dashed border-white/10 rounded-[1.5rem] flex flex-col items-center justify-center text-slate-500 hover:text-emerald-400 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all cursor-pointer bg-black/30">
                                       <Upload size={24} />
                                       <span className="text-[9px] font-black uppercase tracking-widest mt-2">Inject Media Stream</span>
                                       <input 
                                         type="file" 
                                         className="hidden" 
                                         accept="image/*,video/*,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain"
                                         onChange={async (e) => {
                                           const file = e.target.files?.[0];
                                           if (file) {
                                             try {
                                               const type = file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'pdf';
                                               const base64Url = await fileToBase64(file);
                                               setPrivateSenderFile({
                                                 id: Math.random().toString(36).substr(2, 9),
                                                 name: file.name,
                                                 type: type as any,
                                                 url: base64Url
                                               });
                                             } catch (err) { console.error(err); }
                                           }
                                         }}
                                       />
                                     </label>
                                   )}
                                </div>
                                <p className="text-[8px] text-slate-500 mt-1 italic uppercase tracking-tighter text-center">Size Limit: 5MB per file.</p>
                              </div>
                              
                              <div className="flex flex-col sm:flex-row gap-3 mt-4 w-full">
                                {privateSenderMode === 'dynamic' && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const lines = privateSenderTo.split('\n').map(l => l.trim()).filter(l => l);
                                      if (lines.length === 0 || !privateSenderMsg) {
                                        showToast('Please fill in some recipients and template message text first! ⚠️', 'warning');
                                        return;
                                      }
                                      showToast(`Dynamic preview successfully calculated! check the real-world sample list on the left side! 🔍`, 'success');
                                    }}
                                    className="flex-1 bg-slate-800 hover:bg-slate-750 text-emerald-400 border border-emerald-500/25 text-[10px] font-black uppercase tracking-[0.2em] px-6 py-5 rounded-2xl shadow-xl transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 duration-300 cursor-pointer"
                                  >
                                    <Eye size={14} />
                                    Preview Messages
                                  </button>
                                )}
                                <button 
                                  onClick={async () => {
                                    if (!privateSenderSession || privateSenderSession.status !== 'open') {
                                      showToast('Please connect your number first! ❌', 'error');
                                      return;
                                    }
                                    
                                    let parsedRecipients: { to: string; message: string }[] = [];

                                    if (privateSenderMode === 'dynamic') {
                                      const lines = privateSenderTo.split('\n').map(l => l.trim()).filter(l => l);
                                      for (const line of lines) {
                                        const parts = line.split(',').map(p => p.trim());
                                        const to = parts[0];
                                        if (!to) continue;
                                        
                                        // Build dynamic template replacing {1}, {2}, etc.
                                        let finalMsg = privateSenderMsg || '';
                                        for (let idx = 1; idx < parts.length; idx++) {
                                          finalMsg = finalMsg.replaceAll(`{${idx}}`, parts[idx]);
                                        }
                                        parsedRecipients.push({ to, message: finalMsg });
                                      }
                                    } else {
                                      const rawRecipients = privateSenderTo.split(/[\n,]/).map(r => r.trim()).filter(r => r);
                                      parsedRecipients = rawRecipients.map(to => ({
                                        to,
                                        message: privateSenderMsg || ''
                                      }));
                                    }

                                    if (parsedRecipients.length === 0 || (!privateSenderMsg && !privateSenderFile)) {
                                      showToast('Please enter recipient(s) and message! ❌', 'error');
                                      return;
                                    }

                                    if (parsedRecipients.length > 500) {
                                      showToast('Maximum 500 numbers allowed! ⚠️', 'warning');
                                      return;
                                    }
                                    
                                    setPrivateSenderLoading(true);
                                    const finishedCampaignName = privateSenderCampaignName || 'Quick Sends';

                                    try {
                                      const body: any = {
                                        id: privateSenderSession.id,
                                        recipients: parsedRecipients,
                                        campaignName: finishedCampaignName
                                      };

                                      if (privateSenderFile) {
                                        body.mediaType = privateSenderFile.type;
                                        body.mediaData = privateSenderFile.url;
                                        body.fileName = privateSenderFile.name;
                                      }

                                      const res = await safeFetchJson(`${PRIVATE_SENDER_API_BASE}/bulk-send`, {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify(body)
                                      });

                                      // Clear active dispatcher textboxes and file attachments instantly so user can run another campaign
                                      setPrivateSenderTo('');
                                      setPrivateSenderMsg('');
                                      setPrivateSenderFile(null);
                                      setPrivateSenderCampaignName('');
                                      
                                      showToast(res.message || 'Campaign successfully enqueued and running in the background! 🚀', 'success');
                                      
                                      // Auto-switch to reports page and select the brand new active campaign
                                      setShowPrivateSenderReports(true);
                                      setPrivateSenderSelectedCampaign(finishedCampaignName);

                                      // Update local reports list immediately
                                      try {
                                        const d = await safeFetchJson(`${PRIVATE_SENDER_API_BASE}/status`);
                                        if (d && Array.isArray(d.sessions) && privateSenderSession) {
                                          const s = d.sessions.find((sess: any) => sess.id === privateSenderSession.id);
                                          if (s) setPrivateSenderMessages(s.messages || []);
                                        }
                                      } catch (err) {
                                        console.error('Refresh messages error:', err);
                                      }
                                    } catch (e: any) {
                                      console.error(e);
                                      showToast(e.message || 'An error occurred during sending! ❌', 'error');
                                    } finally {
                                      setPrivateSenderLoading(false);
                                    }
                                  }}
                                  disabled={privateSenderLoading || !privateSenderSession || privateSenderSession.status !== 'open'}
                                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black uppercase tracking-[0.2em] px-8 py-5 rounded-2xl shadow-xl transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 duration-300 disabled:opacity-50 disabled:pointer-events-none cursor-pointer"
                                >
                                  <Send size={14} />
                                  {privateSenderLoading ? 'Transmitting...' : 'Send Private Message'}
                                </button>
                              </div>
                            </div>
                         </div>
                      </div>
                        </>
                      ) : (
                        <>
                          {/* Reports Summary Stats inside Reports Page */}
                          {(() => {
                            const totalTransmissions = privateSenderMessages.length;
                            const sentCount = privateSenderMessages.filter(m => m.status === 'sent' || m.status === 'delivered' || m.status === 'read').length;
                            const successRate = totalTransmissions > 0 ? Math.round((sentCount / totalTransmissions) * 100) : 100;
                            const campaignsSet = new Set(privateSenderMessages.map(m => m.campaignName || 'Quick Sends'));
                            const campaignCount = campaignsSet.size;

                            return (
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4 animate-in fade-in duration-500">
                                 <div className="glass p-10 rounded-[2.5rem] border border-white/40 shadow-2xl flex flex-col gap-6 relative overflow-hidden group">
                                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Total Dispatched</span>
                                    <span className="text-5xl font-black text-slate-900 tracking-tighter">{totalTransmissions}</span>
                                 </div>
                                 <div className="glass p-10 rounded-[2.5rem] border border-white/40 shadow-2xl flex flex-col gap-6">
                                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Average Success Rate</span>
                                    <span className="text-5xl font-black text-emerald-600 tracking-tighter">{successRate}%</span>
                                 </div>
                                 <div className="glass p-10 rounded-[2.5rem] border border-white/40 shadow-2xl flex flex-col gap-6">
                                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Total Campaigns</span>
                                    <span className="text-5xl font-black text-indigo-600 tracking-tighter">{campaignCount}</span>
                                 </div>
                              </div>
                            );
                          })()}
                        </>
                      )}

                      {showPrivateSenderReports && (
                        <div id="private-sender-reports" className="mx-4 glass rounded-[3rem] border border-white/40 shadow-2xl p-10 lg:p-12 bg-white/40 backdrop-blur-md animate-in fade-in duration-500">
                        <div className="flex items-center justify-between mb-8 pb-6 border-b border-slate-900/10">
                           <div className="flex items-center gap-4">
                             <div className="w-14 h-14 bg-amber-500 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-amber-500/20">
                               <FileText size={24} />
                             </div>
                             <div>
                                <h4 className="text-xl font-black text-slate-900 uppercase tracking-tight">
                                  {privateSenderSelectedCampaign ? 'Campaign Report' : 'Transmission Ledger'}
                                </h4>
                                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mt-1.5">
                                  {privateSenderSelectedCampaign ? `Logs for "${privateSenderSelectedCampaign}"` : 'Real-time campaign delivery telemetry'}
                                </span>
                             </div>
                           </div>
                          <div className="flex items-center gap-3">
                            {privateSenderSelectedCampaign && (
                              <button 
                                onClick={() => setPrivateSenderSelectedCampaign(null)}
                                className="bg-white/60 hover:bg-white/80 border border-white/85 text-[10px] font-black uppercase tracking-widest px-4 py-2.5 rounded-xl shadow-sm text-slate-700 transition-all flex items-center gap-2 duration-300 hover:scale-105 active:scale-95 whitespace-nowrap"
                              >
                                <ArrowLeft size={12} />
                                Back to Campaigns
                              </button>
                            )}
                            <button 
                              onClick={async () => {
                                if (!privateSenderSession) return;
                                try {
                                  const d = await safeFetchJson(`${PRIVATE_SENDER_API_BASE}/status`);
                                  if (d && Array.isArray(d.sessions) && privateSenderSession) {
                                    const s = d.sessions.find((sess: any) => sess.id === privateSenderSession.id);
                                    if (s) setPrivateSenderMessages(s.messages || []);
                                  }
                                  showToast('Logs Refreshed! ✅', 'success');
                                } catch (err) {
                                  console.error('Refresh error:', err);
                                }
                              }}
                              className="bg-indigo-50 text-indigo-600 hover:bg-indigo-100 border border-slate-200/50 text-[10px] font-black uppercase tracking-widest px-4 py-2.5 rounded-xl shadow-sm transition-all flex items-center gap-2 duration-300 hover:scale-105 active:scale-95"
                            >
                              <RefreshCw size={12} />
                              Refresh Logs
                            </button>
                            {privateSenderMessages.length > 0 && (
                              <button 
                                onClick={() => downloadPrivateSenderCampaignCSV(privateSenderSelectedCampaign)}
                                className="bg-emerald-50 text-emerald-600 hover:bg-emerald-100 border border-slate-200/50 text-[10px] font-black uppercase tracking-widest px-4 py-2.5 rounded-xl shadow-sm transition-all flex items-center gap-2 duration-300 hover:scale-105 active:scale-95 whitespace-nowrap"
                              >
                                <Download size={12} />
                                {privateSenderSelectedCampaign ? 'Download Report' : 'Download All Logs'}
                              </button>
                            )}
                            {privateSenderSelectedCampaign && (
                              <button 
                                onClick={() => deletePrivateSenderCampaign(privateSenderSelectedCampaign)}
                                className="bg-rose-50 text-rose-600 hover:bg-rose-100 border border-rose-200/50 text-[10px] font-black uppercase tracking-widest px-4 py-2.5 rounded-xl shadow-sm transition-all flex items-center gap-2 duration-300 hover:scale-105 active:scale-95 whitespace-nowrap"
                              >
                                <Trash2 size={12} />
                                Delete Campaign
                              </button>
                            )}
                          </div>
                        </div>

                        {privateSenderMessages.length === 0 ? (
                          <div className="py-24 text-center border-2 border-dashed border-slate-200/25 rounded-3xl bg-white/20 shadow-inner flex flex-col items-center justify-center gap-4">
                            <FileText size={48} className="text-slate-350" />
                            <p className="text-slate-505 font-extrabold text-[10px] uppercase tracking-widest">No transmissions logged yet. Start dispatching campaigns!</p>
                          </div>
                        ) : !privateSenderSelectedCampaign ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                            {/* Grouped Campaigns View */}
                            {(() => {
                              const campaigns: { [key: string]: PrivateSenderMessage[] } = {};
                              privateSenderMessages.forEach(m => {
                                const name = m.campaignName || 'Quick Sends';
                                if (!campaigns[name]) campaigns[name] = [];
                                campaigns[name].push(m);
                              });

                              return Object.entries(campaigns).reverse().map(([name, msgs]) => {
                                const latest = msgs[msgs.length - 1];
                                const sent = msgs.filter(m => m.status === 'sent' || m.status === 'delivered' || m.status === 'read').length;
                                const total = msgs.length;
                                
                                return (
                                  <motion.div 
                                    key={name}
                                    whileHover={{ y: -6, scale: 1.02 }}
                                    onClick={() => setPrivateSenderSelectedCampaign(name)}
                                    className="bg-white/60 border border-white/80 rounded-[2rem] p-6 shadow-sm cursor-pointer hover:border-amber-450 hover:shadow-lg transition-all group flex flex-col h-full duration-300"
                                  >
                                    <div className="flex justify-between items-start mb-4">
                                      <div className="flex items-center gap-2">
                                        <div className="p-3 rounded-2xl bg-amber-50 text-amber-600 group-hover:bg-amber-500 group-hover:text-white transition-colors duration-300">
                                          <History size={18} />
                                        </div>
                                        <div className="flex items-center gap-1.5 opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                                          <button
                                            title="Download CSV Report"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              downloadPrivateSenderCampaignCSV(name);
                                            }}
                                            className="p-2 rounded-xl bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white border border-emerald-200 transition-all shadow-sm hover:scale-105 active:scale-95"
                                          >
                                            <Download size={11} />
                                          </button>
                                          <button
                                            title="Delete Campaign Reports"
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              deletePrivateSenderCampaign(name);
                                            }}
                                            className="p-2 rounded-xl bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white border border-rose-200 transition-all shadow-sm hover:scale-105 active:scale-95"
                                          >
                                            <Trash2 size={11} />
                                          </button>
                                        </div>
                                      </div>
                                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest bg-slate-100 px-2.5 py-1 rounded-full">{new Date(latest.timestamp).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}</span>
                                    </div>
                                    
                                    <h5 className="font-extrabold text-slate-800 text-base uppercase tracking-tight mb-2 truncate group-hover:text-amber-600 transition-colors">{name}</h5>
                                    <p className="text-xs text-slate-500 mb-6 line-clamp-2 leading-relaxed font-semibold">{latest.text || 'Media Message'}</p>
                                    
                                    <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-100">
                                      <div className="flex flex-col">
                                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Transmit Count</span>
                                        <span className="text-xs font-black text-slate-700 uppercase tracking-wide mt-1">{total} Items</span>
                                      </div>
                                      <div className="flex flex-col items-end">
                                        <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">Delivery Rate</span>
                                        <span className="text-xs font-black text-emerald-600 mt-1">{Math.round((sent / total) * 100)}%</span>
                                      </div>
                                    </div>
                                  </motion.div>
                                );
                              });
                            })()}
                          </div>
                        ) : (
                          <div className="overflow-x-auto rounded-[2rem] border border-slate-100 bg-white/30 shadow-inner">
                            <table className="w-full text-left border-collapse">
                              <thead>
                                <tr className="bg-white/60 border-b border-slate-100">
                                  <th className="py-5 px-6 text-[10px] font-black text-slate-900 uppercase w-20 tracking-wider">SR. NO.</th>
                                  <th className="py-5 px-6 text-[10px] font-black text-slate-900 uppercase tracking-wider">RECIPIENT</th>
                                  <th className="py-5 px-6 text-[10px] font-black text-slate-900 uppercase tracking-wider">STATUS</th>
                                  <th className="py-5 px-6 text-[10px] font-black text-slate-900 uppercase tracking-wider">TIME</th>
                                  <th className="py-5 px-6 text-[10px] font-black text-slate-900 uppercase tracking-wider">MESSAGE</th>
                                </tr>
                              </thead>
                              <tbody>
                                {privateSenderMessages
                                  .filter(m => (m.campaignName || 'Quick Sends') === privateSenderSelectedCampaign)
                                  .slice()
                                  .reverse()
                                  .map((msg, idx, arr) => (
                                    <tr key={msg.id} className="border-b border-slate-100 hover:bg-white/50 transition-colors duration-250">
                                      <td className="py-5 px-6 text-xs text-slate-500 font-bold">{arr.length - idx}</td>
                                      <td className="py-5 px-6 text-sm font-black text-slate-800 tracking-tight">{msg.to}</td>
                                      <td className="py-5 px-6">
                                        <span className={`px-3 py-1.5 rounded-full text-[9px] uppercase font-black tracking-widest shadow-sm ${
                                          msg.status === 'read' ? 'bg-indigo-50 border border-indigo-100 text-indigo-600' :
                                          msg.status === 'delivered' ? 'bg-emerald-50 border border-emerald-100 text-emerald-600' :
                                          msg.status === 'sent' ? 'bg-slate-50 border border-slate-100 text-slate-600' :
                                          'bg-rose-50 border border-rose-100 text-rose-600'
                                        }`}>
                                          {msg.status}
                                        </span>
                                      </td>
                                      <td className="py-5 px-6 text-xs text-slate-500 font-bold">
                                        {new Date(msg.timestamp).toLocaleTimeString('en-IN', { 
                                          timeZone: 'Asia/Kolkata',
                                          hour: '2-digit', 
                                          minute: '2-digit',
                                          hour12: true
                                        })}
                                      </td>
                                      <td className="py-5 px-6 text-xs text-slate-600 max-w-xs truncate font-semibold" title={msg.text}>
                                        {msg.text || 'Media Attachment'}
                                      </td>
                                    </tr>
                                  ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>
                    )}
                  </>
                )}
                </div>
              )}
              {currentPage === 'Dashboard' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 animate-in fade-in duration-500 w-full">
                  {currentUser.role === 'Admin' ? (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <StatCard label="Total Overview" value={stats.total} color="blue" icon={LayoutDashboard} />
                        <StatCard label="Active Now" value={stats.active} color="green" icon={Play} />
                        <StatCard label="Completed" value={stats.completed} color="purple" icon={CheckCircle} />
                        <StatCard label="Awaiting" value={stats.pending} color="amber" icon={Clock} />
                      </div>
                      
                      <div className="glass rounded-[2rem] p-8 mt-8 overflow-hidden">
                        <div className="flex items-center justify-between mb-8">
                          <div>
                            <h3 className="text-2xl font-black text-slate-800 tracking-tight">Enterprise Performance</h3>
                            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">High-Tier User Contribution Analytics</p>
                          </div>
                          <div className="bg-emerald-50 text-emerald-600 px-5 py-2 rounded-2xl text-xs font-black border border-emerald-100 flex items-center gap-2 shadow-sm uppercase tracking-wider">
                            <Star size={14} className="fill-emerald-600" />
                            TOP PERFORMERS
                          </div>
                        </div>

                        {topSpentUsers.length === 0 ? (
                          <div className="text-center py-12 text-slate-400">
                            <Users size={48} className="mx-auto mb-4 opacity-20" />
                            <p>No user data available</p>
                          </div>
                        ) : (
                          <TopUsersTable users={topSpentUsers} />
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="space-y-8">
                      {/* Credit Wallet */}
                      <div className="flex flex-wrap items-center gap-4 p-2 bg-slate-900/5 rounded-[2.5rem] w-fit mx-auto lg:mx-0">
                        <div className="bg-white px-6 py-3 rounded-full flex items-center gap-3 shadow-sm border border-slate-100">
                           <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-600">
                              <MousePointer2 size={16} />
                           </div>
                           <div className="flex flex-col">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Button</span>
                              <span className="text-sm font-black text-slate-700 leading-none">{(currentUser.btnCredits ?? 0).toLocaleString()}</span>
                           </div>
                        </div>
                        <div className="bg-white px-6 py-3 rounded-full flex items-center gap-3 shadow-sm border border-slate-100">
                           <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-600">
                              <Globe size={16} />
                           </div>
                           <div className="flex flex-col">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">International</span>
                              <span className="text-sm font-black text-slate-700 leading-none">{(currentUser.intCredits ?? 0).toLocaleString()}</span>
                           </div>
                        </div>
                        <div className="bg-white px-6 py-3 rounded-full flex items-center gap-3 shadow-sm border border-slate-100">
                           <div className="w-8 h-8 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-600">
                              <Smartphone size={16} />
                           </div>
                           <div className="flex flex-col">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Domestic</span>
                              <span className="text-sm font-black text-slate-700 leading-none">{(currentUser.domCredits ?? 0).toLocaleString()}</span>
                           </div>
                        </div>
                        <button 
                          onClick={() => setCurrentPage('Manage Transactions')}
                          className="w-12 h-12 rounded-full bg-slate-900 text-white flex items-center justify-center hover:bg-slate-800 transition-all active:scale-90 shadow-lg"
                        >
                          <Plus size={20} />
                        </button>
                      </div>

                      {/* Welcome Message */}
                      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                        <div>
                          <h3 className="text-4xl font-black text-slate-900 tracking-tight">Active Pulse</h3>
                          <p className="text-slate-500 font-medium mt-1">Hello, {currentUser.name}. Your communications ecosystem is operational.</p>
                        </div>
                        
                        <div className="flex bg-white p-1 rounded-2xl shadow-sm border border-slate-200">
                           <button className="px-6 py-2 rounded-xl text-xs font-black bg-slate-900 text-white shadow-lg">OVERVIEW</button>
                           <button onClick={() => setCurrentPage('My Campaigns')} className="px-6 py-2 rounded-xl text-xs font-black text-slate-400 hover:text-slate-600 transition-colors">ANALYTICS</button>
                        </div>
                      </div>

                      {/* My Campaigns Stats */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <StatCard 
                          label="Global Campaigns" 
                          value={userDashboardStats.total} 
                          color="blue" 
                          icon={Rocket} 
                        />
                        <StatCard 
                          label="Delivered Successfully" 
                          value={userDashboardStats.completed} 
                          color="green" 
                          icon={CheckCircle} 
                        />
                        <StatCard 
                          label="Processing Queue" 
                          value={userDashboardStats.pending} 
                          color="amber" 
                          icon={Clock} 
                        />
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {/* Recent Credit Transactions */}
                        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
                          <h4 className="font-bold text-slate-800 mb-1">Recent Credit Transactions</h4>
                          <p className="text-xs text-slate-400 mb-6">Your latest credit activities</p>
                          
                          <div className="space-y-6">
                            {recentUserTransactions.length === 0 ? (
                              <div className="text-center py-10">
                                <p className="text-slate-400 text-sm">No recent transactions</p>
                              </div>
                            ) : (
                              recentUserTransactions.map((tx) => (
                                <div key={tx.id} className="flex gap-4">
                                  <div className={`w-10 h-10 rounded-lg ${tx.action === 'Added' ? 'bg-green-500' : 'bg-red-500'} flex items-center justify-center text-white flex-shrink-0`}>
                                    <FileText size={20} />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm font-bold text-slate-700">Credit {tx.action}: {tx.amount} {tx.type} credits</p>
                                    <p className="text-[10px] text-slate-400 leading-relaxed">
                                      {tx.note} • {tx.date}
                                    </p>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                        </div>

                        {/* Campaign Status Overview */}
                        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
                          <h4 className="font-bold text-slate-800 mb-1">Campaign Status Overview</h4>
                          <p className="text-xs text-slate-400 mb-6">Status of all your campaigns</p>
                          
                          <div className="space-y-6">
                            {[
                              { label: 'Completed', value: creditStats.completed, color: 'bg-green-500' },
                              { label: 'Pending', value: creditStats.pending, color: 'bg-amber-500' },
                              { label: 'Processing', value: creditStats.active, color: 'bg-blue-500' },
                              { label: 'Rejected Campaigns', value: creditStats.rejected, color: 'bg-red-500' },
                            ].map((status, i) => (
                              <div key={i} className="space-y-2">
                                <div className="flex justify-between text-[10px] font-bold">
                                  <span className="text-slate-600">{status.label}</span>
                                  <span className="text-slate-400">{status.value}%</span>
                                </div>
                                <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                                  <div 
                                    className={`h-full ${status.color} transition-all duration-500`} 
                                    style={{ width: `${status.value}%` }}
                                  />
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {currentPage === 'Demo Server' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 px-4">
                      <div>
                        <h3 className="text-4xl font-black text-slate-900 tracking-tight uppercase">channel</h3>
                        <p className="text-slate-500 font-medium mt-1">Manage and monitor core server instances and WhatsApp bridges.</p>
                      </div>
                      <button 
                        onClick={() => {
                          setNewChannelName('');
                          setQrStep('name');
                          setGeneratedQr(null);
                          setIsAddChannelModalOpen(true);
                        }}
                        className="flex items-center justify-center gap-3 bg-emerald-600 text-white font-black text-xs uppercase tracking-[0.2em] px-8 py-4 rounded-2xl shadow-[0_20px_50px_rgba(16,185,129,0.2)] hover:bg-emerald-700 transition-all transform active:scale-95"
                      >
                        <PlusCircle size={18} />
                        Sync New Channel
                      </button>
                   </div>

                   {/* Server Stats */}
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4">
                      <div className="glass p-10 rounded-[2.5rem] border border-white/40 shadow-2xl flex flex-col gap-6 relative overflow-hidden group">
                         <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity"><Activity size={80} /></div>
                         <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Core Status</span>
                         <div className="flex items-center gap-4">
                            <div className={`w-4 h-4 rounded-full shadow-[0_0_15px] ${waStatus.status === 'open' ? 'bg-emerald-500 shadow-emerald-500/50' : 'bg-rose-500 shadow-rose-500/50 animate-pulse'}`} />
                            <span className="text-3xl font-black text-slate-900 uppercase tracking-tighter">{waStatus.status === 'open' ? 'Online' : 'Linking...'}</span>
                         </div>
                      </div>
                      <div className="glass p-10 rounded-[2.5rem] border border-white/40 shadow-2xl flex flex-col gap-6">
                         <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Synced</span>
                         <span className="text-5xl font-black text-slate-900 tracking-tighter">{demoChannels.filter(c => c.status === 'Connected').length}</span>
                      </div>
                      <div className="glass p-10 rounded-[2.5rem] border border-white/40 shadow-2xl flex flex-col gap-6">
                         <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Processor Load</span>
                         <span className="text-5xl font-black text-slate-900 tracking-tighter">18%</span>
                      </div>
                   </div>

                   {/* Channel Management */}
                   <div className="glass rounded-[3rem] border border-white/40 shadow-2xl overflow-hidden mx-4">
                     <div className="p-10 lg:p-12 space-y-10">
                        <div className="flex items-center justify-between">
                           <h4 className="text-2xl font-black text-slate-900 uppercase tracking-tight">add channel</h4>
                           <div className="px-4 py-1.5 bg-slate-900 rounded-full text-[9px] font-black text-white uppercase tracking-widest">{demoChannels.length} Registered</div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                          {demoChannels.map((channel) => (
                            <div key={channel.id} className="bg-white/40 border-2 border-white/80 rounded-[2.5rem] p-8 hover:bg-white transition-all group relative overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1">
                              <div className="flex items-start justify-between mb-8">
                                <div className="w-14 h-14 rounded-2xl bg-slate-900 text-white flex items-center justify-center shadow-2xl group-hover:bg-emerald-600 transition-colors">
                                  <Smartphone size={28} />
                                </div>
                                <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm ${
                                  channel.status === 'Connected' ? 'bg-emerald-500 text-white' : 
                                  channel.status === 'Logged Out' ? 'bg-rose-500 text-white' : 'bg-amber-500 text-white'
                                }`}>
                                  {channel.status}
                                </span>
                              </div>
                              
                              <div className="mb-10">
                                <h5 className="font-black text-slate-900 text-lg uppercase tracking-tight mb-1">{channel.name}</h5>
                                <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{channel.number || 'DE-AUTHED'}</p>
                                {channel.isRestricted && (
                                  <div className="mt-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-2xl text-[10px] font-bold leading-normal uppercase select-none flex items-start gap-2">
                                    <ShieldAlert size={14} className="flex-shrink-0 mt-0.5" />
                                    <span>Sender Restricted (463): WhatsApp rate-limited or blocked new message actions using this account.</span>
                                  </div>
                                )}
                              </div>

                              <div className="flex items-center gap-3">
                                <button 
                                  onClick={() => {
                                    setSelectedChannelForMessage(channel);
                                    setIsSendMessageModalOpen(true);
                                  }}
                                  className="flex-1 bg-slate-900 hover:bg-black text-white text-[10px] font-black uppercase tracking-[0.2em] py-4 rounded-2xl transition-all shadow-xl active:scale-95"
                                >
                                  Test Link
                                </button>
                                <button 
                                  onClick={() => handleLogoutWA(channel.id)}
                                  disabled={deletingSessionId === channel.id}
                                  className="w-14 h-14 flex items-center justify-center rounded-2xl bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white transition-all shrink-0"
                                >
                                  {deletingSessionId === channel.id ? <RefreshCw className="animate-spin" size={18} /> : <Trash2 size={18} />}
                                </button>
                              </div>
                            </div>
                          ))}

                          <button 
                            onClick={() => {
                              setNewChannelName('');
                              setQrStep('name');
                              setGeneratedQr(null);
                              setIsAddChannelModalOpen(true);
                            }}
                            className="border-4 border-dashed border-slate-900/5 rounded-[2.5rem] p-10 flex flex-col items-center justify-center gap-4 hover:border-emerald-500/20 hover:bg-emerald-500/5 transition-all group"
                          >
                            <div className="w-16 h-16 rounded-2xl bg-white shadow-xl flex items-center justify-center text-slate-300 group-hover:text-emerald-500 transition-all duration-500 group-hover:rotate-90">
                              <PlusCircle size={32} />
                            </div>
                            <span className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] group-hover:text-emerald-600 transition-colors">add number</span>
                          </button>
                        </div>
                     </div>
                   </div>

                   {/* API Protocol Section */}
                   <div className="mx-4 bg-slate-900 rounded-[3rem] shadow-[0_40px_100px_rgba(0,0,0,0.3)] border border-white/5 p-12 lg:p-20 overflow-hidden relative group">
                      <div className="absolute -top-24 -right-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-[120px] group-hover:bg-emerald-500/20 transition-all duration-700" />
                      
                      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                         <div className="space-y-10">
                            <div className="flex items-center gap-5">
                               <div className="w-14 h-14 bg-emerald-500 rounded-2xl flex items-center justify-center text-white shadow-[0_10px_30px_rgba(16,185,129,0.3)]"><Code size={28} /></div>
                               <h4 className="text-3xl font-black text-white uppercase tracking-tight">External API <span className="text-emerald-500">v1.0</span></h4>
                            </div>
                            <p className="text-slate-400 font-medium text-sm leading-relaxed max-w-lg italic">
                               "Trigger campaigns programmatically using your custom API integration with standard authentication keys."
                            </p>
                            <div className="space-y-6">
                               <div className="flex items-center gap-4">
                                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                                  <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">End-to-end secure transmission</span>
                               </div>
                               <div className="flex items-center gap-4">
                                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                                  <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">High speed instant delivery</span>
                               </div>
                            </div>
                         </div>

                         <div className="space-y-8">
                            <div className="bg-black/60 backdrop-blur-xl rounded-3xl border border-white/10 p-8 shadow-2xl relative">
                               <div className="flex items-center justify-between mb-6">
                                  <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">API Endpoint URL</span>
                                  <span className="px-3 py-1 bg-emerald-500/10 text-emerald-500 text-[8px] font-black uppercase rounded-lg border border-emerald-500/20">Authorized Access</span>
                               </div>
                               <code className="text-sm text-slate-300 font-mono break-all tracking-tight select-all cursor-copy hover:text-white transition-colors">https://api.panel-service.com/v1/send</code>
                            </div>

                            <div className="bg-black/60 backdrop-blur-xl rounded-3xl border border-white/10 p-8 shadow-2xl">
                               <div className="flex items-center justify-between mb-6">
                                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">HTTP Request Format</span>
                               </div>
                               <pre className="text-xs text-emerald-400 font-mono overflow-x-auto leading-relaxed">
{`{
  "method": "POST",
  "headers": {
    "API-Key": "YOUR_API_KEY",
    "Content-Type": "application/json"
  },
  "body": {
    "numbers": ["91XXXXXXXXXX"],
    "message": "Hello World"
  }
}`}
                               </pre>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
              )}

              {currentPage === 'Create Campaign' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                      <div>
                        <h3 className="text-4xl font-black text-slate-900 tracking-tight">Standard Campaign</h3>
                        <p className="text-slate-500 font-medium mt-1">Send messages, images, PDFs, and videos to multiple contacts.</p>
                      </div>

                   </div>

                  <div className="glass rounded-[2.5rem] overflow-hidden border border-white/40 shadow-2xl">
                    <div className="p-10 space-y-12">
                      {/* Intelligence Bar */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="bg-white/40 border border-white/60 p-4 rounded-3xl flex flex-col">
                           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Numbers</span>
                           <span className="text-xl font-black text-slate-800">{campaignStats.total}</span>
                        </div>
                        <div className="bg-emerald-500/5 border border-emerald-500/20 p-4 rounded-3xl flex flex-col">
                           <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">Valid Numbers</span>
                           <span className="text-xl font-black text-emerald-600">{campaignStats.valid}</span>
                        </div>
                        <div className="bg-red-500/5 border border-red-500/20 p-4 rounded-3xl flex flex-col">
                           <span className="text-[10px] font-black text-red-600 uppercase tracking-widest mb-1">Invalid Numbers</span>
                           <span className="text-xl font-black text-red-600">{campaignStats.invalid}</span>
                        </div>
                        <div className="bg-amber-500/5 border border-amber-500/20 p-4 rounded-3xl flex flex-col">
                           <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest mb-1">Duplicate Numbers</span>
                           <span className="text-xl font-black text-amber-600">{campaignStats.duplicates}</span>
                        </div>
                      </div>

                      {/* Geometric Settings */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div className="space-y-4">
                          <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Route Type</label>
                          <div className="grid grid-cols-2 p-1.5 bg-slate-900/5 rounded-2xl">
                            <button 
                              onClick={() => setCampaignOption('Domestic')}
                              className={`flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black transition-all ${campaignOption === 'Domestic' ? 'bg-white text-slate-900 shadow-md transform active:scale-95' : 'text-slate-400 hover:text-slate-600'}`}
                            >
                              <Smartphone size={14} /> DOMESTIC
                            </button>
                            <button 
                              onClick={() => setCampaignOption('International')}
                              className={`flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-black transition-all ${campaignOption === 'International' ? 'bg-white text-slate-900 shadow-md transform active:scale-95' : 'text-slate-400 hover:text-slate-600'}`}
                            >
                              <Globe size={14} /> INTERNATIONAL
                            </button>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Select Country</label>
                          <div className="relative group">
                            <button 
                              onClick={() => setIsCountryDropdownOpen(!isCountryDropdownOpen)}
                              disabled={campaignOption === 'Domestic'}
                              className={`flex items-center gap-4 w-full bg-white/40 border border-white/60 rounded-2xl px-5 py-3.5 transition-all focus:ring-2 focus:ring-slate-900/10 ${campaignOption === 'International' ? 'hover:bg-white/60 cursor-pointer shadow-sm' : 'opacity-60 cursor-not-allowed grayscale'}`}
                            >
                              <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-xl shadow-inner border border-slate-100">
                                {campaignOption === 'Domestic' ? '🇮🇳' : selectedCountryData.flag}
                              </div>
                              <span className="text-sm font-black text-slate-700">
                                {campaignOption === 'Domestic' ? 'INDIA (+91)' : `${selectedCountryData.name.toUpperCase()} (${selectedCountryData.prefix})`}
                              </span>
                              {campaignOption === 'International' && <ChevronDown className={`ml-auto text-slate-400 transition-transform duration-300 ${isCountryDropdownOpen ? 'rotate-180' : ''}`} size={16} />}
                            </button>

                            <AnimatePresence>
                              {isCountryDropdownOpen && campaignOption === 'International' && (
                                <motion.div 
                                  initial={{ opacity: 0, y: 10 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  exit={{ opacity: 0, y: 10 }}
                                  className="absolute top-full left-0 w-full mt-3 bg-white/95 backdrop-blur-xl border border-slate-200 rounded-2xl shadow-2xl z-50 overflow-hidden py-2"
                                >
                                  <div className="max-h-60 overflow-y-auto custom-scrollbar">
                                    {countries.filter(c => c.name !== 'India').map((c) => (
                                      <button
                                        key={c.name}
                                        onClick={() => {
                                          setSelectedCountry(c.name);
                                          setIsCountryDropdownOpen(false);
                                        }}
                                        className="flex items-center gap-4 w-full px-5 py-3 hover:bg-slate-900 hover:text-white text-left transition-all group"
                                      >
                                        <span className="text-xl grayscale group-hover:grayscale-0 transition-all">{c.flag}</span>
                                        <span className="text-xs font-black uppercase tracking-wider">{c.name}</span>
                                        <span className="text-xs text-slate-400 ml-auto font-bold">{c.prefix}</span>
                                      </button>
                                    ))}
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        </div>
                      </div>

                      {/* Campaign Identity */}
                      <div className="space-y-4">
                        <div className="flex justify-between items-center ml-1">
                          <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Campaign Name</label>
                          <span className={`text-[10px] font-black tracking-widest ${campaignTitle.length > 20 ? 'text-red-500' : 'text-slate-300'}`}>
                            {campaignTitle.length} / 20 MAX
                          </span>
                        </div>
                        <input 
                          type="text" 
                          placeholder="ENTER CAMPAIGN NAME..."
                          value={campaignTitle || ''}
                          onChange={(e) => setCampaignTitle(e.target.value)}
                          className={`w-full bg-white/40 border-2 rounded-2xl px-6 py-4 text-sm font-black uppercase tracking-widest focus:outline-none focus:bg-white transition-all ${
                            campaignTitle.length > 20 ? 'border-red-500 text-red-500' : 'border-white/60 focus:border-slate-900/20'
                          }`}
                        />
                      </div>

                      {/* Content Vector */}
                      <div className="space-y-4">
                        <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Campaign Message</label>
                        <textarea 
                          placeholder="ENTER CAMPAIGN MESSAGE..."
                          value={message || ''}
                          onChange={(e) => setMessage(e.target.value)}
                          rows={6}
                          className="w-full bg-white/40 border-2 border-white/60 rounded-[2rem] px-6 py-6 text-sm font-medium focus:outline-none focus:bg-white focus:border-slate-900/20 transition-all resize-none shadow-inner"
                        />
                        <div className="flex items-center justify-end px-2">
                           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Character Count: {message.length} / 1024</span>
                        </div>
                      </div>

                      {/* Format Protocol */}
                      <div className="space-y-6">
                        <div className="flex items-center justify-between ml-1">
                          <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Number Input Method</label>
                          <div className="flex bg-slate-100 p-1 rounded-xl">
                            {(['Manual', 'CSV Numbers', 'Excel Numbers'] as const).map((format) => (
                              <button 
                                key={format}
                                onClick={() => setNumberFormat(format.split(' ')[0] as any)}
                                className={`px-5 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ${
                                  (format.startsWith(numberFormat)) ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'
                                }`}
                              >
                                {format.split(' ')[0]}
                              </button>
                            ))}
                          </div>
                        </div>

                        {numberFormat !== 'Manual' ? (
                          <div className="relative group">
                             <div className="w-full h-40 border-2 border-dashed border-white/60 bg-white/20 rounded-[2rem] flex flex-col items-center justify-center transition-all group-hover:bg-white/40 group-hover:border-slate-300">
                                <div className="w-14 h-14 rounded-2xl bg-white shadow-xl flex items-center justify-center text-slate-900 mb-3 transform transition-transform group-hover:scale-110">
                                   <Upload size={24} />
                                </div>
                                <p className="text-xs font-black text-slate-600 uppercase tracking-widest">Drop {numberFormat} File Here</p>
                                <p className="text-[10px] font-bold text-slate-400 mt-1">OR CLICK TO BROWSE FILES</p>
                                <input 
                                  type="file" 
                                  className="absolute inset-0 opacity-0 cursor-pointer" 
                                  accept={numberFormat === 'CSV' ? '.csv' : '.xlsx,.xls'}
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) handleFileUpload(file, false);
                                  }}
                                />
                             </div>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <div className="flex justify-between items-center ml-1">
                               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Manual Entry</span>
                               <div className="flex gap-3">
                                  {mobileNumbers.length > 0 && (
                                    <button onClick={() => setMobileNumbers('')} className="text-[10px] font-black text-red-500 uppercase tracking-widest hover:underline flex items-center gap-1"><XCircle size={10} /> Clear All</button>
                                  )}
                                  {(campaignStats.duplicates > 0 || campaignStats.invalid > 0) && (
                                    <button onClick={() => cleanupNumbers()} className="text-[10px] font-black text-emerald-600 uppercase tracking-widest hover:underline flex items-center gap-1"><ShieldCheck size={10} /> Clean List</button>
                                  )}
                               </div>
                            </div>
                            <textarea 
                              placeholder="Enter numbers here (one per line, e.g. 919876543210)..."
                              value={mobileNumbers || ''}
                              onChange={(e) => setMobileNumbers(e.target.value)}
                              onBlur={() => cleanupNumbers()}
                              rows={8}
                              className="w-full bg-white/40 border-2 border-white/60 rounded-[2rem] px-6 py-6 text-sm font-mono focus:outline-none focus:bg-white focus:border-slate-900/20 transition-all resize-none shadow-inner"
                            />
                          </div>
                        )}
                      </div>

                      {/* Media Assets */}
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <MediaVault 
                          icon={ImageIcon}
                          title="Image Assets" 
                          subtitle="Max 2 Units (3MB Each)"
                          files={uploadedImages} 
                          onUpload={(file) => handleMediaUpload('image', file)} 
                          onRemove={(id) => removeFile(id, 'image')}
                          accept="image/*"
                        />
                        <MediaVault 
                          icon={VideoIcon}
                          title="Motion Assets" 
                          subtitle="Max 1 Unit (10MB)"
                          files={uploadedVideos} 
                          onUpload={(file) => handleMediaUpload('video', file)} 
                          onRemove={(id) => removeFile(id, 'video')}
                          accept="video/*"
                        />
                        <MediaVault 
                          icon={FileText}
                          title="Document Assets" 
                          subtitle="Max 1 Unit (3MB PDF)"
                          files={uploadedPDFs} 
                          onUpload={(file) => handleMediaUpload('pdf', file)} 
                          onRemove={(id) => removeFile(id, 'pdf')}
                          accept=".pdf"
                        />
                      </div>

                      {/* Action Matrix */}
                      <div className="pt-6">
                         <button 
                           onClick={() => handleSendCampaign(false)}
                           disabled={!campaignTitle || (!mobileNumbers && numberFormat === 'Manual') || !message || campaignTitle.length > 20}
                           className={`w-full py-6 rounded-[2rem] text-sm font-black uppercase tracking-[0.3em] flex items-center justify-center gap-3 transition-all shadow-2xl active:scale-[0.98] ${
                             !campaignTitle || (!mobileNumbers && numberFormat === 'Manual') || !message || campaignTitle.length > 20
                             ? 'bg-slate-100 text-slate-300 cursor-not-allowed'
                             : 'bg-slate-900 text-white hover:bg-black hover:-translate-y-1'
                           }`}
                         >
                           <Rocket size={18} className={campaignTitle && mobileNumbers && message ? 'animate-bounce' : ''} />
                           Start Campaign
                         </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'Create Button Campaign' && (
                <div className="max-w-7xl mx-auto pb-20 space-y-12 w-full animate-in fade-in duration-500">
                   <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                      <div>
                        <h3 className="text-4xl font-black text-slate-900 tracking-tight">Create Button Campaign</h3>
                        <p className="text-slate-500 font-medium mt-1">Send interactive button messages with links and phone numbers.</p>
                      </div>

                   </div>

                  <div className="glass rounded-[2.5rem] overflow-hidden border border-white/40 shadow-2xl">
                    <div className="p-10 space-y-12">
                      {/* Intelligence Array */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="bg-white/40 border border-white/60 p-4 rounded-3xl flex flex-col">
                           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Numbers</span>
                           <span className="text-xl font-black text-slate-800">{btnCampaignStats.total}</span>
                        </div>
                        <div className="bg-emerald-500/5 border border-emerald-500/20 p-4 rounded-3xl flex flex-col">
                           <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">Valid Numbers</span>
                           <span className="text-xl font-black text-emerald-600">{btnCampaignStats.valid}</span>
                        </div>
                        <div className="bg-red-500/5 border border-red-500/20 p-4 rounded-3xl flex flex-col">
                           <span className="text-[10px] font-black text-red-600 uppercase tracking-widest mb-1">Invalid Numbers</span>
                           <span className="text-xl font-black text-red-600">{btnCampaignStats.invalid}</span>
                        </div>
                        <div className="bg-amber-500/5 border border-amber-500/20 p-4 rounded-3xl flex flex-col">
                           <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest mb-1">Duplicate Numbers</span>
                           <span className="text-xl font-black text-amber-600">{btnCampaignStats.duplicates}</span>
                        </div>
                      </div>

                      {/* Campaign Paradigm */}
                      <div className="space-y-4">
                        <div className="flex justify-between items-center ml-1">
                          <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Campaign Name</label>
                          <span className={`text-[10px] font-black tracking-widest ${btnCampaignTitle.length > 20 ? 'text-red-500' : 'text-slate-300'}`}>
                            {btnCampaignTitle.length} / 20 MAX
                          </span>
                        </div>
                        <input 
                          type="text" 
                          placeholder="ENTER CAMPAIGN NAME..."
                          value={btnCampaignTitle || ''}
                          onChange={(e) => setBtnCampaignTitle(e.target.value)}
                          className={`w-full bg-white/40 border-2 rounded-2xl px-6 py-4 text-sm font-black uppercase tracking-widest focus:outline-none focus:bg-white transition-all ${
                            btnCampaignTitle.length > 20 ? 'border-red-500 text-red-500' : 'border-white/60 focus:border-slate-900/20'
                          }`}
                        />
                      </div>

                      {/* Content Vector */}
                      <div className="space-y-4">
                        <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Campaign Message</label>
                        <textarea 
                          placeholder="ENTER CAMPAIGN MESSAGE..."
                          value={btnMessage || ''}
                          onChange={(e) => setBtnMessage(e.target.value)}
                          rows={6}
                          className="w-full bg-white/40 border-2 border-white/60 rounded-[2rem] px-6 py-6 text-sm font-medium focus:outline-none focus:bg-white focus:border-slate-900/20 transition-all resize-none shadow-inner"
                        />
                        <div className="flex items-center justify-end px-2">
                           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Character Count: {btnMessage.length} / 1024</span>
                        </div>
                      </div>

                      {/* Logic Branching */}
                      <div className="space-y-6">
                        <div className="flex items-center gap-3 ml-1">
                          <label className="text-xs font-black text-slate-900 uppercase tracking-[0.2em]">Button Options</label>
                          
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          {/* Hyperlink Gateway */}
                          <div className="p-6 bg-white/30 border border-white/60 rounded-[2rem] space-y-4 shadow-sm">
                            <div className="flex items-center gap-3 text-slate-900">
                              <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center shadow-lg"><Globe size={14} /></div>
                              <span className="text-[10px] font-black uppercase tracking-widest">WEBSITE LINK</span>
                            </div>
                            <input 
                              type="text" 
                              placeholder="BUTTON TEXT (E.G. VISIT WEBSITE)"
                              value={btnLinkText || ''}
                              onChange={(e) => setBtnLinkText(e.target.value)}
                              className="w-full bg-white/60 border border-slate-100 rounded-xl px-4 py-3 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white shadow-inner"
                            />
                            <div className="relative">
                              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={12} />
                              <input 
                                type="text" 
                                placeholder="HTTPS://YOUR-WEBSITE.COM"
                                value={btnLinkUrl || ''}
                                onChange={(e) => setBtnLinkUrl(e.target.value)}
                                className="w-full bg-white/60 border border-slate-100 rounded-xl pl-10 pr-4 py-3 text-[10px] font-bold focus:outline-none focus:bg-white shadow-inner"
                              />
                            </div>
                          </div>

                          {/* Voice Gateway */}
                          <div className="p-6 bg-white/30 border border-white/60 rounded-[2rem] space-y-4 shadow-sm">
                            <div className="flex items-center gap-3 text-slate-900">
                              <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center shadow-lg"><Smartphone size={14} /></div>
                              <span className="text-[10px] font-black uppercase tracking-widest">CALL PHONE NUMBER</span>
                            </div>
                            <input 
                              type="text" 
                              placeholder="BUTTON TEXT (E.G. CALL US)"
                              value={btnCallText || ''}
                              onChange={(e) => setBtnCallText(e.target.value)}
                              className="w-full bg-white/60 border border-slate-100 rounded-xl px-4 py-3 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white shadow-inner"
                            />
                            <div className="relative">
                              <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={12} />
                              <input 
                                type="text" 
                                placeholder="+XX XXX XXX XXXX"
                                value={btnCallNumber || ''}
                                onChange={(e) => setBtnCallNumber(e.target.value)}
                                className="w-full bg-white/60 border border-slate-100 rounded-xl pl-10 pr-4 py-3 text-[10px] font-bold focus:outline-none focus:bg-white shadow-inner"
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Visual Assets */}
                      <MediaVault 
                        icon={Layers}
                        title="Interactive Header" 
                        subtitle="Single Visual Asset (Max 3MB)"
                        files={btnMedia} 
                        onUpload={async (file) => {
                          try {
                            const base64Url = await fileToBase64(file);
                            const newFile: UploadedFile = {
                              id: Math.random().toString(36).substr(2, 9),
                              name: file.name,
                              type: file.type.includes('image') ? 'image' : file.type.includes('video') ? 'video' : 'pdf',
                              url: base64Url
                            };
                            setBtnMedia(prev => {
                              if (prev.length < 1) {
                                return [newFile];
                              }
                              return prev;
                            });
                          } catch (err) {
                            console.error('Failed to convert file to base64:', err);
                          }
                        }} 
                        onRemove={(id) => setBtnMedia(prev => prev.filter(f => f.id !== id))}
                        accept="image/*,video/*,.pdf"
                      />

                      {/* Format Protocol */}
                      <div className="space-y-6">
                        <div className="flex items-center justify-between ml-1">
                          <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Number Input Method</label>
                          <div className="flex bg-slate-100 p-1 rounded-xl">
                            {(['Manual', 'CSV Numbers', 'Excel Numbers'] as const).map((format) => (
                              <button 
                                key={format}
                                onClick={() => setBtnNumberFormat(format.split(' ')[0] as any)}
                                className={`px-5 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ${
                                  (format.startsWith(btnNumberFormat)) ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'
                                }`}
                              >
                                {format.split(' ')[0]}
                              </button>
                            ))}
                          </div>
                        </div>

                        {btnNumberFormat !== 'Manual' ? (
                          <div className="relative group">
                             <div className="w-full h-40 border-2 border-dashed border-white/60 bg-white/20 rounded-[2rem] flex flex-col items-center justify-center transition-all group-hover:bg-white/40 group-hover:border-slate-300">
                                <div className="w-14 h-14 rounded-2xl bg-white shadow-xl flex items-center justify-center text-slate-900 mb-3 transform transition-transform group-hover:scale-110">
                                   <Upload size={24} />
                                </div>
                                <p className="text-xs font-black text-slate-600 uppercase tracking-widest">Drop {btnNumberFormat} File Here</p>
                                <input 
                                  type="file" 
                                  className="absolute inset-0 opacity-0 cursor-pointer" 
                                  accept={btnNumberFormat === 'CSV' ? '.csv' : '.xlsx,.xls'}
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) handleFileUpload(file, true);
                                  }}
                                />
                             </div>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <div className="flex justify-between items-center ml-1">
                               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Manual Entry</span>
                               <div className="flex gap-3">
                                  {btnMobileNumbers.length > 0 && (
                                    <button onClick={() => setBtnMobileNumbers('')} className="text-[10px] font-black text-red-500 uppercase tracking-widest hover:underline flex items-center gap-1"><XCircle size={10} /> Clear All</button>
                                  )}
                                  {(btnCampaignStats.duplicates > 0 || btnCampaignStats.invalid > 0) && (
                                    <button onClick={() => cleanupNumbers(true)} className="text-[10px] font-black text-emerald-600 uppercase tracking-widest hover:underline flex items-center gap-1"><ShieldCheck size={10} /> Clean List</button>
                                  )}
                               </div>
                            </div>
                            <textarea 
                              placeholder="Enter numbers here (one per line, e.g. 919876543210)..."
                              value={btnMobileNumbers || ''}
                              onChange={(e) => setBtnMobileNumbers(e.target.value)}
                              onBlur={() => cleanupNumbers(true)}
                              rows={8}
                              className="w-full bg-white/40 border-2 border-white/60 rounded-[2rem] px-6 py-6 text-sm font-mono focus:outline-none focus:bg-white focus:border-slate-900/20 transition-all resize-none shadow-inner"
                            />
                          </div>
                        )}
                      </div>

                      {/* Deployment Action */}
                      <div className="pt-6">
                         <button 
                           onClick={() => handleSendCampaign(true)}
                           disabled={!btnCampaignTitle || (!btnMobileNumbers && btnNumberFormat === 'Manual') || !btnMessage || btnCampaignTitle.length > 20}
                           className={`w-full py-6 rounded-[2rem] text-sm font-black uppercase tracking-[0.3em] flex items-center justify-center gap-3 transition-all shadow-2xl active:scale-[0.98] ${
                             !btnCampaignTitle || (!btnMobileNumbers && btnNumberFormat === 'Manual') || !btnMessage || btnCampaignTitle.length > 20
                             ? 'bg-slate-100 text-slate-300 cursor-not-allowed'
                             : 'bg-indigo-600 text-white hover:bg-indigo-700 hover:-translate-y-1 shadow-indigo-500/20'
                           }`}
                         >
                           <Rocket size={18} className={btnCampaignTitle && btnMobileNumbers && btnMessage ? 'animate-bounce' : ''} />
                           Start Campaign
                         </button>
                      </div>
                    </div>
                  </div>

                  {/* Operational Protocol (Guidelines) */}
                  <div className="glass rounded-[2rem] border border-white/40 shadow-xl p-10">
                    <div className="flex items-center gap-4 mb-8">
                       <div className="w-12 h-12 rounded-2xl bg-indigo-900 border border-indigo-500 text-white flex items-center justify-center shadow-lg"><ShieldCheck size={24} /></div>
                       <div>
                          <h4 className="text-xl font-black text-slate-900 uppercase tracking-tight">Button Campaign Guidelines</h4>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Rules & Guidelines</p>
                       </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                       {[
                         { title: 'DELIVERY SPEED', desc: 'Button Campaign may take 30-240 minutes to deliver' },
                         { title: 'MEDIA FILES LIMIT', desc: 'Only 01 image or 01 video or 01 PDF allowed per campaign' },
                         { title: 'INDIA DOMESTIC ONLY', desc: 'Button Campaigns are available for INDIA only' },
                         { title: 'SEPARATE CREDITS', desc: 'Separate credits needed for Button Campaigns' },
                         { title: 'LINK FORMAT', desc: 'Link should be added with HTTP or HTTPS' },
                         { title: 'CALL NUMBER PREFIX', desc: '+91 need not be added for call button' },
                         { title: 'PROHIBITED CONTENT', desc: 'No Elections Campaigns allowed for Button Campaign' }
                       ].map((rule, idx) => (
                         <div key={idx} className="p-5 bg-white/40 border border-white/60 rounded-2xl shadow-inner hover:bg-white/60 transition-all">
                            <span className="text-[10px] font-black text-indigo-600 uppercase mb-2 block">{rule.title}</span>
                            <p className="text-xs font-bold text-slate-700 leading-relaxed">{rule.desc}</p>
                         </div>
                       ))}
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'My Campaigns' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-4">
                      <div>
                        <h3 className="text-4xl font-black text-slate-900 tracking-tight">Mission Control</h3>
                        <p className="text-slate-500 font-medium mt-1">Reviewing active operation parameters and throughput.</p>
                      </div>
                      <div className="flex bg-white/50 backdrop-blur-sm p-1.5 rounded-2xl border border-white/60 shadow-inner">
                         <div className="flex items-center gap-3 px-6 py-2">
                           <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center text-white text-[10px] shadow-lg font-black">{currentUser.btnCredits}</div>
                           <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Interaction Assets</span>
                         </div>
                      </div>
                   </div>

                  <div className="glass rounded-[2.5rem] border border-white/40 shadow-2xl overflow-hidden">
                    <div className="p-8">
                      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-10">
                        <div className="flex items-center gap-4">
                           <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center shadow-xl"><Layers size={22} /></div>
                           <div>
                              <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Active Operation Array</h3>
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Real-time status synchronization</p>
                           </div>
                        </div>
                        
                        <div className="flex items-center gap-3 w-full lg:w-auto">
                          <div className="relative group flex-1 lg:w-80">
                            <input 
                              type="text" 
                              placeholder="SEARCH OPERATION MATRIX..."
                              value={searchQuery || ''}
                              onChange={(e) => setSearchQuery(e.target.value)}
                              className="w-full bg-white/40 border-2 border-white/60 rounded-2xl pl-12 pr-6 py-3.5 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white focus:border-slate-900/20 transition-all shadow-inner"
                            />
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-hover:text-slate-600 transition-colors" size={16} />
                          </div>
                        </div>
                      </div>
                      <CampaignTable 
                        campaigns={activeFilteredCampaigns} 
                        onFinish={currentUser.role === 'Admin' ? (id) => setRunningCampaignId(id) : undefined}
                        onView={setSelectedCampaign}
                        onReport={handleCampaignReportClick}
                        onEdit={(currentUser.role === 'Admin' || currentUser.role === 'Reseller') ? setEditingCampaign : undefined}
                        onTestMessage={handleTestMessage}
                        onReset={(currentUser.role === 'Admin' || currentUser.role === 'Reseller') ? handleResetCampaign : undefined}
                        isAdmin={currentUser.role === 'Admin' || currentUser.role === 'Reseller'}
                        isSystemAdmin={currentUser.role === 'Admin'}
                        onRefundNonWA={handleRefundNonWA}
                      />
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'Pending Campaign' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-4">
                      <div>
                        <h3 className="text-4xl font-black text-slate-900 tracking-tight">Staging Buffer</h3>
                        <p className="text-slate-500 font-medium mt-1">Operations awaiting protocol validation and authorization.</p>
                      </div>
                   </div>

                  <div className="glass rounded-[2.5rem] border border-white/40 shadow-2xl overflow-hidden">
                    <div className="p-8">
                      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-10">
                        <div className="flex items-center gap-4">
                           <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-xl"><Clock size={22} /></div>
                           <div>
                              <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Pending Influx Array</h3>
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Awaiting administrator clearance</p>
                           </div>
                        </div>
                        
                        <div className="relative group w-full lg:w-80">
                          <input 
                            type="text" 
                            placeholder="FILTER PENDING VECTORS..."
                            value={searchQuery || ''}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full bg-white/40 border-2 border-white/60 rounded-2xl pl-12 pr-6 py-3.5 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white focus:border-slate-900/20 transition-all shadow-inner"
                          />
                          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                        </div>
                      </div>
                      <CampaignTable 
                        campaigns={pendingFilteredCampaigns} 
                        onFinish={(id) => setRunningCampaignId(id)}
                        onView={setSelectedCampaign}
                        onReject={setRejectingCampaignId}
                        onReport={handleCampaignReportClick}
                        onEdit={(currentUser.role === 'Admin' || currentUser.role === 'Reseller') ? setEditingCampaign : undefined}
                        onTestMessage={handleTestMessage}
                        onReset={(currentUser.role === 'Admin' || currentUser.role === 'Reseller') ? handleResetCampaign : undefined}
                        isAdmin={currentUser.role === 'Admin' || currentUser.role === 'Reseller'}
                        isSystemAdmin={currentUser.role === 'Admin'}
                        onRefundNonWA={handleRefundNonWA}
                      />
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'Finished Campaign' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 px-4">
                      <div>
                        <h3 className="text-4xl font-black text-slate-900 tracking-tight">Data Archive</h3>
                        <p className="text-slate-500 font-medium mt-1">Comprehensive logs of terminated and completed transmissions.</p>
                      </div>
                   </div>

                  <div className="glass rounded-[2.5rem] border border-white/40 shadow-2xl overflow-hidden">
                    <div className="p-8">
                      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-10">
                        <div className="flex items-center gap-6">
                           <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-xl"><CheckCircle size={22} /></div>
                           <div className="flex bg-slate-900/5 p-1 rounded-2xl">
                             <button 
                               onClick={() => setFinishedTab('Completed')}
                               className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${finishedTab === 'Completed' ? 'bg-white text-slate-900 shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
                             >
                               Success
                             </button>
                             <button 
                               onClick={() => setFinishedTab('Rejected')}
                               className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${finishedTab === 'Rejected' ? 'bg-white text-red-600 shadow-md' : 'text-slate-400 hover:text-slate-600'}`}
                             >
                               Rejected
                             </button>
                           </div>
                        </div>
                        
                        <div className="relative group w-full lg:w-80">
                          <input 
                            type="text" 
                            placeholder={`SEARCH ARCHIVED LOGS...`}
                            value={searchQuery || ''}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full bg-white/40 border-2 border-white/60 rounded-2xl pl-12 pr-6 py-3.5 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white focus:border-slate-900/20 transition-all shadow-inner"
                          />
                          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                        </div>
                      </div>
                      <CampaignTable 
                        campaigns={finishedFilteredCampaigns} 
                        onView={setSelectedCampaign}
                        onRestore={(currentUser.role === 'Admin' || currentUser.role === 'Reseller') ? handleRestoreCampaign : undefined}
                        onReport={handleCampaignReportClick}
                        onEdit={(currentUser.role === 'Admin' || currentUser.role === 'Reseller') ? setEditingCampaign : undefined}
                        onTestMessage={handleTestMessage}
                        onReset={(currentUser.role === 'Admin' || currentUser.role === 'Reseller') ? handleResetCampaign : undefined}
                        isAdmin={currentUser.role === 'Admin' || currentUser.role === 'Reseller'}
                        isSystemAdmin={currentUser.role === 'Admin'}
                        onRefundNonWA={handleRefundNonWA}
                      />
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'User Management' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 px-4">
                      <div>
                        <h3 className="text-4xl font-black text-slate-900 tracking-tight">User Management</h3>
                        <p className="text-slate-500 font-medium mt-1">Manage agent accounts, resellers, and configure user specific credit allocation.</p>
                      </div>
                      <button 
                        onClick={() => setIsAddUserModalOpen(true)}
                        className="flex items-center justify-center gap-3 bg-slate-900 text-white font-black text-xs uppercase tracking-[0.2em] px-8 py-4 rounded-2xl shadow-2xl hover:bg-slate-800 transition-all transform active:scale-95"
                      >
                        <UserPlus size={18} />
                        Add New Account
                      </button>
                   </div>

                   {/* System Metrics */}
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-6 px-4">
                      <div className="glass p-8 rounded-[2rem] border border-white/40 shadow-xl flex items-center gap-6">
                         <div className="w-14 h-14 rounded-2xl bg-indigo-500 text-white flex items-center justify-center shadow-lg"><UserIcon size={24} /></div>
                         <div>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Total Users</span>
                            <span className="text-2xl font-black text-slate-900">{users.filter(u => u.role === 'User').length}</span>
                         </div>
                      </div>
                      <div className="glass p-8 rounded-[2rem] border border-white/40 shadow-xl flex items-center gap-6">
                         <div className="w-14 h-14 rounded-2xl bg-purple-500 text-white flex items-center justify-center shadow-lg"><Rocket size={24} /></div>
                         <div>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Total Resellers</span>
                            <span className="text-2xl font-black text-slate-900">{users.filter(u => u.role === 'Reseller').length}</span>
                         </div>
                      </div>
                      <div className="glass p-8 rounded-[2rem] border border-white/40 shadow-xl flex items-center gap-6">
                         <div className="w-14 h-14 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-lg"><CheckCircle size={24} /></div>
                         <div>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Active Accounts</span>
                            <span className="text-2xl font-black text-slate-900">{users.filter(u => u.status === 'Active').length}</span>
                         </div>
                      </div>
                   </div>

                  <div className="glass rounded-[2.5rem] border border-white/40 shadow-2xl overflow-hidden">
                    <div className="p-8 lg:p-10 space-y-10">
                      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8">
                        <div className="flex bg-slate-900/5 p-1 rounded-2xl w-fit">
                          {(['Active', 'Suspended', 'Deleted'] as const).map((tab) => (
                            <button
                              key={tab}
                              onClick={() => setUserStatusTab(tab)}
                              className={`px-8 py-2.5 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${
                                userStatusTab === tab ? 'bg-white text-slate-900 shadow-md' : 'text-slate-400 hover:text-slate-600'
                              }`}
                            >
                              {tab}
                            </button>
                          ))}
                        </div>

                        <div className="flex flex-col md:flex-row gap-4 items-center flex-1 max-w-4xl">
                          <div className="relative group flex-1 w-full">
                            <input 
                              type="text" 
                              placeholder="Search users..."
                              value={userSearchQuery || ''}
                              onChange={(e) => setUserSearchQuery(e.target.value)}
                              className="w-full bg-white/40 border-2 border-white/60 rounded-2xl pl-12 pr-6 py-4 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white focus:border-slate-900/20 transition-all shadow-inner"
                            />
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                          </div>
                          <select 
                            className="bg-white/40 border-2 border-white/60 rounded-2xl px-6 py-4 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white shadow-inner appearance-none cursor-pointer pr-12 w-full md:w-auto"
                            value={userRoleFilter || 'All'}
                            onChange={(e) => setUserRoleFilter(e.target.value as any)}
                          >
                            <option value="All">Tier: All</option>
                            <option value="User">Tier: User</option>
                            <option value="Reseller">Tier: Reseller</option>
                          </select>
                        </div>
                      </div>

                      <div className="overflow-x-auto custom-scrollbar">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="border-b border-slate-100">
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">User Info</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Login Credentials</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Account & Status</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Assigned Uplink</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Plan & Status</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Allocated Credits</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {filteredUsers.map((u) => (
                                <tr key={u.id} className="border-b border-slate-50/50 hover:bg-slate-900/5 transition-all group">
                                  <td className="py-6 px-4">
                                    <div className="flex items-center gap-4">
                                      <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-xs font-black shadow-lg">
                                        {u.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                                      </div>
                                      <div>
                                        <p className="font-black text-slate-800 text-xs uppercase tracking-tight">{u.name}</p>
                                        <p className="text-[10px] text-slate-400 font-bold">{u.location || 'GLOBAL'}</p>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="py-6 px-4">
                                    <div className="text-[9px] font-black uppercase tracking-widest space-y-1.5">
                                      <p className="text-slate-400">ID: <span className="text-slate-900">{u.username}</span></p>
                                      <p className="text-slate-400">KEY: <span className="text-indigo-600 font-mono">{u.password}</span></p>
                                      <p className="text-slate-400">COM: <span className="text-slate-600">{u.mobile}</span></p>
                                    </div>
                                  </td>
                                  <td className="py-6 px-4">
                                     <div className="flex flex-col gap-2">
                                        <span className={`w-fit px-3 py-1 rounded-lg text-white text-[9px] font-black uppercase tracking-widest shadow-sm ${
                                          u.role === 'Admin' ? 'bg-slate-900' :
                                          u.role === 'Reseller' ? 'bg-purple-600' :
                                          'bg-indigo-500'
                                        }`}>
                                          {u.role}
                                        </span>
                                        <span className={`w-fit px-3 py-1 rounded-lg text-white text-[9px] font-black uppercase tracking-widest shadow-sm ${
                                          u.status === 'Active' ? 'bg-emerald-500' : 
                                          u.status === 'Suspended' ? 'bg-amber-500' : 
                                          'bg-red-500'
                                        }`}>
                                          {u.status}
                                        </span>
                                     </div>
                                  </td>
                                  <td className="py-6 px-4">
                                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                      {users.find(parent => parent.id === u.uplink)?.name || u.uplink || 'ORIGIN'}
                                    </span>
                                  </td>
                                  <td className="py-6 px-4">
                                     <div className="text-[9px] font-black uppercase tracking-widest space-y-1.5 min-w-[140px]">
                                        <p className="text-slate-400">Created: <span className="text-slate-950 font-bold">{u.createdAt ? new Date(u.createdAt).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }) : 'Initial account'}</span></p>
                                        <p className="text-slate-400">Plan expiry: <span className={u.role !== 'Admin' && u.planExpiryDate && new Date(u.planExpiryDate) < new Date() ? 'text-rose-500 font-extrabold' : 'text-slate-950 font-bold'}>
                                          {u.role === 'Admin' ? 'Infinity ♾️' : (u.planExpiryDate ? new Date(u.planExpiryDate).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }) : '1 Year Limit')}
                                        </span></p>
                                        <p className="text-slate-400">Campaign: <span className={u.campaignApproved !== false ? 'text-emerald-500 font-bold' : 'text-rose-500 font-black'}>
                                          {u.role === 'Admin' ? 'APPROVED' : (u.campaignApproved !== false ? 'APPROVED ✅' : 'PENDING ❌')}
                                        </span></p>
                                     </div>
                                  </td>
                                  <td className="py-6 px-4">
                                     <div className="space-y-1.5 text-[9px] font-black uppercase tracking-widest">
                                        <div className="flex justify-between w-24">
                                           <span className="text-slate-400">DOM</span>
                                           <span className="text-slate-900">{u.domCredits}</span>
                                        </div>
                                        <div className="flex justify-between w-24">
                                           <span className="text-slate-400">INT</span>
                                           <span className="text-slate-900">{u.intCredits}</span>
                                        </div>
                                        <div className="flex justify-between w-24">
                                           <span className="text-slate-400">BTN</span>
                                           <span className="text-slate-900">{u.btnCredits}</span>
                                        </div>
                                     </div>
                                  </td>
                                  <td className="py-6 px-4 text-right">
                                    <div className="flex justify-end relative">
                                      <button 
                                        onClick={() => setOpenUserDropdownId(openUserDropdownId === u.id ? null : u.id)}
                                        className="w-10 h-10 flex items-center justify-center hover:bg-slate-900 hover:text-white rounded-xl text-slate-400 transition-all shadow-sm"
                                      >
                                        <MoreHorizontal size={18} />
                                      </button>
                                      
                                      <AnimatePresence>
                                        {openUserDropdownId === u.id && (
                                          <>
                                            <div 
                                              className="fixed inset-0 z-10" 
                                              onClick={() => setOpenUserDropdownId(null)}
                                            />
                                            <motion.div
                                              initial={{ opacity: 0, scale: 0.95, y: -10 }}
                                              animate={{ opacity: 1, scale: 1, y: 0 }}
                                              exit={{ opacity: 0, scale: 0.95, y: -10 }}
                                              className="absolute right-0 top-full mt-3 w-56 bg-white border border-slate-200 rounded-2xl shadow-2xl z-20 overflow-hidden py-2"
                                            >
                                              <div className="px-2 space-y-1">
                                                <button 
                                                  onClick={() => {
                                                    const text = `Matrix Identity: ${u.name}\nHandle: ${u.username}\nKey: ${u.password}`;
                                                    navigator.clipboard.writeText(text);
                                                    showToast(`Credentials for ${u.name} transmitted to clipboard!`);
                                                    setOpenUserDropdownId(null);
                                                  }}
                                                  className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-900 hover:text-white transition-all rounded-xl group text-left"
                                                >
                                                  <Copy size={14} className="text-blue-500 group-hover:text-white" />
                                                  Copy Credentials
                                                </button>
                                                <button 
                                                  onClick={() => {
                                                    setSelectedUserForCampaigns(u);
                                                    setOpenUserDropdownId(null);
                                                  }}
                                                  className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-900 hover:text-white transition-all rounded-xl group text-left"
                                                >
                                                  <Rocket size={14} className="text-indigo-500 group-hover:text-white" />
                                                  Protocol Logs
                                                </button>
                                                <button 
                                                  onClick={() => {
                                                    setManagingCreditsUser(u);
                                                    setOpenUserDropdownId(null);
                                                  }}
                                                  className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-900 hover:text-white transition-all rounded-xl group text-left"
                                                >
                                                  <RefreshCw size={14} className="text-purple-500 group-hover:text-white" />
                                                  Sync Assets
                                                </button>
                                                <button 
                                                  onClick={() => {
                                                    setTransactionSearchQuery(u.id);
                                                    setCurrentPage('Manage Transactions');
                                                    setOpenUserDropdownId(null);
                                                  }}
                                                  className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-900 hover:text-white transition-all rounded-xl group text-left"
                                                >
                                                  <Search size={14} className="text-emerald-500 group-hover:text-white" />
                                                  History Matrix
                                                </button>
                                                <button 
                                                  onClick={() => {
                                                    if (u.status === 'Deleted') {
                                                      setUsers(prev => prev.map(user => user.id === u.id ? { ...user, status: 'Active' } : user));
                                                    } else {
                                                      const newStatus = u.status === 'Active' ? 'Suspended' : 'Active';
                                                      setUsers(prev => prev.map(user => user.id === u.id ? { ...user, status: newStatus as any } : user));
                                                    }
                                                    setOpenUserDropdownId(null);
                                                  }}
                                                  className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-900 hover:text-white transition-all rounded-xl group text-left"
                                                >
                                                  {u.status === 'Deleted' ? <ShieldCheck size={14} className="text-blue-500 group-hover:text-white" /> : u.status === 'Active' ? <CircleOff size={14} className="text-amber-500 group-hover:text-white" /> : <Power size={14} className="text-emerald-500 group-hover:text-white" />}
                                                  {u.status === 'Deleted' ? 'Re-authorize' : u.status === 'Active' ? 'De-authorize' : 'Initialize'}
                                                </button>
                                                {u.role !== 'Admin' && (
                                                  <>
                                                    <button 
                                                      onClick={() => {
                                                        const oneYr = new Date();
                                                        oneYr.setFullYear(oneYr.getFullYear() + 1);
                                                        const updated = { 
                                                          ...u, 
                                                          planExpiryDate: oneYr.toISOString(),
                                                          campaignApproved: true
                                                        };
                                                        setUsers(prev => prev.map(user => user.id === u.id ? updated : user));
                                                        showToast(`Plan for ${u.name} successfully renewed till ${oneYr.toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })} ✅`);
                                                        setOpenUserDropdownId(null);
                                                      }}
                                                      className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-black uppercase tracking-widest text-emerald-600 hover:bg-emerald-600 hover:text-white transition-all rounded-xl group text-left"
                                                    >
                                                      <CalendarDays size={14} className="text-emerald-500 group-hover:text-white" />
                                                      Renew Plan (+1 Year)
                                                    </button>
                                                    <button 
                                                      onClick={() => {
                                                        const updated = { 
                                                          ...u, 
                                                          campaignApproved: u.campaignApproved === false ? true : false
                                                        };
                                                        setUsers(prev => prev.map(user => user.id === u.id ? updated : user));
                                                        showToast(`Campaign sending for ${u.name} is now ${updated.campaignApproved ? 'APPROVED ✅' : 'BLOCKED ❌'}`);
                                                        setOpenUserDropdownId(null);
                                                      }}
                                                      className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-black uppercase tracking-widest text-indigo-600 hover:bg-indigo-600 hover:text-white transition-all rounded-xl group text-left"
                                                    >
                                                      <ShieldCheck size={14} className="text-indigo-500 group-hover:text-white" />
                                                      Toggle Approval ({u.campaignApproved !== false ? 'Block' : 'Approve'})
                                                    </button>
                                                  </>
                                                )}
                                                <button 
                                                  onClick={() => {
                                                    setUserBeingEdited(u);
                                                    setOpenUserDropdownId(null);
                                                  }}
                                                  className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-900 hover:text-white transition-all rounded-xl group text-left"
                                                >
                                                  <Pencil size={14} className="text-slate-400 group-hover:text-white" />
                                                  Edit Protocol
                                                </button>
                                                <div className="h-px bg-slate-100 my-2 mx-2" />
                                                <button 
                                                  onClick={() => {
                                                    handleDeleteUser(u);
                                                    setOpenUserDropdownId(null);
                                                  }}
                                                  className="w-full flex items-center gap-3 px-4 py-3 text-[10px] font-black uppercase tracking-widest text-red-500 hover:bg-red-600 hover:text-white transition-all rounded-xl group text-left"
                                                >
                                                  <Trash2 size={14} className="text-red-500 group-hover:text-white" />
                                                  Terminate User
                                                </button>
                                              </div>
                                            </motion.div>
                                          </>
                                        )}
                                      </AnimatePresence>
                                    </div>
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'Private Subscriptions' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="px-4">
                      <h3 className="text-4xl font-black text-slate-900 tracking-tight text-center lg:text-left">Private Sender Requests</h3>
                      <p className="text-slate-500 font-medium mt-2 text-center lg:text-left">Manage custom sender registrations and private service subscriptions.</p>
                   </div>

                  <div className="glass rounded-[2.5rem] border border-white/40 shadow-2xl overflow-hidden">
                    <div className="p-8 lg:p-10">
                      <div className="overflow-x-auto custom-scrollbar">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="border-b border-slate-100">
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest w-24">No.</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">User Name & Info</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Subscription Status</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Request Timeline</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {users
                              .sort((a, b) => {
                                const order: Record<string, number> = { 'pending': 0, 'approved': 1, 'none': 2 };
                                const aVal = a.privateSenderSubscription || 'none';
                                const bVal = b.privateSenderSubscription || 'none';
                                return (order[aVal] ?? 2) - (order[bVal] ?? 2);
                              })
                              .filter(u => u.role !== 'Admin')
                              .map((u, idx) => (
                                <tr key={u.id} className="border-b border-slate-50/50 hover:bg-slate-900/5 transition-all">
                                  <td className="py-6 px-4 font-black text-slate-400 text-xs tracking-tighter">#{String(idx + 1).padStart(2, '0')}</td>
                                  <td className="py-6 px-4">
                                    <div className="flex items-center gap-4">
                                      <div className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-[10px] font-black shadow-lg">
                                        {u.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                                      </div>
                                      <div>
                                        <p className="font-black text-slate-800 text-xs uppercase tracking-tight">{u.name}</p>
                                        <p className="text-[9px] text-slate-400 font-bold tracking-widest uppercase">{u.mobile}</p>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="py-6 px-4">
                                    <span className={`px-4 py-1.5 rounded-xl text-white text-[9px] font-black uppercase tracking-widest shadow-sm ${
                                      u.privateSenderSubscription === 'approved' ? 'bg-emerald-500' : 
                                      u.privateSenderSubscription === 'pending' ? 'bg-amber-500' : 'bg-slate-300'
                                    }`}>
                                      {u.privateSenderSubscription === 'approved' ? 'Active Clearance' : 
                                       u.privateSenderSubscription === 'pending' ? 'Pending Signal' : 'No Authorization'}
                                    </span>
                                  </td>
                                  <td className="py-6 px-4">
                                    {u.privateSenderSubscription === 'approved' ? (
                                      <div className="space-y-1.5 text-[9px] font-black uppercase tracking-widest">
                                        <p className="text-slate-400">INIT: <span className="text-slate-900">{u.privateSenderActivation ? new Date(u.privateSenderActivation).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }) : 'N/A'}</span></p>
                                        <p className="text-red-500">TERM: <span>{u.privateSenderExpiry ? new Date(u.privateSenderExpiry).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' }) : 'N/A'}</span></p>
                                      </div>
                                    ) : (
                                      <span className="text-[9px] font-black text-slate-200 uppercase tracking-widest">Inert Vector</span>
                                    )}
                                  </td>
                                  <td className="py-6 px-4 text-right">
                                    <div className="flex justify-end gap-3">
                                      {u.privateSenderSubscription === 'approved' ? (
                                        <button 
                                          onClick={() => {
                                            const updatedUser = { ...u, privateSenderSubscription: 'none' as const };
                                            delete updatedUser.privateSenderExpiry;
                                            delete updatedUser.privateSenderActivation;
                                            setUsers(prev => prev.map(user => user.id === u.id ? updatedUser as User : user));
                                            if (currentUser?.id === u.id) {
                                              setCurrentUser(updatedUser as User);
                                            }
                                            showToast(`Subscription revoked for ${u.name}.`, 'warning');
                                          }}
                                          className="bg-slate-900 border border-slate-800 text-white text-[9px] font-black uppercase tracking-[0.2em] px-6 py-2.5 rounded-xl hover:bg-red-600 hover:border-red-600 transition-all shadow-lg"
                                        >
                                          De-authorize
                                        </button>
                                      ) : (
                                        <>
                                          <button 
                                            onClick={() => {
                                              const now = new Date();
                                              const expiryDate = new Date();
                                              const months = u.privateSenderPendingDuration || 1;
                                              expiryDate.setMonth(expiryDate.getMonth() + months);
                                              const updatedUser = { 
                                                ...u, 
                                                privateSenderSubscription: 'approved' as const,
                                                privateSenderActivation: now.toISOString(),
                                                privateSenderExpiry: expiryDate.toISOString()
                                              };
                                              delete updatedUser.privateSenderPendingDuration;
                                              setUsers(prev => prev.map(user => user.id === u.id ? updatedUser as User : user));
                                              if (currentUser?.id === u.id) {
                                                setCurrentUser(updatedUser as User);
                                              }
                                              showToast(`Subscription approved for ${u.name}! ✅`);
                                            }}
                                            className="bg-emerald-500 text-white text-[9px] font-black uppercase tracking-[0.2em] px-6 py-2.5 rounded-xl hover:bg-emerald-600 transition-all shadow-lg"
                                          >
                                            {u.privateSenderSubscription === 'pending' ? 'Validate Signal' : 'Escalate Tier'}
                                          </button>
                                          {u.privateSenderSubscription === 'pending' && (
                                            <button 
                                              onClick={() => {
                                                const updatedUser = { ...u, privateSenderSubscription: 'none' as const };
                                                delete updatedUser.privateSenderExpiry;
                                                setUsers(prev => prev.map(user => user.id === u.id ? updatedUser as User : user));
                                                if (currentUser?.id === u.id) {
                                                  setCurrentUser(updatedUser as User);
                                                }
                                                showToast(`Subscription request rejected for ${u.name}. ❌`, 'error');
                                              }}
                                              className="bg-slate-200 text-slate-500 text-[9px] font-black uppercase tracking-[0.2em] px-6 py-2.5 rounded-xl hover:bg-red-500 hover:text-white transition-all shadow-sm"
                                            >
                                              Decline
                                            </button>
                                          )}
                                        </>
                                      )}
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            {users.length === 0 && (
                              <tr>
                                <td colSpan={5} className="py-24 text-center">
                                  <div className="flex flex-col items-center gap-4">
                                     <Globe size={48} className="text-slate-100" />
                                     <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest leading-loose">No active elevation requests detected within the local cluster.</p>
                                  </div>
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'Manage Transactions' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="px-4">
                      <h3 className="text-4xl font-black text-slate-900 tracking-tight text-center lg:text-left">Asset Ledger</h3>
                      <p className="text-slate-500 font-medium mt-2 text-center lg:text-left">Monitoring network-wide resource depletion and credit influx events.</p>
                   </div>

                  <div className="glass rounded-[2.5rem] border border-white/40 shadow-2xl overflow-hidden">
                    <div className="p-8 lg:p-10 space-y-10">
                      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8">
                        <div className="relative group flex-1 max-w-2xl">
                          <input 
                            type="text" 
                            placeholder="SEARCH TRANSACTION ID OR ENTITY..."
                            value={transactionSearchQuery || ''}
                            onChange={(e) => setTransactionSearchQuery(e.target.value)}
                            className="w-full bg-white/40 border-2 border-white/60 rounded-2xl pl-12 pr-6 py-4 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white focus:border-slate-900/20 transition-all shadow-inner"
                          />
                          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                        </div>
                        
                        <div className="flex flex-col md:flex-row gap-4">
                          <select 
                            className="bg-white/40 border-2 border-white/60 rounded-2xl px-6 py-4 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white shadow-inner appearance-none cursor-pointer pr-12"
                            value={transactionTypeFilter || 'All'}
                            onChange={(e) => setTransactionTypeFilter(e.target.value as any)}
                          >
                            <option value="All">Resource: All</option>
                            <option value="domestic">Resource: Domestic</option>
                            <option value="international">Resource: International</option>
                            <option value="button">Resource: Button</option>
                          </select>
                          <select 
                            className="bg-white/40 border-2 border-white/60 rounded-2xl px-6 py-4 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white shadow-inner appearance-none cursor-pointer pr-12"
                            value={transactionActionFilter || 'All'}
                            onChange={(e) => setTransactionActionFilter(e.target.value as any)}
                          >
                            <option value="All">Event: All</option>
                            <option value="Added">Signal: Influx</option>
                            <option value="Deducted">Signal: Depletion</option>
                          </select>
                          <button 
                            onClick={() => setShowRefundAnalytics(!showRefundAnalytics)}
                            className={`px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-xl active:scale-95 flex items-center gap-2 ${showRefundAnalytics ? 'bg-rose-500 text-white shadow-rose-500/20' : 'bg-amber-500 text-white shadow-amber-500/20'}`}
                          >
                            <History size={14} />
                            {showRefundAnalytics ? 'Close Analytics' : 'Refund Summary'}
                          </button>
                        </div>
                      </div>

                      {showRefundAnalytics ? (
                        <div className="space-y-6">
                           {/* 48-Hour Combined Refund Panel */}
                           {pending48HrRefundCampaigns.length > 0 ? (
                             <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20 p-6 rounded-3xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-md">
                               <div className="space-y-1">
                                 <h4 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
                                   <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                                   Pending 48-Hour Refunds Available
                                 </h4>
                                 <p className="text-xs font-semibold text-slate-600">
                                   There are <span className="font-black text-amber-600">{pending48HrRefundCampaigns.length} campaigns</span> older than 48 hours awaiting refund processing.
                                 </p>
                                 <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                   All campaign refunds for each user will be merged into a single combined entry instead of separate ones.
                                 </p>
                               </div>
                               <button
                                 onClick={handleProcessBulk48HrRefunds}
                                 className="px-6 py-3.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-black text-[10px] uppercase tracking-widest rounded-2xl shadow-lg shadow-amber-500/20 active:scale-95 transition-all flex items-center gap-2 shrink-0"
                               >
                                 <RefreshCw size={14} />
                                 Process Combined Refunds ({pending48HrRefundCampaigns.length})
                               </button>
                             </div>
                           ) : (
                             <div className="bg-emerald-50/50 border border-emerald-100 p-6 rounded-3xl flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-inner">
                               <div className="space-y-1">
                                 <h4 className="text-sm font-black text-emerald-800 uppercase tracking-wider flex items-center gap-2">
                                   Pending 48-Hour Refunds
                                 </h4>
                                 <p className="text-xs font-semibold text-slate-500">
                                   All completed campaigns older than 48 hours have been successfully refunded. No pending batch refunds found! ✨
                                 </p>
                               </div>
                             </div>
                           )}

                           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                              <div className="bg-indigo-50/50 p-6 rounded-3xl border border-indigo-100 flex flex-col gap-2">
                                <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em]">Total Refund Events</span>
                                <span className="text-3xl font-black text-indigo-600">{transactionStats.refundsCount}</span>
                              </div>
                              <div className="bg-emerald-50/50 p-6 rounded-3xl border border-emerald-100 flex flex-col gap-2">
                                <span className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.2em]">Total Credits Refunded</span>
                                <span className="text-3xl font-black text-emerald-600">{transactionStats.totalRefunded.toLocaleString()}</span>
                              </div>
                              <div className="bg-amber-50/50 p-6 rounded-3xl border border-amber-100 flex flex-col gap-2">
                                <span className="text-[10px] font-black text-amber-400 uppercase tracking-[0.2em]">Affected Entities</span>
                                <span className="text-3xl font-black text-amber-600">{transactionStats.totalUsers}</span>
                              </div>
                           </div>

                           <div className="overflow-x-auto custom-scrollbar">
                            <table className="w-full text-left border-collapse">
                              <thead>
                                <tr className="border-b border-slate-100">
                                  <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Entity Name</th>
                                  <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Entity ID</th>
                                  <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Refund Count</th>
                                  <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Total Credits Refunded</th>
                                  <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Last Signal</th>
                                </tr>
                              </thead>
                              <tbody>
                                {userRefundAnalytics.map(([uid, data]) => {
                                  const u = users.find(user => user.id === uid);
                                  return (
                                    <tr key={uid} className="border-b border-slate-50/50 hover:bg-slate-900/5 transition-all">
                                      <td className="py-6 px-4">
                                        <span className="text-[10px] font-black text-slate-800 uppercase tracking-tight">{u?.name || 'TERMINATED ENTITY'}</span>
                                      </td>
                                      <td className="py-6 px-4">
                                        <span className="font-mono text-[9px] font-black text-slate-400 tracking-tighter uppercase">{uid.substring(0, 12)}...</span>
                                      </td>
                                      <td className="py-6 px-4">
                                        <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest bg-slate-100 px-3 py-1 rounded-lg">
                                          {data.count} Events
                                        </span>
                                      </td>
                                      <td className="py-6 px-4">
                                        <span className="text-[11px] font-black text-emerald-600">
                                          +{data.total.toLocaleString()}
                                        </span>
                                      </td>
                                      <td className="py-6 px-4">
                                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                          {new Date(data.lastDate).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}
                                        </span>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                           </div>
                        </div>
                      ) : (
                        <div className="overflow-x-auto custom-scrollbar">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="border-b border-slate-100">
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Chronos ID</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Entity Target</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Asset Magnitude</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Resource Class</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Signal State</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Time Index</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">System Notes</th>
                            </tr>
                          </thead>
                          <tbody>
                            {transactions
                              .filter(t => currentUser.role === 'Admin' || t.userId === currentUser.id || users.find(u => u.id === t.userId)?.uplink === currentUser.id || users.find(u => u.id === t.userId)?.uplink === currentUser.name)
                              .filter(t => transactionTypeFilter === 'All' ? true : t.type === transactionTypeFilter)
                              .filter(t => transactionActionFilter === 'All' ? true : t.action === transactionActionFilter)
                              .filter(t => t.note.toLowerCase().includes(transactionSearchQuery.toLowerCase()) || t.userId.toLowerCase().includes(transactionSearchQuery.toLowerCase()))
                              .map((tx) => {
                                const user = users.find(u => u.id === tx.userId);
                                return (
                                  <tr key={tx.id} className="border-b border-slate-50/50 hover:bg-slate-900/5 transition-all">
                                    <td className="py-6 px-4">
                                       <span className="font-mono text-[9px] font-black text-slate-400 tracking-tighter uppercase">{tx.id.substring(0, 12)}...</span>
                                    </td>
                                    <td className="py-6 px-4">
                                      <div className="flex flex-col gap-0.5">
                                        <span className="text-[10px] font-black text-slate-800 uppercase tracking-tight">{user?.name || 'TERMINATED ENTITY'}</span>
                                        <span className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">{user?.role || 'ORPHAN'}</span>
                                      </div>
                                    </td>
                                    <td className="py-6 px-4">
                                       <span className={`text-[11px] font-black ${tx.action === 'Added' ? 'text-emerald-600' : 'text-red-500'}`}>
                                          {tx.action === 'Added' ? '+' : '-'}{tx.amount}
                                       </span>
                                    </td>
                                    <td className="py-6 px-4">
                                       <span className="text-[9px] font-black text-indigo-500 uppercase tracking-widest bg-indigo-50 px-3 py-1 rounded-lg">
                                          {tx.type}
                                       </span>
                                    </td>
                                    <td className="py-6 px-4">
                                       <div className={`w-3 h-3 rounded-full shadow-inner ${tx.action === 'Added' ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`} />
                                    </td>
                                    <td className="py-6 px-4">
                                       <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                                          {new Date(tx.date).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}
                                       </span>
                                    </td>
                                    <td className="py-6 px-4">
                                       <span className="text-[10px] font-black text-slate-600 uppercase tracking-tight leading-relaxed max-w-xs block">
                                          {tx.note}
                                       </span>
                                    </td>
                                  </tr>
                                );
                              })}
                            {transactions.length === 0 && (
                              <tr>
                                <td colSpan={7} className="py-24 text-center">
                                  <div className="flex flex-col items-center gap-4">
                                     <History size={48} className="text-slate-100" />
                                     <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest leading-loose">No transactional events recorded in the current matrix.</p>
                                  </div>
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    )}
                    </div>
                  </div>
                </div>
              )}

              {(currentPage === 'Non Whatsapp Number' || currentPage === 'White Listing Number' || currentPage === 'White Listing DB') && (
                <NumberSearchPage 
                  title={currentPage === 'Non Whatsapp Number' ? 'Search With Number' : (currentPage === 'White Listing DB' ? 'White Listing Database' : 'White Listing Number')}
                  records={currentPage === 'Non Whatsapp Number' ? nonWhatsappRecords : whitelistRecords}
                  onSearch={() => handleNumberAction('search', currentPage !== 'Non Whatsapp Number')}
                  onAdd={() => handleNumberAction('add', currentPage !== 'Non Whatsapp Number')}
                  onDelete={() => handleNumberAction('delete', currentPage !== 'Non Whatsapp Number')}
                  onBulkUpload={(file) => handleBulkUpload(file, currentPage !== 'Non Whatsapp Number')}
                  onClearAll={() => {
                    if (currentPage === 'Non Whatsapp Number') {
                      setNonWhatsappRecords([]);
                      showToast('Non-WhatsApp intercept logs cleared! 🧼');
                    } else {
                      setWhitelistRecords([]);
                      showToast('White Listing intercept logs cleared! 🧼');
                    }
                  }}
                  onRemoveRecord={(id) => currentPage === 'Non Whatsapp Number' ? setNonWhatsappRecords(nonWhatsappRecords.filter(r => r.id !== id)) : setWhitelistRecords(whitelistRecords.filter(r => r.id !== id))}
                  searchNumber={searchNumber}
                  setSearchNumber={setSearchNumber}
                  searchOption={searchOption}
                  setSearchOption={setSearchOption}
                  searchCountry={searchCountry}
                  setSearchCountry={setSearchCountry}
                />
              )}

              {currentPage === 'Campaign Config' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="px-4 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
                      <div className="text-center lg:text-left">
                        <h3 className="text-4xl font-black text-slate-900 tracking-tight">System Protocol</h3>
                        <p className="text-slate-500 font-medium mt-2 text-center lg:text-left">Global configuration parameters for multi-tier campaign execution.</p>
                      </div>
                      <button 
                        onClick={handleOpenUpdateModal}
                        className="bg-slate-900 text-white text-[10px] font-black uppercase tracking-[0.2em] px-10 py-5 rounded-[2rem] hover:scale-105 transition-all shadow-2xl active:scale-95"
                      >
                        Push New Protocol
                      </button>
                   </div>

                  <div className="glass rounded-[2.5rem] border border-white/40 shadow-2xl overflow-hidden">
                    <div className="flex border-b border-slate-100/50 bg-white/40">
                      {(['General', 'Domestic', 'International', 'Button'] as const).map((tab) => (
                        <button
                          key={tab}
                          onClick={() => setConfigTab(tab)}
                          className={`flex-1 px-8 py-6 text-[10px] font-black uppercase tracking-widest transition-all border-b-4 ${
                            configTab === tab ? 'border-indigo-500 text-indigo-600 bg-white/60' : 'border-transparent text-slate-400 hover:text-slate-600'
                          }`}
                        >
                          {tab} Grid
                        </button>
                      ))}
                    </div>

                    <div className="p-8 lg:p-10 overflow-x-auto custom-scrollbar">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-100">
                            <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest w-24">Index</th>
                            <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Protocol Identifier</th>
                            <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Payload Magnitude</th>
                          </tr>
                        </thead>
                        <tbody>
                          {configTab === 'General' && generalConfigs.map((config, idx) => (
                            <tr key={config.id} className="border-b border-slate-50/50 hover:bg-slate-900/5 transition-all">
                              <td className="py-6 px-4 font-black text-slate-400 text-xs tracking-tighter">#{String(idx + 1).padStart(2, '0')}</td>
                              <td className="py-6 px-4 font-black text-slate-800 text-xs uppercase tracking-tight">{config.name}</td>
                              <td className="py-6 px-4">
                                <span className="bg-indigo-50 text-indigo-600 text-[10px] font-black px-4 py-1.5 rounded-lg border border-indigo-100 uppercase tracking-widest shadow-sm">
                                  {config.size} Units
                                </span>
                              </td>
                            </tr>
                          ))}
                          {configTab === 'Domestic' && domesticConfigs.map((config, idx) => (
                            <tr key={config.id} className="border-b border-slate-50/50 hover:bg-slate-900/5 transition-all">
                              <td className="py-6 px-4 font-black text-slate-400 text-xs tracking-tighter">#{String(idx + 1).padStart(2, '0')}</td>
                              <td className="py-6 px-4 font-black text-slate-800 text-xs uppercase tracking-tight">{config.name}</td>
                              <td className="py-6 px-4">
                                <span className="bg-emerald-50 text-emerald-600 text-[10px] font-black px-4 py-1.5 rounded-lg border border-emerald-100 uppercase tracking-widest shadow-sm">
                                  {config.size} Units
                                </span>
                              </td>
                            </tr>
                          ))}
                          {configTab === 'International' && internationalConfigs.map((config, idx) => (
                            <tr key={config.id} className="border-b border-slate-50/50 hover:bg-slate-900/5 transition-all">
                              <td className="py-6 px-4 font-black text-slate-400 text-xs tracking-tighter">#{String(idx + 1).padStart(2, '0')}</td>
                              <td className="py-6 px-4 font-black text-slate-800 text-xs uppercase tracking-tight">{config.name}</td>
                              <td className="py-6 px-4">
                                <span className="bg-amber-50 text-amber-600 text-[10px] font-black px-4 py-1.5 rounded-lg border border-amber-100 uppercase tracking-widest shadow-sm">
                                  {config.size} Units
                                </span>
                              </td>
                            </tr>
                          ))}
                          {configTab === 'Button' && buttonConfigs.map((config, idx) => (
                            <tr key={config.id} className="border-b border-slate-50/50 hover:bg-slate-900/5 transition-all">
                              <td className="py-6 px-4 font-black text-slate-400 text-xs tracking-tighter">#{String(idx + 1).padStart(2, '0')}</td>
                              <td className="py-6 px-4 font-black text-slate-800 text-xs uppercase tracking-tight">{config.name}</td>
                              <td className="py-6 px-4">
                                <span className="bg-indigo-50/50 text-indigo-700 text-[10px] font-black px-4 py-1.5 rounded-lg border border-indigo-200 uppercase tracking-widest shadow-sm">
                                  {config.size} Units
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'Cities' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="px-4 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
                      <div className="text-center lg:text-left">
                        <h3 className="text-4xl font-black text-slate-900 tracking-tight text-center lg:text-left">Zone Ledger</h3>
                        <p className="text-slate-500 font-medium mt-2 text-center lg:text-left">Geospatial endpoint indexing for localized campaign targeting.</p>
                      </div>
                      <div className="flex flex-col sm:flex-row items-center gap-4">
                        <div className="bg-white/40 px-6 py-4 rounded-2xl border border-white/60 shadow-inner flex items-center gap-3">
                           <Globe size={16} className="text-slate-400" />
                           <span className="text-[10px] font-black text-slate-600 uppercase tracking-[0.1em]">Total Active Zones: <span className="text-slate-900">{cities.length}</span></span>
                        </div>
                        <button 
                          onClick={() => setIsAddCityModalOpen(true)}
                          className="bg-emerald-500 text-white text-[10px] font-black uppercase tracking-[0.2em] px-10 py-5 rounded-[2rem] hover:scale-105 transition-all shadow-2xl active:scale-95 flex items-center gap-2"
                        >
                          <PlusCircle size={16} />
                          Inject Zone
                        </button>
                      </div>
                   </div>

                  <div className="glass rounded-[2.5rem] border border-white/40 shadow-2xl overflow-hidden">
                    <div className="p-8 lg:p-10 space-y-10">
                      <div className="relative group max-w-2xl">
                        <input 
                          type="text" 
                          placeholder="SCAN FOR SPECIFIC ZONE..."
                          value={userSearchQuery || ''}
                          onChange={(e) => setUserSearchQuery(e.target.value)}
                          className="w-full bg-white/40 border-2 border-white/60 rounded-2xl pl-12 pr-6 py-4 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:bg-white focus:border-slate-900/20 transition-all shadow-inner"
                        />
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                      </div>

                      <div className="overflow-x-auto custom-scrollbar">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="border-b border-slate-100">
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest w-24">Index</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Zone Designation</th>
                              <th className="py-6 px-4 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right">Termination</th>
                            </tr>
                          </thead>
                          <tbody>
                            {cities
                              .filter(city => city.toLowerCase().includes(userSearchQuery.toLowerCase()))
                              .map((city, idx) => (
                                <tr key={idx} className="border-b border-slate-50/50 hover:bg-slate-900/5 transition-all group">
                                  <td className="py-6 px-4 font-black text-slate-400 text-xs tracking-tighter">#{String(idx + 1).padStart(3, '0')}</td>
                                  <td className="py-6 px-4 font-black text-slate-800 text-xs uppercase tracking-tight">{city}</td>
                                  <td className="py-6 px-4 text-right">
                                    <button 
                                      onClick={() => handleDeleteCity(city)}
                                      className="p-3 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all"
                                      title="Purge Zone"
                                    >
                                      <Trash2 size={18} />
                                    </button>
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'Admin Staff' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
                   <div className="px-4 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
                      <div className="text-center lg:text-left">
                        <h3 className="text-4xl font-black text-slate-900 tracking-tight text-center lg:text-left">Staff Management</h3>
                        <p className="text-slate-500 font-medium mt-2 text-center lg:text-left">Manage administrative operators, team member accounts, and assign system access permissions.</p>
                      </div>
                      <button 
                        onClick={() => {
                          setEditingAdmin(null);
                          setAdminForm({
                            name: '',
                            email: '',
                            password: '',
                            status: 'Active',
                            accesses: {}
                          });
                          setIsEditAdminModalOpen(true);
                        }}
                        className="bg-slate-900 text-white text-[10px] font-black uppercase tracking-[0.2em] px-10 py-5 rounded-[2rem] hover:scale-105 transition-all shadow-2xl active:scale-95 flex items-center gap-2"
                      >
                        <UserPlus size={16} />
                        Add Staff Member
                      </button>
                   </div>

                  <div className="glass rounded-[2.5rem] border border-white/40 shadow-2xl overflow-hidden text-center lg:text-left">
                    <div className="overflow-x-auto custom-scrollbar">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-100 bg-white/40">
                            <th className="py-8 px-8 text-[9px] font-black text-slate-400 uppercase tracking-widest w-24">No.</th>
                            <th className="py-8 px-8 text-[9px] font-black text-slate-400 uppercase tracking-widest">Operator Name</th>
                            <th className="py-8 px-8 text-[9px] font-black text-slate-400 uppercase tracking-widest">Email Address</th>
                            <th className="py-8 px-8 text-[9px] font-black text-slate-400 uppercase tracking-widest">Status</th>
                            <th className="py-8 px-8 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {adminStaff.map((admin, idx) => (
                            <tr key={admin.id} className="border-b border-slate-50/50 hover:bg-slate-900/5 transition-all">
                              <td className="py-8 px-8 font-black text-slate-400 text-xs tracking-tighter">#{String(idx + 1).padStart(2, '0')}</td>
                              <td className="py-8 px-8">
                                <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center text-[10px] font-black shadow-lg">
                                    {admin.name[0].toUpperCase()}
                                  </div>
                                  <span className="font-black text-slate-800 text-xs uppercase tracking-tight">{admin.name}</span>
                                </div>
                              </td>
                              <td className="py-8 px-8">
                                 <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{admin.email}</span>
                              </td>
                              <td className="py-8 px-8">
                                <span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm ${
                                  admin.status === 'Active' ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white'
                                }`}>
                                  {admin.status === 'Active' ? 'Active' : 'Inactive'}
                                </span>
                              </td>
                              <td className="py-8 px-8 text-right">
                                <button 
                                  onClick={() => handleEditAdmin(admin)}
                                  className="bg-white border border-slate-200 text-slate-900 text-[9px] font-black uppercase tracking-[0.2em] px-6 py-2.5 rounded-xl hover:bg-slate-900 hover:text-white transition-all shadow-sm"
                                >
                                  Modify Access
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'Terms & Conditions' && !isManagingTerms && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 animate-in fade-in duration-500">
                  <div className="px-4 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
                     <div className="text-center lg:text-left">
                       <h3 className="text-4xl font-black text-slate-900 tracking-tight">Terms & Conditions</h3>
                       <p className="text-slate-500 font-medium mt-2">Guidelines, compliance requirements, and system operational limits.</p>
                     </div>
                     {currentUser?.role === 'Admin' && (
                       <button 
                         onClick={() => {
                           setEditTermsContent(termsContent);
                           setIsManagingTerms(true);
                           setManageTermsTab('Edit');
                         }}
                         className="bg-slate-900 text-white text-[10px] font-black uppercase tracking-[0.2em] px-10 py-5 rounded-[2rem] hover:scale-105 transition-all shadow-2xl active:scale-95 flex items-center gap-2 self-center lg:self-auto"
                       >
                         <Settings size={16} />
                         Manage Terms & Conditions
                       </button>
                     )}
                  </div>

                  <div className="px-4">
                    <div className="glass rounded-[3rem] border border-white/40 shadow-2xl p-10 lg:p-12 font-sans backdrop-blur-md bg-white/40 relative">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10 border-b border-slate-900/10 pb-8">
                         <div className="flex items-center gap-4">
                            <div className="w-14 h-14 rounded-2xl bg-indigo-550 border border-indigo-400 text-white flex items-center justify-center shadow-lg"><FileText size={28} /></div>
                            <div>
                               <h4 className="text-xl font-black text-slate-900 uppercase tracking-tight">Official Panel Policy</h4>
                               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ensuring transmission integrity and platform standard operational policy</p>
                            </div>
                         </div>
                         <div>
                            <span className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-2xl text-[9px] font-black text-indigo-600 bg-white/60 border border-white/85 uppercase tracking-[0.15em] shadow-sm">
                              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
                              Last updated: {lastUpdatedTerms}
                            </span>
                         </div>
                      </div>
                      
                      <div className="prose prose-slate max-w-none text-slate-800 font-semibold leading-relaxed space-y-4">
                        <Markdown>{termsContent}</Markdown>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {currentPage === 'Terms & Conditions' && isManagingTerms && currentUser?.role === 'Admin' && (
                <div className="max-w-7xl mx-auto space-y-12 pb-20 animate-in fade-in duration-500">
                  <div className="px-4 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
                     <div className="text-center lg:text-left">
                       <h3 className="text-4xl font-black text-slate-900 tracking-tight">Terms Control Center</h3>
                       <p className="text-slate-500 font-medium mt-2">Manage customer agreements, system limits, transmission policies, and compliance statements.</p>
                     </div>
                     <button 
                       onClick={() => setIsManagingTerms(false)}
                       className="bg-slate-900 text-white text-[10px] font-black uppercase tracking-[0.2em] px-10 py-5 rounded-[2rem] hover:scale-105 transition-all shadow-2xl active:scale-95 flex items-center gap-2 self-center lg:self-auto"
                     >
                       <Globe size={16} />
                       View Live Page
                     </button>
                  </div>

                  <div className="px-4">
                    <div className="glass rounded-[3rem] border border-white/40 shadow-2xl overflow-hidden bg-white/40 backdrop-blur-lg">
                      <div className="p-10 border-b border-slate-900/10 bg-white/50 flex flex-col sm:flex-row justify-between items-center gap-6">
                        <div className="flex border border-slate-950/5 pb-0 bg-white/40 p-1.5 rounded-2xl gap-1 w-full sm:w-auto">
                          {(['Edit', 'Preview', 'History'] as const).map((tab) => (
                            <button
                              key={tab}
                              onClick={() => setManageTermsTab(tab)}
                              className={`flex-1 sm:flex-initial px-8 py-3 text-[10px] font-black uppercase tracking-[0.15em] transition-all rounded-xl ${
                                manageTermsTab === tab 
                                  ? 'bg-slate-900 text-white shadow-md' 
                                  : 'text-slate-500 hover:text-slate-950 hover:bg-white/50'
                              }`}
                            >
                              {tab}
                            </button>
                          ))}
                        </div>

                        {manageTermsTab === 'Edit' && (
                          <button 
                            onClick={() => setEditTermsContent(`# WhatsApp Campaign Terms & Conditions

## WhatsApp Campaign Limitations:

1. All WhatsApp Campaigns sent may not be visible on Web WhatsApp.
2. WhatsApp Campaign may not reach iPhones all the time, due to iPhone security issues.
3. Every number sent from our Panel will show as SENT only always in reports.
4. The delivery success ratio will be approximately 60% to 80%, because 20%-40% may not get delivered or may show waiting for message, due to channel (WhatsApp number) Ban issues in WhatsApp.
5. Buttons Campaign will be allowed with 01 Media Only (01 image or 01 video or 01 PDF).
6. Buttons Campaigns are available for INDIA only.
7. Button Campaign may take a minimum of 30-240 minutes to deliver.
8. No Elections Campaigns allowed for Button Campaign.
9. Max Allowed size for image/video/pdf is 5MB each only.
10. Max up to 02 Lacs numbers can be sent in a single campaign.
11. Delivery time 02-04 Hrs.
12. Can be sent Monday to Saturday between 10 am to 06 pm IST only.
13. Max 03 Demo campaigns (less than 10 numbers) allowed in a day.
14. Max 10 campaigns allowed in a day.
15. All non-WhatsApp number credits would be refunded after 48 Hrs.

Note: Before pushing anything in bulk, please test by sending to your own 5-10 numbers to ensure everything is fine because once sent cannot be undone.`)}
                            className="w-full sm:w-auto hover:bg-white border border-slate-200 text-slate-850 text-[9px] font-black uppercase tracking-widest px-6 py-3.5 rounded-xl bg-white/60 transition-all flex items-center justify-center gap-2"
                          >
                            Reset Default Content
                          </button>
                        )}
                      </div>

                      <div className="p-10 lg:p-12">
                        {manageTermsTab === 'Edit' && (
                          <div className="space-y-6">
                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 pl-1">Document Content (Markdown Editor)</p>
                            <textarea 
                              value={editTermsContent || ''}
                              onChange={(e) => setEditTermsContent(e.target.value)}
                              rows={18}
                              className="w-full bg-white/40 border border-white/60 rounded-[2rem] p-8 text-sm font-mono text-slate-800 placeholder:text-slate-350 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all shadow-inner resize-none focus:shadow-md"
                              placeholder="Write terms and conditions content..."
                            />

                            <div className="flex items-center gap-4 pt-4">
                              <button 
                                onClick={handleSaveTerms}
                                className="bg-emerald-500 text-white text-[10px] font-black uppercase tracking-[0.2em] px-10 py-5 rounded-[2rem] hover:scale-105 hover:bg-emerald-600 transition-all shadow-2xl active:scale-95 flex items-center gap-2"
                              >
                                <CheckCircle size={16} />
                                Save & Publish
                              </button>
                              <button 
                                onClick={() => setManageTermsTab('Preview')}
                                className="bg-slate-900 text-white text-[10px] font-black uppercase tracking-[0.2em] px-10 py-5 rounded-[2rem] hover:scale-105 transition-all shadow-2xl active:scale-95 flex items-center gap-2"
                              >
                                Preview Style
                              </button>
                            </div>
                          </div>
                        )}

                        {manageTermsTab === 'Preview' && (
                          <div className="space-y-6">
                            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Live Preview Container</h4>
                            <div className="p-10 border border-white/80 rounded-[2rem] bg-white/60 shadow-inner prose prose-slate max-w-none text-slate-850 leading-relaxed font-semibold">
                              <Markdown>{editTermsContent}</Markdown>
                            </div>
                          </div>
                        )}

                        {manageTermsTab === 'History' && (
                          <div className="space-y-6">
                            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Publishing Trail</h4>
                            <div className="overflow-hidden border border-white/50 rounded-[2rem] bg-white/40 shadow-inner">
                              <table className="w-full text-left border-collapse">
                                <thead>
                                  <tr className="bg-white/40 border-b border-white/60">
                                    <th className="py-5 px-8 text-[10px] font-black text-slate-400 uppercase tracking-widest w-24">Ver</th>
                                    <th className="py-5 px-8 text-[10px] font-black text-slate-400 uppercase tracking-widest">Publish Date</th>
                                    <th className="py-5 px-8 text-[10px] font-black text-slate-400 uppercase tracking-widest">Authorized Op</th>
                                    <th className="py-5 px-8 text-[10px] font-black text-slate-400 uppercase tracking-widest">Content Snapshot</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {termsHistory.map((h) => (
                                    <tr key={h.version} className="border-b border-white/20 last:border-0 hover:bg-white/25 transition-all">
                                      <td className="py-5 px-8 text-xs font-black text-indigo-600">v{h.version}</td>
                                      <td className="py-5 px-8 text-xs font-bold text-slate-600">{h.lastUpdated}</td>
                                      <td className="py-5 px-8 text-xs font-bold text-slate-700">{h.updatedBy}</td>
                                      <td className="py-5 px-8 text-xs font-mono text-slate-500 truncate max-w-xs">{h.content}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Add City Modal */}
              <AnimatePresence>
                {rejectingCampaignId && (
                  <RejectModal 
                    onReject={handleRejectCampaign}
                    onClose={() => setRejectingCampaignId(null)}
                  />
                )}
                {selectedUserForCampaigns && (
                  <UserCampaignsModal 
                    user={selectedUserForCampaigns}
                    campaigns={campaigns.filter(c => c.userId === selectedUserForCampaigns.id)}
                    onClose={() => setSelectedUserForCampaigns(null)}
                    onViewCampaign={(c) => {
                      setSelectedCampaign(c);
                    }}
                    onReport={handleCampaignReportClick}
                    onEdit={currentUser.role === 'Admin' ? setEditingCampaign : undefined}
                    onTestMessage={handleTestMessage}
                    onReset={handleResetCampaign}
                    onRestore={handleRestoreCampaign}
                    onRefundNonWA={handleRefundNonWA}
                  />
                )}
                {managingCreditsUser && (
                  <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9, y: 30 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: 30 }}
                      className="glass rounded-[3rem] shadow-2xl w-full max-w-md overflow-hidden border border-white/40 flex flex-col"
                    >
                      <div className="p-10 border-b border-white/20 flex justify-between items-center bg-white/40">
                        <div className="space-y-1">
                          <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">Asset Reallocation</h3>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{managingCreditsUser.name} | Identifier {managingCreditsUser.id.substring(0, 8)}</p>
                        </div>
                        <button onClick={() => setManagingCreditsUser(null)} className="w-10 h-10 bg-white/60 hover:bg-white rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group">
                          <X size={20} className="group-hover:rotate-90 transition-transform" />
                        </button>
                      </div>

                      <div className="p-10 space-y-10 bg-white/10">
                        <div className="grid grid-cols-2 gap-5">
                          {[
                            { action: 'Add', icon: Plus, color: 'emerald' },
                            { action: 'Remove', icon: Minus, color: 'rose' }
                          ].map((opt) => (
                            <button 
                              key={opt.action}
                              onClick={() => setCreditAction(opt.action as any)}
                              className={`py-5 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all border-2 ${
                                creditAction === opt.action 
                                  ? `border-slate-900 bg-white text-slate-900 shadow-xl scale-[1.02]` 
                                  : 'border-white/40 text-slate-400 hover:bg-white/40'
                              }`}
                            >
                              <opt.icon size={14} className={creditAction === opt.action ? `text-${opt.color}-500` : ''} />
                              {opt.action} Funds
                            </button>
                          ))}
                        </div>

                        <div className="space-y-4">
                          <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Asset Category</label>
                          <div className="grid grid-cols-3 gap-3">
                            {['Domestic', 'International', 'Button'].map((type) => (
                              <button 
                                key={type}
                                onClick={() => setCreditType(type as any)}
                                className={`py-4 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all border ${
                                  creditType === type 
                                    ? 'bg-slate-900 text-white shadow-lg' 
                                    : 'bg-white/40 text-slate-400 border-white/60 hover:bg-white/60'
                                }`}
                              >
                                {type}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Transaction Vector</label>
                          <div className="relative">
                            <input 
                              type="number" 
                              value={creditAmount || ''}
                              onChange={(e) => setCreditAmount(e.target.value)}
                              placeholder="0.00"
                              className="w-full bg-white/40 border border-white/60 rounded-2xl px-6 py-5 text-lg font-black text-slate-900 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner text-center"
                            />
                            <div className="absolute right-6 top-1/2 -translate-y-1/2 text-[10px] font-black text-slate-400 uppercase tracking-widest">Units</div>
                          </div>
                        </div>
                      </div>

                      <div className="p-10 bg-white/40 border-t border-white/20">
                        <button 
                          onClick={handleUpdateCredits}
                          className={`w-full py-6 rounded-[2rem] text-[10px] font-black uppercase tracking-[0.3em] shadow-2xl transition-all active:scale-[0.98] text-white ${
                            creditAction === 'Add' ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-rose-500 hover:bg-rose-600'
                          }`}
                        >
                          Execute {creditAction} Protocol
                        </button>
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] text-center mt-6">All transactions recorded in the immutable audit log</p>
                      </div>
                    </motion.div>
                  </div>
                )}
              </AnimatePresence>

      {selectedCampaign && (
        <CampaignDetailsModal 
          campaign={selectedCampaign} 
          mockDb={mockDb}
          nonWaDb={nonWaDb}
          allCampaigns={campaigns}
          onClose={() => setSelectedCampaign(null)} 
          onEdit={currentUser.role === 'Admin' ? setEditingCampaign : undefined}
          isAdmin={currentUser.role === 'Admin' || currentUser.role === 'Reseller'}
          isSystemAdmin={currentUser.role === 'Admin'}
          onCSVDownload={handleCSVDownload}
          onWhitelistingDownload={handleWhitelistingDownload}
          onWhitelistingCommonDownload={handleWhitelistingCommonDownload}
        />
      )}
        {isPrivateSenderSubscribing && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              className="glass rounded-[3rem] shadow-2xl w-full max-w-lg overflow-hidden flex flex-col border border-white/40"
            >
              <div className="p-10 border-b border-white/20 flex justify-between items-center bg-white/40">
                <div className="space-y-1">
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight uppercase flex items-center gap-3">
                    <CreditCard size={24} className="text-indigo-600" />
                    Premium
                  </h3>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Escalate your operational capabilities</p>
                </div>
                <button onClick={() => setIsPrivateSenderSubscribing(false)} className="w-10 h-10 bg-white/60 hover:bg-white rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group">
                  <X size={20} className="group-hover:rotate-90 transition-transform" />
                </button>
              </div>

              <div className="p-10 space-y-8 overflow-y-auto max-h-[60vh] custom-scrollbar bg-white/10">
                <div className="grid grid-cols-1 gap-4">
                  {[
                    { name: 'Standard', price: 2999, duration: 1, unit: 'month' },
                    { name: 'Elite', price: 7499, duration: 3, unit: 'month' },
                    { name: 'Prime', price: 23999, duration: 12, unit: 'month' }
                  ].map((plan, idx) => (
                    <div 
                      key={idx}
                      onClick={() => setSelectedPlan(plan as any)}
                      className={`p-6 rounded-[2rem] border-2 cursor-pointer transition-all ${
                        selectedPlan.name === plan.name ? 'border-slate-900 bg-white shadow-xl scale-[1.02]' : 'border-white/40 hover:bg-white/40'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <div className="space-y-1">
                          <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">{plan.name}</h4>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{plan.duration} {plan.unit}{plan.duration > 1 ? 's' : ''} Access Protocol</p>
                        </div>
                        <div className="text-right">
                          <span className="text-2xl font-black text-slate-900 tracking-tighter">₹{plan.price}</span>
                          {selectedPlan.name === plan.name && (
                            <div className="flex justify-end mt-1">
                              <CheckCircle size={16} className="text-emerald-500" />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="space-y-4 px-2">
                  <h5 className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em]">Escalation Benefits</h5>
                  <ul className="space-y-4">
                    {[
                      'Infinite Endpoint Connections',
                      'Diagnostic Status Telemetry',
                      'Strategic Support Access',
                      'Account Integrity Protection'
                    ].map((feature, i) => (
                      <li key={i} className="flex items-center gap-4 text-[11px] font-bold text-slate-600">
                        <div className="w-5 h-5 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-600 flex-shrink-0">
                          <Check size={12} />
                        </div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="p-10 bg-white/40 border-t border-white/20 space-y-6">
                <button 
                  onClick={() => {
                    const updatedUser: User = { 
                      ...currentUser, 
                      privateSenderSubscription: 'pending' as const,
                      privateSenderPendingDuration: selectedPlan.duration
                    };
                    delete updatedUser.privateSenderActivation;
                    delete updatedUser.privateSenderExpiry;
                    setCurrentUser(updatedUser);
                    setUsers(prev => prev.map(u => u.id === currentUser.id ? updatedUser : u));
                    setIsPrivateSenderSubscribing(false);
                    showToast(`Subscription requested! Awaiting admin approval. ⏳`);
                  }}
                  className="w-full py-6 bg-slate-900 hover:bg-black text-white font-black text-xs uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98]"
                >
                  Confirm Authorization
                </button>
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Protocol Secured via 256-Bit Entropy Encryption</p>
              </div>
            </motion.div>
          </div>
        )}


                {isAddCityModalOpen && (
                  <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9, y: 20 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: 20 }}
                      className="glass rounded-[3rem] shadow-2xl w-full max-w-lg overflow-hidden border border-white/40"
                    >
                      <div className="flex items-center justify-between p-10 border-b border-white/20 bg-white/40">
                        <div className="space-y-1">
                           <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">Expand Matrix</h3>
                           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Register new geographical coordinate</p>
                        </div>
                        <button 
                          onClick={() => setIsAddCityModalOpen(false)}
                          className="w-10 h-10 bg-white/60 hover:bg-white rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group"
                        >
                          <X size={20} className="group-hover:rotate-90 transition-transform" />
                        </button>
                      </div>
                      
                      <div className="p-10 space-y-8 bg-white/10">
                        <div className="space-y-3">
                          <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Entity Name / Location</label>
                          <input 
                            type="text" 
                            placeholder="Type location identifier..."
                            value={newCityName || ''}
                            onChange={(e) => setNewCityName(e.target.value)}
                            className="w-full bg-white/40 border border-white/60 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                            autoFocus
                            onKeyDown={(e) => e.key === 'Enter' && handleAddCity()}
                          />
                        </div>
                      </div>

                      <div className="p-10 bg-white/40 border-t border-white/20 flex gap-4">
                        <button 
                          onClick={() => setIsAddCityModalOpen(false)}
                          className="flex-1 px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-slate-900 rounded-2xl transition-all"
                        >
                          Abort
                        </button>
                        <button 
                          onClick={handleAddCity}
                          className="flex-1 px-8 py-5 text-[10px] font-black text-white bg-slate-900 hover:bg-black rounded-[2rem] shadow-2xl transition-all active:scale-[0.98]"
                        >
                          Index City
                        </button>
                      </div>
                    </motion.div>
                  </div>
                )}
              
              {/* Edit Admin Staff Modal */}
              <AnimatePresence>
                {isEditAdminModalOpen && (
                  <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95, y: 20 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95, y: 20 }}
                      className="glass rounded-[3rem] shadow-2xl w-full max-w-3xl overflow-hidden border border-white/40 flex flex-col max-h-[90vh]"
                    >
                      <div className="flex items-center justify-between p-10 border-b border-white/20 bg-white/40 flex-shrink-0">
                        <div className="space-y-1">
                          <h3 className="text-2xl font-black text-slate-900 tracking-tight uppercase">{editingAdmin ? 'Edit Staff Member' : 'Add Staff Member'}</h3>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{editingAdmin ? 'Update staff credentials and permissions' : 'Create a new operator account and assign privileges'}</p>
                        </div>
                        <button 
                          onClick={() => setIsEditAdminModalOpen(false)}
                          className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm border border-white/60 group"
                        >
                          <X size={24} className="group-hover:rotate-90 transition-transform" />
                        </button>
                      </div>
                      
                      <div className="p-10 overflow-y-auto flex-1 space-y-12 custom-scrollbar bg-white/10">
                        {/* Basic Details */}
                        <div className="space-y-6">
                           <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-[0.3em] px-2 flex items-center gap-3">
                              <UserIcon size={14} className="text-slate-900" />
                              Operator Information
                           </h4>
                          
                          <div className="space-y-6">
                            <div className="space-y-3">
                              <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Full Name *</label>
                              <div className="relative group">
                                <input 
                                  type="text" 
                                  placeholder="Enter team member's full name"
                                  value={adminForm.name || ''}
                                  onChange={(e) => setAdminForm({ ...adminForm, name: e.target.value })}
                                  className="w-full bg-white/40 border border-white/60 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                              <div className="space-y-3">
                                <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Email Address *</label>
                                <div className="relative group">
                                  <input 
                                    type="email" 
                                    placeholder="operator@email.com"
                                    value={adminForm.email || ''}
                                    onChange={(e) => setAdminForm({ ...adminForm, email: e.target.value })}
                                    className="w-full bg-white/40 border border-white/60 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                                  />
                                </div>
                              </div>
                              <div className="space-y-3">
                                <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Access Password</label>
                                <div className="relative group">
                                  <input 
                                    type="password" 
                                    placeholder="••••••••••••"
                                    value={adminForm.password || ''}
                                    onChange={(e) => setAdminForm({ ...adminForm, password: e.target.value })}
                                    className="w-full bg-white/40 border border-white/60 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                                  />
                                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-2 px-2 italic">Leave blank to keep current password</p>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-8 pt-2 px-2">
                              {[
                                { status: 'Active', color: 'bg-emerald-500' },
                                { status: 'Inactive', color: 'bg-slate-300' }
                              ].map((opt) => (
                                <label key={opt.status} className="flex items-center gap-3 cursor-pointer group">
                                  <div 
                                    onClick={() => setAdminForm({ ...adminForm, status: opt.status as any })}
                                    className={`w-6 h-6 rounded-xl border-2 flex items-center justify-center transition-all ${
                                      adminForm.status === opt.status ? 'border-slate-900 bg-white shadow-lg' : 'border-white/60 hover:border-slate-200'
                                    }`}
                                  >
                                    {adminForm.status === opt.status && <div className={`w-3 h-3 ${opt.color} rounded-lg shadow-sm`} />}
                                  </div>
                                  <span className={`text-[10px] font-black uppercase tracking-widest ${adminForm.status === opt.status ? 'text-slate-900' : 'text-slate-400'}`}>{opt.status}</span>
                                </label>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Admin Staff Accesses */}
                        <div className="space-y-6">
                           <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-[0.3em] px-2 flex items-center gap-3">
                              <Shield size={14} className="text-slate-900" />
                              Assign Access Permissions
                           </h4>
                          
                          <div className="glass rounded-[2rem] border border-white/40 overflow-hidden shadow-xl">
                            <table className="w-full text-left">
                              <thead>
                                <tr className="bg-white/40 border-b border-white/20">
                                  <th className="py-5 px-8 text-[9px] font-black text-slate-400 uppercase tracking-widest w-24">ID</th>
                                  <th className="py-5 px-8 text-[9px] font-black text-slate-400 uppercase tracking-widest">Page & Module</th>
                                  <th className="py-5 px-8 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right">Access Level</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-white/20">
                                {ADMIN_MODULES.map((module, idx) => (
                                  <tr key={module} className="hover:bg-white/30 transition-all group">
                                    <td className="py-5 px-8 text-[10px] font-black text-slate-300">{(idx + 1).toString().padStart(2, '0')}</td>
                                    <td className="py-5 px-8 text-xs font-black text-slate-800 uppercase tracking-tight">{module}</td>
                                    <td className="py-5 px-8 text-right">
                                      <select 
                                        value={adminForm.accesses[module] ? 'Yes' : 'No'}
                                        onChange={(e) => setAdminForm({
                                          ...adminForm,
                                          accesses: {
                                            ...adminForm.accesses,
                                            [module]: e.target.value === 'Yes'
                                          }
                                        })}
                                        className="bg-white/40 border border-white/60 rounded-xl px-4 py-2 text-[10px] font-black uppercase tracking-widest focus:outline-none focus:ring-2 focus:ring-slate-900 shadow-sm transition-all hover:bg-white/60 cursor-pointer text-slate-800 font-bold"
                                      >
                                        <option value="Yes">Authorized</option>
                                        <option value="No">Restricted</option>
                                      </select>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>

                      <div className="p-10 bg-white/40 border-t border-white/20 flex justify-end gap-5 flex-shrink-0">
                        <button 
                          onClick={() => setIsEditAdminModalOpen(false)}
                          className="px-10 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-slate-900 transition-all"
                        >
                          Cancel
                        </button>
                        <button 
                          onClick={handleSaveAdmin}
                          className="px-12 py-5 text-[10px] font-black text-white bg-slate-900 hover:bg-black rounded-[2rem] shadow-2xl transition-all active:scale-[0.98]"
                        >
                          Save Operator
                        </button>
                      </div>
                    </motion.div>
                  </div>
                )}
              </AnimatePresence>

              {/* Update Config Modal */}
              <AnimatePresence>
                {isUpdateConfigModalOpen && (
                  <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9, y: 30 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.9, y: 30 }}
                      className="glass rounded-[3rem] shadow-2xl w-full max-w-6xl overflow-hidden border border-white/40 flex flex-col max-h-[90vh]"
                    >
                      <div className="flex items-center justify-between p-10 border-b border-white/20 bg-white/40 shadow-sm">
                        <div className="space-y-1">
                          <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Protocol Tuning</h3>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Adjusting core mission parameters | Matrix Version 4.1.2</p>
                        </div>
                        <button 
                          onClick={() => setIsUpdateConfigModalOpen(false)}
                          className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group border border-white/40"
                        >
                          <X size={24} className="group-hover:rotate-90 transition-transform" />
                        </button>
                      </div>

                      <div className="p-10 overflow-y-auto custom-scrollbar flex-1 bg-white/10">
                        <div className="flex gap-4 p-2 bg-white/40 rounded-[2rem] border border-white/60 w-fit mb-12 shadow-inner">
                          {(['General', 'Domestic', 'International', 'Button'] as const).map((tab) => (
                            <button
                              key={tab}
                              onClick={() => setConfigTab(tab)}
                              className={`px-10 py-4 text-[10px] font-black uppercase tracking-[0.2em] transition-all rounded-[1.5rem] ${
                                configTab === tab 
                                  ? 'bg-slate-900 text-white shadow-xl scale-[1.05]' 
                                  : 'text-slate-400 hover:text-slate-600 hover:bg-white/40'
                              }`}
                            >
                              {tab} Vector
                            </button>
                          ))}
                        </div>

                        {configTab === 'General' && (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10 px-2 animate-in fade-in duration-500">
                            {generalConfigs.map((config) => (
                              <div key={config.id} className={config.name === 'Running Message' ? 'md:col-span-2' : ''}>
                                <div className="space-y-3 group">
                                  <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 transition-colors group-focus-within:text-indigo-600">
                                    {config.name} Protocol
                                  </label>
                                  {config.name === 'Running Message' ? (
                                    <textarea 
                                      value={editConfig[config.name] || ''}
                                      onChange={(e) => setEditConfig({...editConfig, [config.name]: e.target.value})}
                                      className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 min-h-[160px] transition-all shadow-inner"
                                    />
                                  ) : (
                                    <input 
                                      type="text" 
                                      value={editConfig[config.name] || ''}
                                      onChange={(e) => setEditConfig({...editConfig, [config.name]: e.target.value})}
                                      className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                                    />
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}

                        {configTab === 'Domestic' && (
                          <div className="space-y-16 px-2 animate-in fade-in duration-500">
                            <div className="space-y-10">
                              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em] flex items-center gap-3">
                                <Activity size={16} className="text-emerald-500" />
                                Operational Constants
                              </h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
                                {[
                                  'DOM Demo Max Campaigns Allowed',
                                  'DOM Max Campaigns Allowed',
                                  'DOM Demo Default Filtering Server ID',
                                  'DOM Demo Default Running Server ID'
                                ].map((name) => (
                                  <div key={name} className="space-y-3">
                                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{name}</label>
                                    <input 
                                      type="text" 
                                      value={editConfig[name] || ''}
                                      onChange={(e) => setEditConfig({...editConfig, [name]: e.target.value})}
                                      className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                                    />
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-6">
                              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em]">Quota Exhaustion Response</h4>
                              <textarea 
                                value={editDomesticMessages.maxAllowed || ''}
                                onChange={(e) => setEditDomesticMessages({...editDomesticMessages, maxAllowed: e.target.value})}
                                className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 min-h-[120px] transition-all shadow-inner"
                              />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                              <div className="space-y-8">
                                <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em] flex items-center gap-3">
                                  <Clock size={16} className="text-indigo-500" />
                                  Operational Window (Fixed)
                                </h4>
                                <div className="space-y-8 bg-white/40 p-8 rounded-[2rem] border border-white/60 shadow-lg">
                                  {[
                                    'DOM Campaigns Allowed From Time',
                                    'DOM Campaigns Allowed To Time'
                                  ].map((name) => (
                                    <div key={name} className="space-y-3">
                                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{name}</p>
                                      <TimePicker 
                                        value={editConfig[name] || ''} 
                                        onChange={(val) => setEditConfig({...editConfig, [name]: val})} 
                                      />
                                    </div>
                                  ))}
                                </div>
                              </div>
                              <div className="space-y-8">
                                <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em] flex items-center gap-3">
                                  <Zap size={16} className="text-amber-500" />
                                  Demo Execution Window
                                </h4>
                                <div className="space-y-8 bg-white/40 p-8 rounded-[2rem] border border-white/60 shadow-lg">
                                  {[
                                    'DOM Demo Campaigns Allowed From Time',
                                    'DOM Demo Campaigns Allowed To Time'
                                  ].map((name) => (
                                    <div key={name} className="space-y-3">
                                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{name}</p>
                                      <TimePicker 
                                        value={editConfig[name] || ''} 
                                        onChange={(val) => setEditConfig({...editConfig, [name]: val})} 
                                      />
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>

                            <div className="space-y-6">
                              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em]">System Overload Alert</h4>
                              <textarea 
                                value={editDomesticMessages.limitExceeded || ''}
                                onChange={(e) => setEditDomesticMessages({...editDomesticMessages, limitExceeded: e.target.value})}
                                className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 min-h-[120px] transition-all shadow-inner"
                              />
                            </div>
                          </div>
                        )}

                        {configTab === 'International' && (
                          <div className="space-y-16 px-2 animate-in fade-in duration-500">
                             <div className="space-y-10">
                              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em] flex items-center gap-3">
                                <Globe size={16} className="text-emerald-500" />
                                Global Parameters
                              </h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
                                {[
                                  'INT Demo Max Campaigns Allowed',
                                  'INT Max Campaigns Allowed',
                                  'INT Demo Default Filtering Server ID',
                                  'INT Demo Default Running Server ID'
                                ].map((name) => (
                                  <div key={name} className="space-y-3">
                                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{name}</label>
                                    <input 
                                      type="text" 
                                      value={editConfig[name] || ''}
                                      onChange={(e) => setEditConfig({...editConfig, [name]: e.target.value})}
                                      className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                                    />
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-6">
                              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em]">International Quota Warning</h4>
                              <textarea 
                                value={editInternationalMessages.maxAllowed || ''}
                                onChange={(e) => setEditInternationalMessages({...editInternationalMessages, maxAllowed: e.target.value})}
                                className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 min-h-[120px] transition-all shadow-inner"
                              />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                              <div className="space-y-8">
                                <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em] flex items-center gap-3">
                                  <Clock size={16} className="text-indigo-500" />
                                  Global Window (Fixed)
                                </h4>
                                <div className="space-y-8 bg-white/40 p-8 rounded-[2rem] border border-white/60 shadow-lg">
                                  {[
                                    'INT Campaigns Allowed From Time',
                                    'INT Campaigns Allowed To Time'
                                  ].map((name) => (
                                    <div key={name} className="space-y-3">
                                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{name}</p>
                                      <TimePicker 
                                        value={editConfig[name] || ''} 
                                        onChange={(val) => setEditConfig({...editConfig, [name]: val})} 
                                      />
                                    </div>
                                  ))}
                                </div>
                              </div>
                              <div className="space-y-8">
                                <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em] flex items-center gap-3">
                                  <Zap size={16} className="text-amber-500" />
                                  Demo Global
                                </h4>
                                <div className="space-y-8 bg-white/40 p-8 rounded-[2rem] border border-white/60 shadow-lg">
                                  {[
                                    'INT Demo Campaigns Allowed From Time',
                                    'INT Demo Campaigns Allowed To Time'
                                  ].map((name) => (
                                    <div key={name} className="space-y-3">
                                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{name}</p>
                                      <TimePicker 
                                        value={editConfig[name] || ''} 
                                        onChange={(val) => setEditConfig({...editConfig, [name]: val})} 
                                      />
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>

                            <div className="space-y-6">
                              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em]">Network Congestion Alert (INT)</h4>
                              <textarea 
                                value={editInternationalMessages.limitExceeded || ''}
                                onChange={(e) => setEditInternationalMessages({...editInternationalMessages, limitExceeded: e.target.value})}
                                className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 min-h-[120px] transition-all shadow-inner"
                              />
                            </div>
                          </div>
                        )}

                        {configTab === 'Button' && (
                          <div className="space-y-16 px-2 animate-in fade-in duration-500">
                            <div className="space-y-10">
                              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em] flex items-center gap-3">
                                <MousePointer2 size={16} className="text-indigo-500" />
                                Interactive Protocol Parameters
                              </h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
                                {[
                                  'BTN Demo Max Campaigns Allowed',
                                  'BTN Max Campaigns Allowed',
                                  'BTN Demo Default Filtering Server ID',
                                  'BTN Demo Default Running Server ID'
                                ].map((name) => (
                                  <div key={name} className="space-y-3">
                                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{name}</label>
                                    <input 
                                      type="text" 
                                      value={editConfig[name] || ''}
                                      onChange={(e) => setEditConfig({...editConfig, [name]: e.target.value})}
                                      className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                                    />
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-6">
                              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em]">Button Quota Warning</h4>
                              <textarea 
                                value={editButtonMessages.maxAllowed || ''}
                                onChange={(e) => setEditButtonMessages({...editButtonMessages, maxAllowed: e.target.value})}
                                className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 min-h-[120px] transition-all shadow-inner"
                              />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                              <div className="space-y-8">
                                <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em] flex items-center gap-3">
                                  <Clock size={16} className="text-zinc-500" />
                                  Button Active Window (Fixed)
                                </h4>
                                <div className="space-y-8 bg-white/40 p-8 rounded-[2rem] border border-white/60 shadow-lg">
                                  {[
                                    'BTN Campaigns Allowed From Time',
                                    'BTN Campaigns Allowed To Time'
                                  ].map((name) => (
                                    <div key={name} className="space-y-3">
                                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{name}</p>
                                      <TimePicker 
                                        value={editConfig[name] || ''} 
                                        onChange={(val) => setEditConfig({...editConfig, [name]: val})} 
                                      />
                                    </div>
                                  ))}
                                </div>
                              </div>
                              <div className="space-y-8">
                                <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em] flex items-center gap-3">
                                  <Zap size={16} className="text-amber-500" />
                                  Demo Active Windows (BTN)
                                </h4>
                                <div className="space-y-8 bg-white/40 p-8 rounded-[2rem] border border-white/60 shadow-lg">
                                  {[
                                    'BTN Demo Campaigns Allowed From Time',
                                    'BTN Demo Campaigns Allowed To Time'
                                  ].map((name) => (
                                    <div key={name} className="space-y-3">
                                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{name}</p>
                                      <TimePicker 
                                        value={editConfig[name] || ''} 
                                        onChange={(val) => setEditConfig({...editConfig, [name]: val})} 
                                      />
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>

                            <div className="space-y-6">
                              <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-[0.3em]">Network Congestion Alert (BTN)</h4>
                              <textarea 
                                value={editButtonMessages.limitExceeded || ''}
                                onChange={(e) => setEditButtonMessages({...editButtonMessages, limitExceeded: e.target.value})}
                                className="w-full bg-white/40 border border-white/60 rounded-[2rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 min-h-[120px] transition-all shadow-inner"
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-end gap-6 p-10 bg-white/40 border-t border-white/20">
                        <button 
                          onClick={() => setIsUpdateConfigModalOpen(false)}
                          className="px-10 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-slate-900 transition-all"
                        >
                          Abort Override
                        </button>
                        <button 
                          onClick={handleUpdateConfig}
                          className="px-12 py-5 bg-slate-900 hover:bg-black text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98]"
                        >
                          Commit Vector Configuration
                        </button>
                      </div>
                                {/* Modals sections moved to end of Dashboard */}
                    </motion.div>
                  </div>
                )}
              </AnimatePresence>

              {/* Add Channel Modal Placeholder */}

              {/* Edit Campaign Modal Placeholder */}

              {/* Send Message Modal Placeholder */}
              {/* Run Campaign Selection Modal Placeholder */}
              {![
                'Dashboard',
                'Demo Server',
                'My Campaigns',
                'Pending Campaign',
                'Finished Campaign',
                'Create Campaign',
                'Create Button Campaign',
                'User Management',
                'Non Whatsapp Number',
                'White Listing Number',
                'White Listing DB',
                'Campaign Config',
                'Cities',
                'Admin Staff',
                'Manage Transactions',
                'Private Sender',
                'Private Subscriptions',
                'Terms & Conditions'
              ].includes(currentPage) && (
                <div className="flex flex-col items-center justify-center py-20 text-slate-400">
                  <Settings size={64} className="mb-4 opacity-20 animate-spin-slow" />
                  <h3 className="text-xl font-bold text-slate-600 mb-2">{currentPage}</h3>
                  <p>This module is currently under development.</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* User Edit / Profile Modal */}
        {userBeingEdited && (
          <ProfileSettingsModal 
            user={userBeingEdited} 
            onClose={() => setUserBeingEdited(null)}
            currentUserRole={currentUser.role}
            onSave={(updatedUser) => {
              if (updatedUser.id === currentUser.id) {
                setCurrentUser(updatedUser);
              }
              setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
              setUserBeingEdited(null);
            }}
          />
        )}
      </main>

      <AnimatePresence>
        {reportingCampaign && (
          <ReportModal 
            campaign={campaigns.find(c => c.id === reportingCampaign.id) || reportingCampaign}
            onClose={() => setReportingCampaign(null)}
            isAdmin={currentUser.role === 'Admin' || currentUser.role === 'Reseller'}
            onUpdateCampaign={(updatedCamp) => {
              setCampaigns(prev => prev.map(c => c.id === updatedCamp.id ? updatedCamp : c));
              setReportingCampaign(updatedCamp);
            }}
            whitelistNumbers={mockDb}
            showToast={showToast}
            channels={channels}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isAddChannelModalOpen && (
          <AddChannelModal 
            onClose={() => setIsAddChannelModalOpen(false)}
            onAdd={handleAddChannel}
            step={qrStep}
            qrCode={generatedQr}
            channelName={newChannelName}
            setChannelName={setNewChannelName}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {editingCampaign && (
          <EditMessageModal 
            campaign={editingCampaign}
            onClose={() => setEditingCampaign(null)}
            onSave={handleUpdateCampaignMessage}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isSendMessageModalOpen && (
          <SendMessageModal 
            onClose={() => setIsSendMessageModalOpen(false)}
            onSend={handleSendMessage}
            channel={selectedChannelForMessage}
            messageData={testMessage}
            setMessageData={setTestMessage}
            isSending={isSending}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {runningCampaignId && campaigns && Array.isArray(campaigns) && (
          <RunCampaignModal 
            campaign={campaigns.find(c => c.id === runningCampaignId)}
            allCampaigns={campaigns}
            channels={demoChannels.filter(ch => ch.status === 'Connected')}
            mockDb={mockDb}
            nonWaDb={nonWaDb}
            onClose={() => setRunningCampaignId(null)}
            onRun={(serverId, filterMode) => handleFinishCampaign(runningCampaignId, serverId, filterMode)}
            onScanned={handleCampaignScanned}
            onDirectFinish={handleDirectFinish}
            isAdmin={currentUser.role === 'Admin' || currentUser.role === 'Reseller'}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isAddUserModalOpen && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              className="glass rounded-[3rem] shadow-2xl w-full max-w-3xl overflow-hidden border border-white/40 flex flex-col max-h-[90vh]"
            >
              <div className="p-10 border-b border-white/20 flex justify-between items-center bg-white/40">
                <div className="space-y-1">
                  <h4 className="text-2xl font-black text-slate-900 tracking-tight uppercase">Create New Account</h4>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Add a new user or reseller account to the system</p>
                </div>
                <button onClick={() => setIsAddUserModalOpen(false)} className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm border border-white/60 group">
                  <X size={24} className="group-hover:rotate-90 transition-transform" />
                </button>
              </div>
              
              <div className="p-10 space-y-10 overflow-y-auto custom-scrollbar bg-white/10">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {[
                    { label: 'Full Name', icon: UserIcon, field: 'name', type: 'text', placeholder: 'Enter full name' },
                    { label: 'Login Username', icon: Fingerprint, field: 'username', type: 'text', placeholder: 'username' },
                    { label: 'Phone Number', icon: Phone, field: 'mobile', type: 'text', placeholder: '+91 00000 00000' },
                    { label: 'Commission (%)', icon: Percent, field: 'cuttingPercentage', type: 'text', placeholder: '0-100' },
                    { label: 'Email Address', icon: Mail, field: 'email', type: 'email', placeholder: 'user@email.com' },
                    { label: 'Login Password', icon: Lock, field: 'password', type: 'password', placeholder: '••••••••••••' },
                  ].map((input) => (
                    <div key={input.field} className="space-y-3">
                      <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">{input.label} *</label>
                      <div className="relative group">
                        <input 
                          type={input.type} 
                          placeholder={input.placeholder}
                          value={(newUser as any)[input.field] || ''}
                          onChange={(e) => setNewUser({...newUser, [input.field]: e.target.value})}
                          className="w-full bg-white/40 border border-white/60 rounded-2xl pl-12 pr-6 py-5 text-sm font-bold text-slate-700 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                        />
                        <input.icon className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-slate-900 transition-colors" size={18} />
                      </div>
                    </div>
                  ))}
                </div>

                {currentUser.role === 'Admin' && (
                  <div className="space-y-4 px-2">
                    <label className="text-[10px] font-bold text-slate-900 uppercase tracking-widest">Account Type</label>
                    <div className="flex items-center gap-10">
                      {['Reseller', 'User'].map((role) => (
                        <label key={role} className="flex items-center gap-4 cursor-pointer group">
                          <div 
                            onClick={() => setNewUser({...newUser, role: role as any})}
                            className={`w-6 h-6 rounded-xl border-2 flex items-center justify-center transition-all ${
                              newUser.role === role ? 'border-slate-900 bg-white shadow-lg' : 'border-white/60 hover:border-slate-200'
                            }`}
                          >
                            {newUser.role === role && <div className="w-3 h-3 bg-slate-900 rounded-lg shadow-sm" />}
                          </div>
                          <span className={`text-xs font-black uppercase tracking-widest ${newUser.role === role ? 'text-slate-900' : 'text-slate-400'}`}>{role}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">State / Location</label>
                    <select 
                      className="w-full bg-white/40 border border-white/60 rounded-2xl px-6 py-5 text-[10px] font-black uppercase tracking-wider text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner cursor-pointer appearance-none"
                      value={newUser.location || ''}
                      onChange={(e) => setNewUser({...newUser, location: e.target.value})}
                    >
                      <option value="">Select State / Location</option>
                      {cities.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">City Segment</label>
                    <select 
                      className="w-full bg-white/40 border border-white/60 rounded-2xl px-6 py-5 text-[10px] font-black uppercase tracking-wider text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner cursor-pointer appearance-none"
                    >
                      <option>General / Default</option>
                    </select>
                  </div>
                </div>

                 <div className="grid grid-cols-1 md:grid-cols-3 gap-8 border-t border-white/20 pt-10">
                   <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Domestic Credits</label>
                      <input 
                        type="number"
                        placeholder="0"
                        value={newUser.domCredits || ''}
                        onChange={(e) => setNewUser({...newUser, domCredits: parseInt(e.target.value) || 0})}
                        className="w-full bg-white/40 border border-white/60 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                      />
                   </div>
                   <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Button Credits</label>
                      <input 
                        type="number"
                        placeholder="0"
                        value={newUser.btnCredits || ''}
                        onChange={(e) => setNewUser({...newUser, btnCredits: parseInt(e.target.value) || 0})}
                        className="w-full bg-white/40 border border-white/60 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                      />
                   </div>
                   <div className="space-y-3">
                      <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">International Credits</label>
                      <input 
                        type="number"
                        placeholder="0"
                        value={newUser.intCredits || ''}
                        onChange={(e) => setNewUser({...newUser, intCredits: parseInt(e.target.value) || 0})}
                        className="w-full bg-white/40 border border-white/60 rounded-2xl px-6 py-5 text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                      />
                   </div>
                </div>
              </div>

              <div className="p-10 bg-white/40 border-t border-white/20 flex items-center justify-end gap-6">
                <button 
                  onClick={() => setIsAddUserModalOpen(false)}
                  className="px-10 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-slate-900 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleAddUser}
                  className="px-12 py-5 bg-slate-900 hover:bg-black text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98]"
                >
                  Create Account
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const TimePicker = ({ value, onChange }: { value: string, onChange: (val: string) => void }) => {
  const [hours, minutes, period] = useMemo(() => {
    const match = value.match(/(\d+):(\d+)\s(AM|PM)/);
    return match ? [match[1], match[2], match[3]] : ['08', '00', 'AM'];
  }, [value]);

  const updateTime = (newH: string, newM: string, newP: string) => {
    onChange(`${newH}:${newM} ${newP}`);
  };

  return (
    <div className="flex items-center gap-4">
      <div className="flex items-center gap-2">
        <div className="flex flex-col items-center">
          <button onClick={() => updateTime(String(Number(hours) % 12 + 1).padStart(2, '0'), minutes, period)} className="text-slate-400 hover:text-slate-600"><ChevronUp size={14} /></button>
          <div className="w-12 h-10 border border-slate-200 rounded-lg flex items-center justify-center text-sm font-bold text-slate-700 bg-white">{hours}</div>
          <button onClick={() => updateTime(String((Number(hours) - 2 + 12) % 12 + 1).padStart(2, '0'), minutes, period)} className="text-slate-400 hover:text-slate-600"><ChevronDown size={14} /></button>
        </div>
        <span className="font-bold text-slate-400">:</span>
        <div className="flex flex-col items-center">
          <button onClick={() => updateTime(hours, String((Number(minutes) + 1) % 60).padStart(2, '0'), period)} className="text-slate-400 hover:text-slate-600"><ChevronUp size={14} /></button>
          <div className="w-12 h-10 border border-slate-200 rounded-lg flex items-center justify-center text-sm font-bold text-slate-700 bg-white">{minutes}</div>
          <button onClick={() => updateTime(hours, String((Number(minutes) - 1 + 60) % 60).padStart(2, '0'), period)} className="text-slate-400 hover:text-slate-600"><ChevronDown size={14} /></button>
        </div>
      </div>
      <div className="flex flex-col gap-1">
        <button 
          onClick={() => updateTime(hours, minutes, 'AM')}
          className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all ${period === 'AM' ? 'bg-[#00796B] text-white' : 'border border-slate-200 text-slate-400'}`}
        >
          AM
        </button>
        <button 
          onClick={() => updateTime(hours, minutes, 'PM')}
          className={`px-3 py-1 rounded-lg text-[10px] font-bold transition-all ${period === 'PM' ? 'bg-[#00796B] text-white' : 'border border-slate-200 text-slate-400'}`}
        >
          PM
        </button>
      </div>
    </div>
  );
};

const NumberSearchPage = ({ 
  title, 
  records, 
  onSearch,
  onAdd, 
  onDelete,
  onBulkUpload,
  onClearAll, 
  onRemoveRecord,
  searchNumber,
  setSearchNumber,
  searchOption,
  setSearchOption,
  searchCountry,
  setSearchCountry
}: { 
  title: string, 
  records: NumberSearchRecord[], 
  onSearch: () => void,
  onAdd: () => void,
  onDelete: () => void,
  onBulkUpload?: (file: File) => void,
  onClearAll: () => void,
  onRemoveRecord: (id: string) => void,
  searchNumber: string,
  setSearchNumber: (v: string) => void,
  searchOption: 'Domestic' | 'International',
  setSearchOption: (v: 'Domestic' | 'International') => void,
  searchCountry: string,
  setSearchCountry: (v: string) => void
}) => (
  <div className="max-w-7xl mx-auto space-y-12 pb-20 w-full animate-in fade-in duration-500">
    <div className="px-4">
       <h3 className="text-4xl font-black text-slate-900 tracking-tight uppercase">{title}</h3>
       <p className="text-slate-500 font-medium mt-1">Execute targeted search protocols across global number matrices.</p>
    </div>

    <div className="glass rounded-[3rem] border border-white/40 shadow-2xl p-10 lg:p-12 mx-4 overflow-hidden relative">

      
      <div className="flex flex-col md:flex-row gap-10 relative z-10">
        <div className="space-y-6 flex-1">
          <div className="space-y-3">
             <label className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em] ml-1">Inquiry Protocol</label>
             <div className="flex p-2 bg-slate-900/5 rounded-2xl border border-slate-900/5">
                {(['Domestic', 'International'] as const).map((opt) => (
                  <button
                    key={opt}
                    onClick={() => setSearchOption(opt)}
                    className={`flex-1 py-3 px-6 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                      searchOption === opt ? 'bg-slate-900 text-white shadow-xl translate-y-[-2px]' : 'text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
             </div>
          </div>

          <div className="space-y-3">
             <label className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em] ml-1">Target Geolocation</label>
             <div className="relative group">
                <div className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-hover:text-emerald-500 transition-colors pointer-events-none">
                   <Globe size={20} />
                </div>
                <select 
                  value={searchCountry || ''}
                  onChange={(e) => setSearchCountry(e.target.value)}
                  disabled={searchOption === 'Domestic'}
                  className={`w-full bg-white/60 border-2 border-white/80 rounded-2xl pl-16 pr-6 py-4 text-xs font-black uppercase tracking-widest focus:outline-none focus:bg-white focus:border-emerald-500/20 transition-all shadow-inner appearance-none ${searchOption === 'Domestic' ? 'opacity-50' : 'cursor-pointer'}`}
                >
                  {searchOption === 'Domestic' ? (
                    <option value="+91 India">🇮🇳 +91 India</option>
                  ) : (
                    countries.filter(c => c.name !== 'India').map(c => (
                      <option key={c.name} value={`${c.prefix} ${c.name}`}>{c.flag} {c.prefix} {c.name}</option>
                    ))
                  )}
                </select>
             </div>
          </div>
        </div>

        <div className="space-y-6 flex-1 lg:flex-[1.5]">
          <div className="space-y-3">
             <label className="text-[10px] font-black text-slate-900 uppercase tracking-[0.2em] ml-1">Vector Input</label>
             <div className="relative">
                <div className="absolute left-8 top-1/2 -translate-y-1/2 flex items-center gap-2">
                   <span className="text-emerald-600 font-mono text-sm font-black bg-emerald-500/10 px-3 py-1 rounded-lg border border-emerald-500/20">
                     {searchCountry.split(' ')[0]}
                   </span>
                </div>
                <input 
                  type="text" 
                  placeholder="SCAN NUMBER SEQUENCE..."
                  value={searchNumber || ''}
                  onChange={(e) => setSearchNumber(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && onSearch()}
                  className="w-full bg-slate-900/5 hover:bg-slate-900/10 border-2 border-transparent rounded-[2.5rem] pl-32 pr-10 py-8 text-lg font-mono focus:outline-none focus:bg-white focus:border-slate-900 transition-all shadow-inner"
                />
             </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
             <button onClick={onSearch} className="bg-slate-900 hover:bg-black text-white px-6 py-5 rounded-2xl transition-all shadow-2xl active:scale-95 flex items-center justify-center gap-2 group">
                <Search size={18} className="group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-black tracking-widest uppercase">SCAN</span>
             </button>
             <button onClick={onAdd} className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-5 rounded-2xl transition-all shadow-2xl active:scale-95 flex items-center justify-center gap-2 group">
                <PlusCircle size={18} className="group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-black tracking-widest uppercase">MARK</span>
             </button>
             <button onClick={onDelete} className="bg-rose-600 hover:bg-rose-700 text-white px-6 py-5 rounded-2xl transition-all shadow-2xl active:scale-95 flex items-center justify-center gap-2 group">
                <Trash2 size={18} className="group-hover:scale-110 transition-transform" />
                <span className="text-[10px] font-black tracking-widest uppercase">PURGE</span>
             </button>
             <label className="bg-white border-2 border-slate-900 px-6 py-5 rounded-2xl hover:bg-slate-900 hover:text-white cursor-pointer transition-all shadow-xl active:scale-95 flex items-center justify-center gap-2 group">
                <Upload size={18} className="group-hover:-translate-y-1 transition-transform" />
                <span className="text-[10px] font-black tracking-widest uppercase">INGEST</span>
                <input type="file" accept=".csv,.txt" className="hidden" onChange={(e) => { const file = e.target.files?.[0]; if (file && onBulkUpload) onBulkUpload(file); }} />
             </label>
          </div>
        </div>
      </div>
    </div>

    <div className="glass rounded-[3rem] border border-white/40 shadow-2xl p-10 lg:p-12 mx-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
           <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-white"><History size={24} /></div>
           <div>
              <h4 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Intercept Log</h4>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Historical Telemetry</span>
           </div>
        </div>
        <div className="flex gap-4">
          <button className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95">
            <RefreshCw size={14} />
            SYNC
          </button>
          <button onClick={onClearAll} className="flex items-center gap-2 bg-rose-50 hover:bg-rose-500 hover:text-white text-rose-500 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95">
            <Trash2 size={14} />
            WIPE ALL
          </button>
        </div>
      </div>

      <div className="overflow-x-auto custom-scrollbar">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b-2 border-slate-900/5">
              <th className="py-6 px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest w-24">Number #</th>
              <th className="py-6 px-4 text-[10px] font-black text-slate-900 uppercase tracking-widest">Target Vector</th>
              <th className="py-6 px-4 text-[10px] font-black text-slate-900 uppercase tracking-widest">Status Code</th>
              <th className="py-6 px-4 text-[10px] font-black text-slate-900 uppercase tracking-widest">Analysis Result</th>
              <th className="py-6 px-4 text-[10px] font-black text-slate-900 uppercase tracking-widest text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {records.map((r, idx) => (
              <tr key={r.id} className="border-b border-slate-50 hover:bg-slate-900/5 transition-all group">
                <td className="py-6 px-4 font-mono text-[10px] text-slate-400">#{String(idx + 1).padStart(3, '0')}</td>
                <td className="py-6 px-4 font-black text-slate-800 text-xs tracking-widest">{r.number}</td>
                <td className="py-6 px-4">
                  <span className={`text-[10px] font-black px-3 py-1 rounded-lg border uppercase tracking-widest shadow-sm ${
                    r.status === 'Found' || r.status === 'Success' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                    r.status === 'Not Found' ? 'bg-rose-50 text-rose-600 border-rose-100' : 
                    'bg-slate-50 text-slate-600 border-slate-100'
                  }`}>
                    {r.status}
                  </span>
                </td>
                <td className="py-6 px-4">
                  <div className="flex items-center gap-2">
                     <div className={`w-1.5 h-1.5 rounded-full ${r.result.includes('Found') || r.result.includes('successfully') ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.5)]'}`} />
                     <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tight line-clamp-1">{r.result}</span>
                  </div>
                </td>
                <td className="py-6 px-4 text-right">
                  <button 
                    onClick={() => onRemoveRecord(r.id)}
                    className="ml-auto p-2 text-slate-300 hover:text-rose-500 transition-all opacity-0 group-hover:opacity-100 translate-x-2 group-hover:translate-x-0"
                  >
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))}
            {records.length === 0 && (
              <tr>
                <td colSpan={5} className="py-32 text-center">
                  <div className="flex flex-col items-center gap-6 opacity-20">
                     <Search size={64} className="text-slate-900" />
                     <p className="text-[10px] font-black text-slate-900 uppercase tracking-[0.5em]">System Idle: Waiting for scan vector</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

const RejectModal = ({ onReject, onClose }: { onReject: (reason: string) => void, onClose: () => void }) => {
  const [reason, setReason] = useState('');

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 30 }}
        className="glass rounded-[3rem] shadow-2xl w-full max-w-md overflow-hidden border border-white/40 flex flex-col"
      >
        <div className="p-10 border-b border-white/20 bg-white/40 shadow-sm flex justify-between items-center">
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-4">
              <AlertTriangle size={24} className="text-rose-500" />
              Reject Campaign
            </h3>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Campaign Rejection Reason</p>
          </div>
          <button onClick={onClose} className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group border border-white/40">
            <X size={24} className="group-hover:rotate-90 transition-transform" />
          </button>
        </div>
        
        <div className="p-10 space-y-8 bg-white/10">
          <div className="space-y-3 group">
            <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 group-focus-within:text-rose-500 transition-colors">Reason for Rejection</label>
            <textarea 
              value={reason || ''}
              onChange={(e) => setReason(e.target.value)}
              placeholder="State the reason for rejecting campaign..."
              className="w-full bg-white/40 border border-white/60 rounded-[1.5rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all min-h-[160px] resize-none shadow-inner"
            />
          </div>
          <div className="bg-rose-50/50 p-4 rounded-2xl border border-rose-100/50 flex items-center gap-3">
             <ShieldAlert size={16} className="text-rose-400" />
             <p className="text-[9px] font-black text-rose-400 uppercase tracking-[0.15em]">This message will be logged in the campaign audit logs</p>
          </div>
        </div>

        <div className="p-10 bg-white/40 border-t border-white/20 flex flex-col gap-6">
          <button 
            onClick={() => onReject(reason)}
            disabled={!reason.trim()}
            className="w-full py-6 bg-rose-500 hover:bg-rose-600 disabled:bg-slate-200 text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98] flex items-center justify-center gap-4"
          >
            Reject Campaign
          </button>
          <button 
            onClick={onClose}
            className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] hover:text-slate-900 transition-colors text-center"
          >
            Cancel / Close
          </button>
        </div>
      </motion.div>
    </div>
  );
};

const AddChannelModal = ({ 
  onClose, 
  onAdd, 
  step, 
  qrCode, 
  channelName, 
  setChannelName 
}: { 
  onClose: () => void, 
  onAdd: () => void, 
  step: 'name' | 'qr' | 'success', 
  qrCode: string | null,
  channelName: string,
  setChannelName: (name: string) => void
}) => {
  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 30 }}
        className="glass rounded-[3rem] shadow-2xl w-full max-w-md overflow-hidden border border-white/40 flex flex-col"
      >
        <div className="p-10 border-b border-white/20 bg-white/40 shadow-sm flex justify-between items-center">
          <div className="space-y-1">
             <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-4">
               <LinkIcon size={24} className="text-emerald-500" />
               Matrix Link
             </h3>
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">External Device Injection</p>
          </div>
          <button onClick={onClose} className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group border border-white/40">
            <X size={24} className="group-hover:rotate-90 transition-transform" />
          </button>
        </div>
        
        <div className="p-10 bg-white/10">
          <AnimatePresence mode="wait">
            {step === 'name' && (
              <motion.div 
                key="name"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div className="text-center space-y-3">
                  <div className="w-20 h-20 bg-emerald-500/10 text-emerald-600 rounded-[2rem] flex items-center justify-center mx-auto shadow-inner border border-emerald-500/20">
                    <Fingerprint size={40} />
                  </div>
                  <h4 className="text-xl font-black text-slate-900 uppercase tracking-tight">Identify Channel</h4>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Assign a unique transmission alias</p>
                </div>
                
                <div className="space-y-3 group">
                  <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 group-focus-within:text-emerald-500 transition-colors">Alias</label>
                  <input 
                    type="text" 
                    placeholder="e.g. PRIMARY_COMMAND_WA"
                    value={channelName || ''}
                    onChange={(e) => setChannelName(e.target.value)}
                    className="w-full bg-white/40 border border-white/60 rounded-[1.5rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all shadow-inner"
                  />
                </div>

                <button 
                  onClick={onAdd}
                  disabled={!channelName.trim()}
                  className="w-full py-6 bg-slate-900 hover:bg-black disabled:bg-slate-200 text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98] flex items-center justify-center gap-4 group"
                >
                  <RefreshCw size={16} className="group-hover:rotate-180 transition-transform duration-500" />
                  Generate Matrix Token
                </button>
              </motion.div>
            )}

            {step === 'qr' && (
              <motion.div 
                key="qr"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8 text-center"
              >
                <div className="space-y-3">
                  <h4 className="text-xl font-black text-slate-900 uppercase tracking-tight">Scan QR Code to Link</h4>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-relaxed px-4">Open WhatsApp on your phone, go to Linked Devices, and scan this QR code to connect.</p>
                </div>

                <div className="relative w-72 h-72 mx-auto bg-white rounded-[3rem] p-6 flex items-center justify-center shadow-2xl border-4 border-white overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/5 to-transparent pointer-events-none" />
                  {qrCode ? (
                    <motion.img 
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      src={qrCode} 
                      alt="WhatsApp QR" 
                      className="w-full h-full relative z-10" 
                      referrerPolicy="no-referrer" 
                    />
                  ) : (
                    <div className="flex flex-col items-center gap-4 relative z-10">
                      <RefreshCw className="text-indigo-600 animate-spin" size={48} />
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Compiling Token...</span>
                    </div>
                  )}
                  
                  {/* Decorative corners */}
                  <div className="absolute top-8 left-8 w-8 h-8 border-t-2 border-l-2 border-slate-100 rounded-tl-xl" />
                  <div className="absolute top-8 right-8 w-8 h-8 border-t-2 border-r-2 border-slate-100 rounded-tr-xl" />
                  <div className="absolute bottom-8 left-8 w-8 h-8 border-b-2 border-l-2 border-slate-100 rounded-bl-xl" />
                  <div className="absolute bottom-8 right-8 w-8 h-8 border-b-2 border-r-2 border-slate-100 rounded-br-xl" />
                </div>

                <div className="flex items-center justify-center gap-3 text-amber-500 bg-amber-50/50 py-3 px-6 rounded-2xl border border-amber-100/50">
                  <Activity size={16} className="animate-pulse" />
                  <span className="text-[10px] font-black uppercase tracking-[0.2em]">Awaiting Uplink Connection...</span>
                </div>

                <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.15em]">
                  Token entropy expires in <span className="text-amber-500">60 seconds</span>
                </p>
              </motion.div>
            )}

            {step === 'success' && (
              <motion.div 
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-10 text-center py-6"
              >
                <div className="w-24 h-24 bg-emerald-500 text-white rounded-[2.5rem] flex items-center justify-center mx-auto shadow-2xl shadow-emerald-500/40 relative">
                   <div className="absolute inset-0 bg-emerald-500 rounded-[2.5rem] animate-ping opacity-20" />
                   <div className="absolute inset-[-8px] border-2 border-emerald-500/20 rounded-[3rem]" />
                   <Check size={56} strokeWidth={3} />
                </div>
                <div className="space-y-3">
                  <h4 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Authorization Verified</h4>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">"{channelName}" is now part of the swarm</p>
                </div>
                <button 
                  onClick={onClose}
                  className="w-full py-6 bg-slate-900 hover:bg-black text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98]"
                >
                  Return to Command Center
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};

const SendMessageModal = ({ 
  onClose, 
  onSend, 
  channel, 
  messageData, 
  setMessageData,
  isSending
}: { 
  onClose: () => void, 
  onSend: () => void, 
  channel: Channel | null,
  messageData: { number: string, text: string, files: UploadedFile[] },
  setMessageData: (data: { number: string, text: string, files: UploadedFile[] }) => void,
  isSending: boolean
}) => {
  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 30 }}
        className="glass rounded-[3rem] shadow-2xl w-full max-w-md overflow-hidden border border-white/40 flex flex-col"
      >
        <div className="p-10 border-b border-white/20 bg-white/40 shadow-sm flex justify-between items-center">
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-4">
              <Zap size={24} className="text-amber-500" />
              Override Payload
            </h3>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Manual Transmission Protocol</p>
          </div>
          <button onClick={onClose} className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group border border-white/40">
            <X size={24} className="group-hover:rotate-90 transition-transform" />
          </button>
        </div>
        
        <div className="p-10 space-y-8 bg-white/10">
          <div className="bg-white/40 p-6 rounded-3xl border border-white/60 shadow-inner flex flex-col gap-2">
            <div className="flex items-center gap-3">
               <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-white">
                  <UserIcon size={14} />
               </div>
               <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">Origin</p>
                  <p className="text-sm font-black text-slate-800 tracking-tight">{channel?.name}</p>
               </div>
            </div>
            <div className="mt-2 pt-2 border-t border-white/20">
               <code className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">{channel?.number}</code>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-2 group">
              <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 group-focus-within:text-indigo-600 transition-colors">Target Vector (10 Digits)</label>
              <div className="relative">
                <Target className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="text" 
                  placeholder="9876543210"
                  value={messageData.number || ''}
                  onChange={(e) => setMessageData({ ...messageData, number: e.target.value })}
                  className="w-full bg-white/40 border border-white/60 rounded-[1.5rem] pl-14 pr-6 py-5 text-sm font-bold text-slate-800 placeholder:text-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all shadow-inner"
                />
              </div>
            </div>

            <div className="space-y-2 group">
              <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1 group-focus-within:text-indigo-600 transition-colors">Encrypted Flux Stream</label>
              <textarea 
                placeholder="Initialize message sequence..."
                value={messageData.text || ''}
                onChange={(e) => setMessageData({ ...messageData, text: e.target.value, files: messageData.files })}
                className="w-full bg-white/40 border border-white/60 rounded-[1.5rem] px-8 py-6 text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all min-h-[120px] resize-none shadow-inner"
              />
            </div>

            <div className="space-y-4">
              <label className="text-[10px] font-black text-slate-900 uppercase tracking-widest ml-1">Attachments</label>
              <div className="flex flex-wrap gap-4">
                {messageData.files.map(file => (
                  <div key={file.id} className="relative group w-14 h-14 rounded-2xl bg-white/40 border border-white/60 flex items-center justify-center overflow-hidden shadow-lg hover:scale-105 transition-all">
                    {file.type === 'image' ? (
                      <img src={file.url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <Package size={20} className="text-slate-900" />
                    )}
                    <button 
                      onClick={() => setMessageData({ ...messageData, files: messageData.files.filter(f => f.id !== file.id) })}
                      className="absolute top-1 right-1 bg-rose-500 text-white rounded-lg p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X size={10} />
                    </button>
                  </div>
                ))}
                {messageData.files.length < 4 && (
                  <label className="w-14 h-14 rounded-2xl border-2 border-dashed border-white/60 flex items-center justify-center text-slate-400 hover:border-slate-900 hover:text-slate-900 cursor-pointer transition-all bg-white/20 hover:bg-white/40 shadow-inner group">
                    <Plus size={24} className="group-hover:scale-125 transition-transform" />
                    <input 
                      type="file" 
                      className="hidden" 
                      accept="image/*,video/*,application/pdf"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const type = file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'pdf';
                          const newFile: UploadedFile = {
                            id: Math.random().toString(36).substr(2, 9),
                            name: file.name,
                            type: type as any,
                            url: URL.createObjectURL(file)
                          };
                          setMessageData({ ...messageData, files: [...messageData.files, newFile] });
                        }
                      }}
                    />
                  </label>
                )}
              </div>
            </div>
          </div>

          <button 
            onClick={onSend}
            disabled={isSending || !messageData.number || !messageData.text}
            className="w-full py-6 bg-slate-900 hover:bg-black disabled:bg-slate-200 text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-[2rem] shadow-2xl transition-all active:scale-[0.98] flex items-center justify-center gap-4 group"
          >
            {isSending ? (
              <>
                <RefreshCw size={18} className="animate-spin text-indigo-400" />
                Synchronizing...
              </>
            ) : (
              <>
                <Send size={18} className="group-hover:translate-x-1 transition-transform" />
                Fire Transmission
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
};


const UserCampaignsModal = ({ user, campaigns, onClose, onViewCampaign, onReport, onEdit, onTestMessage, onReset, onRestore, onRefundNonWA }: { 
  user: User, 
  campaigns: Campaign[], 
  onClose: () => void,
  onViewCampaign: (campaign: Campaign) => void,
  onReport?: (campaign: Campaign) => void,
  onEdit?: (campaign: Campaign) => void,
  onTestMessage?: (campaign: Campaign) => void,
  onReset?: (id: string) => void,
  onRestore?: (id: string) => void,
  onRefundNonWA?: (id: string) => void
}) => (
  <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
    <motion.div 
      initial={{ opacity: 0, scale: 0.9, y: 30 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9, y: 30 }}
      className="glass rounded-[3rem] shadow-2xl w-full max-w-5xl overflow-hidden border border-white/40 flex flex-col"
    >
      <div className="p-10 border-b border-white/20 bg-white/40 shadow-sm flex justify-between items-center">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 rounded-3xl bg-indigo-600 flex items-center justify-center text-white font-black text-xl shadow-lg">
            {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
          </div>
          <div className="space-y-1">
            <h3 className="text-2xl font-black text-slate-900 uppercase tracking-tight">{user.name}'s Archive</h3>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Retrieved operation logs for subject ID: {user.id.slice(0, 8)}</p>
          </div>
        </div>
        <button onClick={onClose} className="w-12 h-12 bg-white/60 hover:bg-white rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all shadow-sm group border border-white/40">
          <X size={24} className="group-hover:rotate-90 transition-transform" />
        </button>
      </div>
      
      <div className="p-10 max-h-[70vh] overflow-y-auto custom-scrollbar bg-white/10">
        {campaigns.length > 0 ? (
          <CampaignTable 
            campaigns={campaigns} 
            onView={onViewCampaign}
            onReport={onReport}
            onEdit={onEdit}
            onTestMessage={onTestMessage}
            onReset={onReset}
            onRestore={onRestore}
            onRefundNonWA={onRefundNonWA}
            isAdmin={true}
            isSystemAdmin={true}
          />
        ) : (
          <div className="text-center py-24 bg-white/20 rounded-[3rem] border-2 border-dashed border-white/60 flex flex-col items-center gap-6">
            <div className="w-20 h-20 bg-white/40 rounded-full flex items-center justify-center text-slate-300 shadow-inner">
              <Archive size={40} />
            </div>
            <div className="space-y-2">
               <p className="text-lg font-black text-slate-900 uppercase tracking-widest">Archive Empty</p>
               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">No operation data found in the current sector</p>
            </div>
          </div>
        )}
      </div>

      <div className="p-10 border-t border-white/20 bg-white/40 flex justify-end">
        <button 
          onClick={onClose}
          className="px-10 py-4 bg-slate-900 hover:bg-black text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-2xl shadow-xl transition-all active:scale-[0.98]"
        >
          Close Session
        </button>
      </div>
    </motion.div>
  </div>
);

const MediaVault = ({ icon: Icon, title, subtitle, files, onUpload, onRemove, accept }: { 
  icon: any,
  title: string, 
  subtitle: string,
  files: UploadedFile[], 
  onUpload: (file: File) => void,
  onRemove: (id: string) => void,
  accept: string
}) => (
  <div className="space-y-4">
    <div className="flex items-center gap-3 ml-1">
       <div className="w-8 h-8 rounded-xl bg-slate-900/5 flex items-center justify-center text-slate-500">
          <Icon size={16} />
       </div>
       <div className="flex flex-col">
          <span className="text-xs font-black text-slate-800 uppercase tracking-wider leading-none mb-1">{title}</span>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">{subtitle}</span>
       </div>
    </div>
    
    <div className="flex flex-col gap-3">
      {files.map(file => (
        <div key={file.id} className="flex items-center gap-3 p-3 bg-white border border-slate-100 rounded-2xl shadow-sm group">
           <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center overflow-hidden">
              {file.type === 'image' && file.url ? (
                <img src={file.url} alt="" className="w-full h-full object-cover" />
              ) : (
                <FileText size={20} className="text-slate-400" />
              )}
           </div>
           <div className="flex-1 min-w-0">
              <p className="text-[10px] font-black text-slate-700 truncate uppercase mt-1">{file.name}</p>
              <p className="text-[9px] font-bold text-slate-400">READY FOR DISPATCH</p>
           </div>
           <button 
             onClick={() => onRemove(file.id)}
             className="w-8 h-8 rounded-lg bg-red-50 text-red-500 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center hover:bg-red-500 hover:text-white"
           >
              <Trash2 size={14} />
           </button>
        </div>
      ))}
      
      {(title.toLowerCase().includes('image') ? files.length < 2 : files.length < 1) && (
        <label 
          key={`${title.toLowerCase().replace(/\s+/g, '-')}-uploader`}
          className="w-full flex flex-col items-center justify-center gap-2 border-2 border-dashed border-slate-200 py-8 rounded-[2rem] text-xs font-black text-slate-400 hover:border-slate-300 hover:bg-slate-50/50 transition-all cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 group-hover:scale-110 transition-transform">
             <Plus size={18} />
          </div>
          <span className="uppercase tracking-widest">Add Resource</span>
          <input 
            type="file" 
            className="hidden" 
            accept={accept}
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                onUpload(file);
                e.target.value = '';
              }
            }}
          />
        </label>
      )}
    </div>
  </div>
);

const StatCard = React.memo(({ label, value, color, icon: Icon }: { label: string, value: string | number, color: 'blue' | 'green' | 'purple' | 'amber' | 'emerald', icon?: any }) => {
  const colorMap = {
    blue: 'from-blue-500 to-indigo-600 shadow-blue-500/20',
    green: 'from-emerald-500 to-teal-600 shadow-emerald-500/20',
    purple: 'from-purple-500 to-pink-600 shadow-purple-500/20',
    amber: 'from-amber-500 to-orange-600 shadow-amber-500/20',
    emerald: 'from-emerald-400 to-emerald-600 shadow-emerald-500/20',
  };

  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="glass p-6 rounded-[2rem] flex flex-col justify-between group transition-all"
    >
      <div className="flex items-center justify-between mb-4">
        <div className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${colorMap[color]} flex items-center justify-center text-white shadow-lg`}>
          {Icon ? <Icon size={24} /> : <Rocket size={24} />}
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</span>
          <div className="h-1 w-12 bg-slate-100 rounded-full mt-1 group-hover:w-20 transition-all duration-500 overflow-hidden">
             <div className={`h-full bg-gradient-to-r ${colorMap[color]} w-2/3`} />
          </div>
        </div>
      </div>
      
      <div className="flex items-baseline gap-1">
        <h4 className="text-4xl font-black text-slate-900 tracking-tight">{value}</h4>
        <span className="text-xs font-bold text-slate-400">Total</span>
      </div>
    </motion.div>
  );
});

const TopUsersTable = React.memo(({ users }: { users: { id: string, name: string, totalSpent: number, campaignCount: number }[] }) => (
  <div className="overflow-x-auto custom-scrollbar">
    <table className="w-full text-left border-collapse">
      <thead>
        <tr className="border-b border-slate-100">
          <th className="py-5 px-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] w-24">Ranking</th>
          <th className="py-5 px-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Profile Identity</th>
          <th className="py-5 px-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Campaigns</th>
          <th className="py-5 px-6 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-right">Credit Allocation</th>
        </tr>
      </thead>
      <tbody>
        {users.map((user, index) => (
          <tr key={user.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50 transition-colors group">
            <td className="py-5 px-6">
               <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black ${
                 index === 0 ? 'bg-amber-100 text-amber-600 border border-amber-200' :
                 index === 1 ? 'bg-slate-100 text-slate-500 border border-slate-200' :
                 index === 2 ? 'bg-orange-50 text-orange-600 border border-orange-100' :
                 'text-slate-400'
               }`}>
                 {index + 1}
               </div>
            </td>
            <td className="py-5 px-6">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-slate-100 to-slate-200 flex items-center justify-center font-black text-slate-500 text-xs shadow-sm">
                   {user.name.charAt(0).toUpperCase()}
                </div>
                <span className="text-sm font-bold text-slate-700">{user.name}</span>
              </div>
            </td>
            <td className="py-5 px-6 text-sm font-bold text-slate-500 text-center">
               <span className="bg-slate-100 px-3 py-1 rounded-full">{user.campaignCount}</span>
            </td>
            <td className="py-5 px-6 text-sm text-emerald-600 font-black text-right">
               {user.totalSpent.toLocaleString()} <span className="text-[10px] text-slate-400 ml-1 uppercase">Units</span>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
));

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};



export default function App() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Lifted state variables for backend persistence and routing
  const [cities, setCities] = useState<string[]>([
    "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar",
    "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Goa",
    "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka",
    "Kerala", "Ladakh", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya",
    "Mizoram", "Nagaland", "Odisha", "Puducherry", "Punjab", "Rajasthan", "Sikkim",
    "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"
  ]);
  const [mockDb, setMockDb] = useState<string[]>([]);
  const [nonWaDb, setNonWaDb] = useState<string[]>([]);
  const [whitelistRecords, setWhitelistRecords] = useState<NumberSearchRecord[]>([]);
  const [nonWhatsappRecords, setNonWhatsappRecords] = useState<NumberSearchRecord[]>([]);
  const [adminStaff, setAdminStaff] = useState<AdminStaff[]>([
    { 
      id: '1', 
      name: 'Ravi', 
      email: 'ravi@admin.com', 
      status: 'Active',
      accesses: { 'Admin Staff': true, 'Users': true }
    }
  ]);
  const [generalConfigs, setGeneralConfigs] = useState([
    { id: 'gen-1', name: 'Image Size', size: '03 MB' },
    { id: 'gen-2', name: 'Number of Images', size: '2' },
    { id: 'gen-3', name: 'PDF Size', size: '03 MB' },
    { id: 'gen-4', name: 'Number Of PDFs', size: '1' },
    { id: 'gen-5', name: 'Video Size', size: '10 MB' },
    { id: 'gen-6', name: 'Number of Videos', size: '1' },
    { id: 'gen-7', name: 'Running Message', size: 'Campaign will be deliver between 8.00 AM to 6 PM, Monday - Saturday.' },
    { id: 'gen-8', name: 'Auto Send Campaign No.', size: '10' },
    { id: 'gen-9', name: 'Phase Number Count', size: '50' },
    { id: 'gen-10', name: 'Phase Gap Time', size: '100' },
    { id: 'gen-11', name: 'Phase Gap Time Filter', size: '1000' },
    { id: 'gen-12', name: 'Maximum Phone Numbers', size: '10000000' }
  ]);
  const [domesticConfigs, setDomesticConfigs] = useState([
    { id: 'dom-1', name: 'DOM Demo Max Campaigns Allowed', size: '3' },
    { id: 'dom-2', name: 'DOM Max Campaigns Allowed', size: '15' },
    { id: 'dom-3', name: 'DOM Campaigns Allowed From Time', size: '08:01 AM' },
    { id: 'dom-4', name: 'DOM Campaigns Allowed To Time', size: '06:01 PM' },
    { id: 'dom-5', name: 'DOM Demo Campaigns Allowed From Time', size: '09:31 AM' },
    { id: 'dom-6', name: 'DOM Demo Campaigns Allowed To Time', size: '08:59 PM' },
    { id: 'dom-7', name: 'DOM Demo Default Filtering Server ID', size: '6865348853639d14732f3a85' },
    { id: 'dom-8', name: 'DOM Demo Default Running Server ID', size: '6865348853639d14732f3a85' }
  ]);
  const [internationalConfigs, setInternationalConfigs] = useState([
    { id: 'int-1', name: 'INT Demo Max Campaigns Allowed', size: '3' },
    { id: 'int-2', name: 'INT Max Campaigns Allowed', size: '15' },
    { id: 'int-3', name: 'INT Campaigns Allowed From Time', size: '08:01 AM' },
    { id: 'int-4', name: 'INT Campaigns Allowed To Time', size: '06:01 PM' },
    { id: 'int-5', name: 'INT Demo Campaigns Allowed From Time', size: '09:31 AM' },
    { id: 'int-6', name: 'INT Demo Campaigns Allowed To Time', size: '08:59 PM' },
    { id: 'int-7', name: 'INT Demo Default Filtering Server ID', size: '6865348853639d14732f3a85' },
    { id: 'int-8', name: 'INT Demo Default Running Server ID', size: '6865348853639d14732f3a85' }
  ]);
  const [buttonConfigs, setButtonConfigs] = useState([
    { id: 'btn-1', name: 'BTN Demo Max Campaigns Allowed', size: '3' },
    { id: 'btn-2', name: 'BTN Max Campaigns Allowed', size: '15' },
    { id: 'btn-3', name: 'BTN Campaigns Allowed From Time', size: '08:01 AM' },
    { id: 'btn-4', name: 'BTN Campaigns Allowed To Time', size: '06:01 PM' },
    { id: 'btn-5', name: 'BTN Demo Campaigns Allowed From Time', size: '09:31 AM' },
    { id: 'btn-6', name: 'BTN Demo Campaigns Allowed To Time', size: '08:59 PM' },
    { id: 'btn-7', name: 'BTN Demo Default Filtering Server ID', size: '6865348853639d14732f3a85' },
    { id: 'btn-8', name: 'BTN Demo Default Running Server ID', size: '6865348853639d14732f3a85' }
  ]);
  
  const showToast = (message: string, type: Toast['type'] = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts(prev => [...prev, { id, message, type }]);
    
    // Auto remove after 4 seconds
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = safeLocalStorage.getItem('app_logged_in_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse logged-in user", e);
      }
    }
    return null;
  });

  useEffect(() => {
    if (currentUser) {
      safeLocalStorage.setItem('app_logged_in_user', JSON.stringify(currentUser));
    } else {
      safeLocalStorage.removeItem('app_logged_in_user');
    }
  }, [currentUser]);

  const [campaigns, setCampaigns] = useState<Campaign[]>([]);

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [users, setUsers] = useState<User[]>([
    {
      id: 'admin',
      name: 'Administrator',
      username: 'anil',
      password: 'sain',
      mobile: '9999999999',
      email: 'admin@example.com',
      role: 'Admin',
      status: 'Active',
      location: 'Delhi',
      uplink: 'system',
      domCredits: 1000000,
      intCredits: 1000000,
      btnCredits: 1000000,
      cuttingPercentage: '0',
      createdAt: '2026-05-30T10:00:00.000Z',
      planExpiryDate: '2030-05-30T10:00:00.000Z', // infinite/extremely long for admin
      campaignApproved: true
    },
    {
      id: '2',
      name: 'Priyanka',
      username: 'priyanka',
      password: 'priyanka',
      mobile: '9932082831',
      email: 'priyanka@example.com',
      role: 'User',
      status: 'Active',
      location: 'Delhi',
      uplink: 'admin',
      domCredits: 100,
      intCredits: 0,
      btnCredits: 100,
      cuttingPercentage: '0',
      createdAt: '2026-05-30T10:00:00.000Z',
      planExpiryDate: '2027-05-30T10:00:00.000Z', // 1 year limit
      campaignApproved: true
    }
  ]);

  // DB Sync state indicator to avoid overwriting during load
  const [dbLoading, setDbLoading] = useState(true);
  const initialLoadDone = useRef(false);

  // Load from MySQL Database on mount
  useEffect(() => {
    fetch('/api/db/init')
      .then(res => res.json())
      .then(data => {
        if (data.success && data.mongodbConnected) {
          console.log("🎒 Loaded data from secure MySQL Database!");
          if (data.users && data.users.length > 0) {
            setUsers(data.users);
          }
          if (data.campaigns && data.campaigns.length > 0) {
            setCampaigns(data.campaigns);
          }
          if (data.transactions && data.transactions.length > 0) {
            setTransactions(data.transactions);
          }
          if (data.cities && data.cities.length > 0) {
            setCities(data.cities);
          }
          if (data.whitelistedNumbers && data.whitelistedNumbers.length > 0) {
            setMockDb(data.whitelistedNumbers);
          }
          if (data.nonWhatsappNumbers && data.nonWhatsappNumbers.length > 0) {
            setNonWaDb(data.nonWhatsappNumbers);
          }
          if (data.whitelistRecords && data.whitelistRecords.length > 0) {
            setWhitelistRecords(data.whitelistRecords);
          }
          if (data.nonWhatsappRecords && data.nonWhatsappRecords.length > 0) {
            setNonWhatsappRecords(data.nonWhatsappRecords);
          }
          if (data.adminStaff && data.adminStaff.length > 0) {
            setAdminStaff(data.adminStaff);
          }
          if (data.campaignConfig && data.campaignConfig.length > 0) {
            const gen = data.campaignConfig.filter((c: any) => c.category === 'General');
            const dom = data.campaignConfig.filter((c: any) => c.category === 'Domestic');
            const inter = data.campaignConfig.filter((c: any) => c.category === 'International');
            const btn = data.campaignConfig.filter((c: any) => c.category === 'Button');
            if (gen.length > 0) setGeneralConfigs(gen);
            if (dom.length > 0) setDomesticConfigs(dom);
            if (inter.length > 0) setInternationalConfigs(inter);
            if (btn.length > 0) setButtonConfigs(btn);
          }
          // Synchronize currentUser from state if still logged in
          const savedUser = safeLocalStorage.getItem('app_logged_in_user');
          if (savedUser) {
            try {
              const uObj = JSON.parse(savedUser);
              const latestUser = data.users?.find((u: any) => u.id === uObj.id);
              if (latestUser) {
                setCurrentUser(latestUser);
               }
            } catch (e) {}
          }
        }
        setDbLoading(false);
        setTimeout(() => {
          initialLoadDone.current = true;
        }, 300);
      })
      .catch(err => {
        console.error("Error connecting or fetching from DB:", err);
        setDbLoading(false);
        setTimeout(() => {
          initialLoadDone.current = true;
        }, 300);
      });
  }, []);

  // Synchronize users changes to MySQL Database
  useEffect(() => {
    if (initialLoadDone.current && !dbLoading) {
      fetch('/api/db/sync-users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ users })
      }).catch(err => console.error("MySQL user sync failed:", err));
    }
  }, [users]);

  // Synchronize campaigns changes to MySQL Database
  useEffect(() => {
    if (initialLoadDone.current && !dbLoading) {
      fetch('/api/db/sync-campaigns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ campaigns })
      }).catch(err => console.error("MySQL campaigns sync failed:", err));
    }
  }, [campaigns]);

  // Synchronize transactions changes to MySQL Database
  useEffect(() => {
    if (initialLoadDone.current && !dbLoading) {
      fetch('/api/db/sync-transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transactions })
      }).catch(err => console.error("MySQL transactions sync failed:", err));
    }
  }, [transactions]);

  // Synchronize cities
  useEffect(() => {
    if (initialLoadDone.current && !dbLoading) {
      fetch('/api/db/sync-cities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cities })
      }).catch(err => console.error("Cities sync failed:", err));
    }
  }, [cities]);

  // Synchronize whitelisted numbers
  useEffect(() => {
    if (initialLoadDone.current && !dbLoading) {
      fetch('/api/db/sync-whitelisted-numbers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ whitelistedNumbers: mockDb })
      }).catch(err => console.error("Whitelisted numbers sync failed:", err));
    }
  }, [mockDb]);

  // Synchronize non whatsapp numbers
  useEffect(() => {
    if (initialLoadDone.current && !dbLoading) {
      fetch('/api/db/sync-non-whatsapp-numbers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nonWhatsappNumbers: nonWaDb })
      }).catch(err => console.error("Non Whatsapp numbers sync failed:", err));
    }
  }, [nonWaDb]);

  // Synchronize whitelist records
  useEffect(() => {
    if (initialLoadDone.current && !dbLoading) {
      fetch('/api/db/sync-whitelist-records', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ whitelistRecords })
      }).catch(err => console.error("whitelistRecords sync failed:", err));
    }
  }, [whitelistRecords]);

  // Synchronize non whatsapp records
  useEffect(() => {
    if (initialLoadDone.current && !dbLoading) {
      fetch('/api/db/sync-non-whatsapp-records', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nonWhatsappRecords })
      }).catch(err => console.error("nonWhatsappRecords sync failed:", err));
    }
  }, [nonWhatsappRecords]);

  // Synchronize admin staff
  useEffect(() => {
    if (initialLoadDone.current && !dbLoading) {
      fetch('/api/db/sync-admin-staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminStaff })
      }).catch(err => console.error("Admin staff sync failed:", err));
    }
  }, [adminStaff]);

  // Synchronize campaign configs
  useEffect(() => {
    if (initialLoadDone.current && !dbLoading) {
      const allConfigs = [...generalConfigs, ...domesticConfigs, ...internationalConfigs, ...buttonConfigs];
      fetch('/api/db/sync-campaign-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ configs: allConfigs })
      }).catch(err => console.error("campaign configs sync failed:", err));
    }
  }, [generalConfigs, domesticConfigs, internationalConfigs, buttonConfigs]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    showToast(`Welcome back, ${user.name}! 👋`);
    if (user.role === 'Admin') {
      setTimeout(() => {
        showToast('Jai Shri Ram 🚩', 'success');
      }, 600);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    showToast('Logged out successfully');
  };

  return (
    <div className="font-sans antialiased text-slate-900">
      <ToastContainer toasts={toasts} removeToast={removeToast} />
      {!currentUser ? (
        <LoginPage users={users} onLogin={handleLogin} />
      ) : (
        <Dashboard 
          currentUser={currentUser} 
          setCurrentUser={setCurrentUser}
          users={users} 
          setUsers={setUsers} 
          campaigns={campaigns}
          setCampaigns={setCampaigns}
          transactions={transactions}
          setTransactions={setTransactions}
          onLogout={handleLogout} 
          showToast={showToast}
          cities={cities}
          setCities={setCities}
          mockDb={mockDb}
          setMockDb={setMockDb}
          nonWaDb={nonWaDb}
          setNonWaDb={setNonWaDb}
          whitelistRecords={whitelistRecords}
          setWhitelistRecords={setWhitelistRecords}
          nonWhatsappRecords={nonWhatsappRecords}
          setNonWhatsappRecords={setNonWhatsappRecords}
          adminStaff={adminStaff}
          setAdminStaff={setAdminStaff}
          generalConfigs={generalConfigs}
          setGeneralConfigs={setGeneralConfigs}
          domesticConfigs={domesticConfigs}
          setDomesticConfigs={setDomesticConfigs}
          internationalConfigs={internationalConfigs}
          setInternationalConfigs={setInternationalConfigs}
          buttonConfigs={buttonConfigs}
          setButtonConfigs={setButtonConfigs}
        />
      )}
    </div>
  );
}
