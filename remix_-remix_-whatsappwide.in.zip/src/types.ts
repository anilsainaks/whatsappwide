export type Page = 
  | 'Dashboard' 
  | 'Demo Server'
  | 'My Campaigns' 
  | 'Pending Campaign' 
  | 'Finished Campaign' 
  | 'Rejected Campaign' 
  | 'Create Campaign' 
  | 'Create Button Campaign' 
  | 'User Management' 
  | 'Non Whatsapp Number' 
  | 'White Listing Number' 
  | 'White Listing DB'
  | 'Campaign Config' 
  | 'Cities' 
  | 'Admin Staff' 
  | 'Manage Transactions' 
  | 'Private Sender'
  | 'Private Subscriptions'
  | 'Terms & Conditions';

export interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

export interface PrivateSenderMessage {
  id: string;
  to: string;
  status: 'sent' | 'delivered' | 'read' | 'failed';
  timestamp: number;
  text?: string;
  campaignName?: string;
}

export type FilterMode = 'all' | 'whitelisted' | 'common' | 'both' | 'agent';

export interface Campaign {
  id: string;
  name: string;
  status: 'Active' | 'Completed' | 'Pending' | 'Rejected';
  date: string;
  message?: string;
  files?: UploadedFile[];
  type?: 'Standard' | 'Button' | 'International';
  userId?: string;
  userName?: string;
  creditsUsed?: number;
  rejectionReason?: string;
  isDemo?: boolean;
  assignedServerId?: string;
  filterMode?: FilterMode;
  numbers?: string[];
  isPaused?: boolean;
  isScanned?: boolean;
  sentCount?: number;
  totalCount?: number;
  originalNumbers?: string[];
  buttonDetails?: {
    linkText?: string;
    linkUrl?: string;
    callText?: string;
    callNumber?: string;
  };
  reportData?: { number: string, status: string, isOverridden?: boolean, senderName?: string, senderNumber?: string }[];
  isRefunded?: boolean;
}

export interface UploadedFile {
  id: string;
  name: string;
  type: 'image' | 'video' | 'pdf';
  url?: string;
}

export interface User {
  id: string;
  name: string;
  username: string;
  password: string;
  mobile: string;
  email: string;
  role: 'Admin' | 'User' | 'Reseller';
  status: 'Active' | 'Suspended' | 'Deleted';
  location: string;
  uplink: string;
  domCredits: number;
  intCredits: number;
  btnCredits: number;
  cuttingPercentage: string;
  privateSenderExpiry?: string; 
  privateSenderActivation?: string; 
  privateSenderSubscription?: 'none' | 'pending' | 'approved';
  privateSenderPendingDuration?: number;
  createdAt?: string;
  planExpiryDate?: string;
  campaignApproved?: boolean;
}

export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  type: 'domestic' | 'international' | 'button';
  date: string;
  note: string;
  action: 'Added' | 'Deducted';
}

export interface NumberSearchRecord {
  id: string;
  number: string;
  status: string;
  result: string;
}

export interface AdminStaff {
  id: string;
  name: string;
  email: string;
  status: 'Active' | 'Inactive';
  accesses: { [key: string]: boolean };
}

export interface Channel {
  id: string;
  name: string;
  number?: string;
  status: 'Connected' | 'Disconnected' | 'Connecting' | 'Expired' | 'Logged Out';
  lastUsed?: string;
  isRestricted?: boolean;
}
