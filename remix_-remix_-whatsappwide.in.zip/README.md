# 📱 WhatsApp Wide - WhatsApp Marketing & Campaigns Panel

Welcome to **WhatsApp Wide**, a high-performance marketing and message broadcast panel. This project connects to WhatsApp directly using the `@whiskeysockets/baileys` library, allowing you to run bulk messaging campaigns, create custom sender profiles, manage users/resellers, and track message delivery states.

---

## 🛠️ Project Architecture (Project Kise Bana Hai?)

This is a **Full-Stack Application** built with a seamless division of labor between frontend and backend:

1. **Frontend (React + Vite + Tailwind CSS)**: 
   - Located in the `/src` folder, primarily managed via `/src/App.tsx`.
   - Renders a visually stunning dashboard with distinct modules for campaigns, WhatsApp QR scanning, analytics, transaction history, user management, and resellers.
   
2. **Backend (Express + Baileys SDK)**:
   - Located in `/server.ts` at the root folder.
   - Directly spins up instances of the Baileys WhatsApp client, manages authentication sessions inside folders (`auth_info_baileys` and `auth_info_private_sender`), streams real-time state changes, generates dynamic QR Codes as Base64 strings, and exposes REST endpoints for trigger execution.

---

## 🔒 Session, Database & Credit Security Analysis (Credits aur Security)

### Q1. Credits kahan se aa rahe hain—Database se ya Session se? 
**Answer:**
Abhi development/prototype state mein, **Credits and Users ka sara data browser ke LocalStorage mein save ho raha hai**:
- `localStorage.getItem('app_users')` — Sabhi users ka data details aur credit limits store karta hai.
- `localStorage.getItem('app_campaigns')` — Campaigns ki tracking information hold karta hai.
- `localStorage.getItem('app_logged_in_user')` — Login session store karta hai.

---

### Q2. "Agar main ise live kar doon aur koi browser session/local storage mein jaakar credits edit kar de, toh kya woh humare panel ko bypass kar lega?"
**Answer:**
**HAAN (YES), bilkul bypass kar sakta hai agar aap isse bina database ke as-is live kar dete hain.**

Chunki saara state browser-side (client-side) `localStorage` mein store hai:
1. Koi bhi user browser ka Inspect Element/DevTools kholkar App Storage context mein jaakar `localStorage` files ko edit kar sakta hai aur apne credits increase kar sakta hai ya role `'User'` se change karke `'Reseller'` ya `'Admin'` kar sakta hai.
2. Kyunki client-side secure nahi hota, isiliye live karne ke liye ye steps important hain:

#### 🛡️ Production Safe Banane Ke Tarike (How to secure it):
1. **Durable Cloud Database lagayein**: Standard database (jaise Firebase/Firestore, PostgreSQL) integration sikhne aur setup karne ke liye AI Studio mein **Firebase** ka connection direct use kar sakte hain. Firebase client aur server se sync rehta hai.
2. **Backend credit validation (server-side check)**: Jab bhi frontend se message send karne ki request `/api/whatsapp/send` ya`/api/private-sender/bulk-send` par jaye, backend (`server.ts`) pehle database se user ke real credits verify kare. Send command chalne ke baad backend hi database ke andar credits minus kare, na ki frontend se.
3. **Session-based Authentication**: JWT (JSON Web Tokens) or Server-side Session management implement karein login security verify karne ke liye taaki koi local storage change karke login bypass na kar sake.

---

## 🖥️ Local System Run Setup Guide (Local Machine Par Kaise Chalayein?)

Terminals Web Editor mein disabled dikhate hain kyunki live code execution container ke server end se backend par manage hota hai. Lekin aap is pure project ko download karke apne local computer ya server par chala sakte hain.

### Step 1: Clone/Download Project
Apne AI Studio ke **Settings** ya top corner menus se **Export Code as ZIP** karien ya fir upar option se direct **Google Cloud Shell** ya **Github repository** mein link kar ke copy fetch karein. Seva local disk par code extract karein.

### Step 2: Install Node.js
Apne machine par Node.js (Version **18 or 20+ Recommended**) install karein:
- Download here: [https://nodejs.org](https://nodejs.org)

### Step 3: Local MySQL Database Setup (MySQL local server par kaise setup karein)
Aap is panel ko local run karne ke liye local MySQL use karenge. Iske liye neeche diye gaye steps follow karein:
1. **Install MySQL Server**: Apne computer par **XAMPP** download karein ya fir custom **MySQL Community Server** install karein:
   - XAMPP: [https://www.apachefriends.org/index.html](https://www.apachefriends.org/index.html) (Best options, isme direct Apache aur MySQL dono mil jate hain)
2. **Start MySQL Service**: Agat aap XAMPP use kar rahe hain, toh **XAMPP Control Panel** kholkar **MySQL** ke aage **Start** button par click karein.
3. **Environment Setup (.env file)**: Project root directory par ek nayi file banayein jiska naam rakhein `.env` aur usme neeche likhe variables enter karein:
   ```env
   # API KEY & CONFIGURATION
   GEMINI_API_KEY="YOUR_KEY_HERE"
   APP_URL="http://localhost:3000"

   # DATABASE CONFIGURATION
   DB_TYPE="mysql"

   # MySQL Details (Local localhost details)
   MYSQL_HOST="localhost"
   MYSQL_PORT=3306
   MYSQL_USER="root"
   MYSQL_PASSWORD=""
   MYSQL_DATABASE="whatsappwide"
   ```
4. **No Database Creation Required**: Node backend automatically startup ke waqt local MySQL Server par database (`whatsappwide`) check/create kar leta hai aur auto-migrations se saari tables (`users`, `campaigns`, `transactions`) seed-data ke sath automatic prepare kar deta hai! Aapko manual commands chalane ki zarurat nahi padegi.

### Step 4: Install Dependencies
Project folder ke andar terminal khol kar run karien:
```bash
npm install
```
*Note: Isse node_modules folder banega aur sabhi core packages (`@whiskeysockets/baileys`, `express`, `react`, `lucide-react`, `mysql2`) automatic download ho jayenge.*

### Step 5: Run Development Server
Local machine par fast live tracking aur testing ke liye compile-run command:
```bash
npm run dev
```
Ye command backend container `server.ts` ko init karegi aur standard developer port `http://localhost:3000` par aapka program local environment aur MySQL ke sath fully functional active ho jayega.

### Step 6: Default Login Access
MySQL local database build hone ke baad user details automatic insert ho jayengi. Aap is admin credential se login kar sakte hain:
- **Username**: `anil`
- **Password**: `sain`

### Step 7: Production Build (Deployment ke liye prepare karein)
Apne production server/VPS par daalne se pehle static content aur bundles minify karne ke liye run karein:
```bash
npm run build
```
Ye automatic **Vite Client build** generate karega aur backend typescript server files ko single server bundler output file `dist/server.cjs` mein secure tarah se pack kar dega.

### Step 8: Start Production Server
Deployment live server start karne ke liye:
```bash
npm run start
```

---

## 📄 Which License is required for GitHub? (Kaunsa License Chahiye?)

GitHub par push karte waqt aapse pucha jayega ki projects ko open security provide karni hai ya private protect karna hai. Neeche diye gaye licenses select karein:

1. **All Rights Reserved (No License File)**:
   - *Kab use karein*: Agar aap ye product bechna chahte hain (commercial billing platform) aur aap nahi chahte ki koi aapka code copy karke khud ka business chalaye.
   - *Fayda*: Aapka code koi use, modify ya distribute bina permission nahi kar sakta.

2. **MIT License (Open-Source)**:
   - *Kab use karein*: Agar aap isko open contribution source project banana chahte hain.
   - *Fayda*: Ye bohot friendly license hai. Koi bhi use, modify aur copy kar sakta hai, bas aapki credit line project folder me bani rahegi.

3. **GPL v3 or Apache 2.0**:
   - *Kab use karein*: Agar aap chahte hain ki agar koi aapka code churate/kop karte waqt koi changes kare, toh unke liye bhi apna changed code mandatory open-source rakhna pade.

**Sifarish (Recommendation):** Chunki ye ek proprietary business marketing tool hai, isme **"All Rights Reserved"** (Kisi license ko select na karein aur license file delete rakhein) ya standard **Private Repository** upload use karein.

---

## ⚙️ Implemented WhatsApp Engine Bug Fix (515 Reconnection Fix)

WhatsApp connections mein dual dynamic states handle kiye gaye hain. Jab aapki virtual instance disconnect hoti thi aur WhatsApp state server code loops fetch nahi kar pata tha (Error `515 Stream Errored` ya verification failures), codes recursive errors loop banate the.

Humne is platform mein implementation details apply kar diye hain:
```typescript
// server.ts updates
if ((session!.reconnectAttempts || 0) >= 5) {
   console.warn(`[WA] Session ${id} hit persistent error code after multiple failed attempts. Force clearing state folder and requesting QR re-scan...`);
   // Auto-safety folder cleanup prevents recursive loops crashing node stack memory!
   deleteFolderRecursive(sessionAuthFolder);
}
```
Isse memory buffers crash hone se bachte hain aur browser bina reload kiye safely QR scan page par revert ho jata hai.

---

### 🙌 Summary checklist of variables:
In `.env` create:
```env
# Credentials
GEMINI_API_KEY="YOUR_KEY"
APP_URL="http://localhost:3000"
```
Enjoy running and monetizing your **WhatsApp Wide Platform**! 🚀
