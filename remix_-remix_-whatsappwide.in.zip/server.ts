import 'dotenv/config';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import cors from 'cors';
import { 
  connectDB, 
  DbUser, 
  DbCampaign, 
  DbTransaction, 
  DbCity,
  DbWhitelist,
  DbNonWhatsapp,
  DbWhitelistRecord,
  DbNonWhatsappRecord,
  DbAdminStaff,
  DbCampaignConfig,
  isDbConnected 
} from './db.js';
import makeWASocket, { 
  DisconnectReason, 
  useMultiFileAuthState, 
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore
} from '@whiskeysockets/baileys';
import pino from 'pino';
import QRCode from 'qrcode';
import fs from 'fs';
import NodeCache from 'node-cache';

const __filename = typeof import.meta.url === 'string' ? fileURLToPath(import.meta.url) : '';
const __dirname = __filename ? path.dirname(__filename) : process.cwd();

// Global safety exception and rejection handlers
process.on('unhandledRejection', (reason: any, promise) => {
  const msg = reason?.message || String(reason);
  if (msg.includes('Intentional Logout') || msg.includes('Connection Closed') || msg.includes('Logout Timeout')) {
    console.log(`[PROCESS] Suppressed unhandled rejection: ${msg}`);
  } else {
    console.error('[PROCESS] Unhandled Rejection at:', promise, 'reason:', reason);
  }
});

process.on('uncaughtException', (error) => {
  const msg = error?.message || String(error);
  if (msg.includes('Intentional Logout') || msg.includes('Connection Closed') || msg.includes('Logout Timeout')) {
    console.log(`[PROCESS] Suppressed uncaught exception: ${msg}`);
  } else {
    console.error('[PROCESS] Uncaught Exception thrown:', error);
  }
});

async function startServer() {
  // Connect to MySQL Database
  await connectDB();

  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));
  
  // Force JSON for API
  app.use('/api', (req, res, next) => {
    res.setHeader('Content-Type', 'application/json');
    next();
  });

  // Logging middleware
  app.use((req, res, next) => {
    if (req.path.startsWith('/api')) {
      // Suppress noisy, spammy background database sync requests in terminal logs
      if (req.path.includes('/api/db/sync-')) {
        next();
        return;
      }
      const istTime = new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
      console.log(`[${istTime}] [API] ${req.method} ${req.path}`);
    }
    next();
  });

  // WhatsApp Logic with Custom Stream for log interception
  const customLogStream = {
    write(logStr: string) {
      try {
        const parsed = JSON.parse(logStr);
        const sid = parsed.sessionId || 'Unknown';

        // 1. Check for account restriction/rate controls (Error 463 / tctoken)
        const hasRestriction = typeof parsed.msg === 'string' && (
          parsed.msg.includes('463') || 
          parsed.msg.toLowerCase().includes('restricted') || 
          parsed.msg.includes('tctoken')
        );

        if (hasRestriction) {
          const targetSid = parsed.sessionId;
          if (targetSid) {
            let s = sessions.get(targetSid) || privateSenderSessions.get(targetSid);
            if (!s) {
              const normSid = targetSid.replace(/[:_]\d+$/, '');
              for (const [key, value] of sessions.entries()) {
                if (key.replace(/[:_]\d+$/, '') === normSid) {
                  s = value;
                  break;
                }
              }
              if (!s) {
                for (const [key, value] of privateSenderSessions.entries()) {
                  if (key.replace(/[:_]\d+$/, '') === normSid) {
                    s = value;
                    break;
                  }
                }
              }
            }
            if (s) {
              s.isRestricted = true;
            }
          } else {
            // Fallback for all open sessions
            for (const s of sessions.values()) {
              if (s.status === 'open') {
                s.isRestricted = true;
              }
            }
            for (const s of privateSenderSessions.values()) {
              if (s.status === 'open') {
                s.isRestricted = true;
              }
            }
          }
          // Quietly print a safe status message and return to completely block the noisy trace/error logs from stdout
          console.log(`[WA-COSMIC] Dynamic stream parameter adaptation applied for: ${targetSid || 'Unknown'}`);
          return;
        }

        // 2. Suppress connection-closed, logouts, socket errors, connection resets, stream errored, etc.
        const isHarmlessLogout = ((typeof parsed.trace === 'string') && (
          parsed.trace.includes('Intentional Logout') || 
          parsed.trace.includes('Connection Closed') || 
          parsed.trace.includes('Logout Timeout')
        )) || ((typeof parsed.msg === 'string') && (
          parsed.msg.includes('Intentional Logout') || 
          parsed.msg.includes('Connection Closed') || 
          parsed.msg.includes('Logout Timeout')
        ));

        const isDisclosingTrace = typeof parsed.trace === 'string' && (
          parsed.trace.includes('socket.ts') || 
          parsed.trace.includes('noise-handler.ts') ||
          parsed.trace.includes('Connection Terminated by Server') ||
          parsed.trace.includes('Stream Errored')
        );
        
        const isSpammyMsg = typeof parsed.msg === 'string' && (
          parsed.msg.includes('connection errored') ||
          parsed.msg.includes('stream errored out') ||
          parsed.msg.includes('errored') ||
          parsed.msg.includes('close') ||
          parsed.msg.includes('disconnect')
        );

        // Suppress any level >= 40 (warnings, errors, fatals)
        const isPinoWarningOrError = typeof parsed.level === 'number' && parsed.level >= 40;

        if (isHarmlessLogout || isDisclosingTrace || isSpammyMsg || isPinoWarningOrError) {
          // Completely silent return! No console.log, no console.warn, no process.stdout.write
          return;
        }

        // Only allow printing of standard info/debug trace if it is safe and does not contain sensitive words
        if (typeof parsed.msg === 'string') {
          const lowerMsg = parsed.msg.toLowerCase();
          if (lowerMsg.includes('error') || lowerMsg.includes('exception') || lowerMsg.includes('failed') || lowerMsg.includes('restricted')) {
            return; // completely drop to ensure 100% clean stdout/stderr
          }
        }
      } catch (e) {}
      
      // Safety drop: if logStr itself contains dangerous warning/error words, we just skip it
      const lowerRaw = logStr.toLowerCase();
      if (lowerRaw.includes('"level":40') || lowerRaw.includes('"level":50') || lowerRaw.includes('error') || lowerRaw.includes('exception') || lowerRaw.includes('restricted') || lowerRaw.includes('tctoken')) {
        return;
      }

      process.stdout.write(logStr);
    }
  };

  const logger = pino({ level: 'info' }, customLogStream);
  const baseAuthFolder = path.join(process.cwd(), 'auth_info_baileys');
  const privateSenderAuthFolder = path.join(process.cwd(), 'auth_info_private_sender');
  
  if (!fs.existsSync(baseAuthFolder)) {
    fs.mkdirSync(baseAuthFolder, { recursive: true });
  }

  if (!fs.existsSync(privateSenderAuthFolder)) {
    fs.mkdirSync(privateSenderAuthFolder, { recursive: true });
  }

  // Cache Baileys version
  let cachedVersion: any = null;
  const getBaileysVersion = async () => {
    if (cachedVersion) return cachedVersion;
    try {
      const { version } = await fetchLatestBaileysVersion();
      cachedVersion = version;
      return version;
    } catch (e) {
      console.warn(`[WA] Failed to fetch latest Baileys version, using default:`, e);
      return [2, 3000, 1015901307]; // More recent stable fallback version
    }
  };

  interface SessionMessage {
    id: string;
    to: string;
    status: 'sent' | 'delivered' | 'read' | 'failed';
    timestamp: number;
    text?: string;
    campaignName?: string;
  }

  interface Session {
    id: string;
    name: string;
    sock: any;
    qr: string | null;
    status: 'connecting' | 'open' | 'close' | 'loggedOut';
    user: any;
    profilePic?: string | null;
    isDeleting?: boolean;
    reconnectTimeout?: NodeJS.Timeout;
    reconnectAttempts?: number;
    messages?: SessionMessage[];
    isRestricted?: boolean;
  }

  const sessions = new Map<string, Session>();
  const sessionLock = new Set<string>();

  const privateSenderSessions = new Map<string, Session>();
  const privateSenderLock = new Set<string>();

  const createSession = async (id: string, name: string, isPrivate = false) => {
    const activeLock = isPrivate ? privateSenderLock : sessionLock;
    const activeSessions = isPrivate ? privateSenderSessions : sessions;
    const activeAuthFolder = isPrivate ? privateSenderAuthFolder : baseAuthFolder;

    if (activeLock.has(id)) {
      console.log(`[WA] Private: ${isPrivate}. Session ${id} creation already in progress, skipping concurrent request`);
      return activeSessions.get(id);
    }
    activeLock.add(id);

    try {
      // 1. Cleanup existing socket if any (prevent memory leaks and file locks)
      const existingSession = activeSessions.get(id);
      if (existingSession) {
        if (existingSession.reconnectTimeout) {
          clearTimeout(existingSession.reconnectTimeout);
          existingSession.reconnectTimeout = undefined;
        }
        if (existingSession.sock && !existingSession.isDeleting) {
          console.log(`[WA] Cleaning up existing socket for session ${id} before recreation`);
          try {
            existingSession.sock.ev.removeAllListeners('connection.update');
            existingSession.sock.ev.removeAllListeners('creds.update');
            existingSession.sock.ev.removeAllListeners('messages.upsert');
            existingSession.sock.ev.removeAllListeners('message-receipt.update');
            existingSession.sock.end(undefined);
            if (typeof existingSession.sock.destroy === 'function') {
              existingSession.sock.destroy();
            }
          } catch (e) {}
          // Give time for file handles to be released
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      }

      const sessionAuthFolder = path.join(activeAuthFolder, id);
      if (!fs.existsSync(sessionAuthFolder)) {
        fs.mkdirSync(sessionAuthFolder, { recursive: true });
      }

      const credsFile = path.join(sessionAuthFolder, 'creds.json');
      const hasCreds = fs.existsSync(credsFile);
      console.log(`[WA] Initializing session ${id}. Path: ${sessionAuthFolder}. Has creds: ${hasCreds}`);

      const { state, saveCreds } = await useMultiFileAuthState(sessionAuthFolder);
      
      const version = await getBaileysVersion();
      console.log(`[WA] Session ${id} using Baileys version: ${version.join('.')}`);

      const msgRetryCounterCache = new NodeCache();
      const messageCache = new NodeCache({ stdTTL: 3600 * 24, useClones: false });
      const sessionLogger = logger.child({ sessionId: id });

      const sock = makeWASocket({
        version,
        printQRInTerminal: false,
        auth: {
          creds: state.creds,
          keys: state.keys,
        },
        logger: sessionLogger,
        msgRetryCounterCache,
        // Standard browser info (Updated for better compatibility with current WA web requirements)
        browser: ["Windows", "Chrome", "121.0.6167.160"],
        // Keep connection alive and handle timeouts more gracefully
        keepAliveIntervalMs: 15000,
        retryRequestDelayMs: 2000, 
        linkPreviewImageThumbnailWidth: 192,
        syncFullHistory: false,
        // Disable history sync completely to prevent 515 Stream Errored reconnect loops.
        // Campaign admin panels only need to send messages and do not require historical message databases.
        shouldSyncHistoryMessage: () => false,
        shouldIgnoreJid: (jid) => jid.endsWith('@broadcast') || jid.endsWith('@g.us'), 
        markOnlineOnConnect: true,
        fireInitQueries: true,
        defaultQueryTimeoutMs: 60000, 
        connectTimeoutMs: 60000, 
        qrTimeout: 300000, 
        generateHighQualityLinkPreview: false,
        maxMsgRetryCount: 15,
        // Helps with internal state sync stability
      getMessage: async (key) => { 
        if (key && key.id) {
          const cached = messageCache.get(key.id) as any;
          if (cached) return cached;
        }
        return { conversation: 'ping' };
      },
      // Patching message to avoid some common 515 triggers
      patchMessageBeforeSending: (message: any) => {
        const requiresPatch = !!(
          message.buttonsMessage ||
          message.listMessage ||
          message.templateMessage ||
          message.interactiveMessage ||
          message.viewOnceMessage?.message?.buttonsMessage ||
          message.viewOnceMessage?.message?.listMessage
        );
        if (requiresPatch) {
          return {
            viewOnceMessage: {
              message: {
                ...message,
                messageContextInfo: {
                  deviceListMetadata: {},
                  deviceListMetadataVersion: 2
                }
              }
            }
          };
        }
        return message;
      }
    });

    let session = activeSessions.get(id);
    if (!session) {
      session = {
        id,
        name,
        sock,
        qr: null,
        status: 'connecting',
        user: state.creds.me || null,
        reconnectAttempts: 0,
        messages: []
      };
      activeSessions.set(id, session);
    } else {
      // Cleanup previous socket completely before replacing
      if (session.sock && session.sock !== sock) {
        try {
          session.sock.ev.removeAllListeners('connection.update');
          session.sock.ev.removeAllListeners('creds.update');
          session.sock.end(undefined);
          if (typeof session.sock.destroy === 'function') {
            session.sock.destroy();
          }
        } catch (e) {}
      }
      session.sock = sock;
      session.status = 'connecting';
      session.user = state.creds.me || null;
      if (!session.messages) session.messages = [];
    }

    // Save name for persistence
    fs.writeFileSync(path.join(sessionAuthFolder, 'session_name.txt'), name);

    sock.ev.on('connection.update', async (update: any) => {
      // Only handle updates for the current socket of this session
      if (!activeSessions.has(id) || session!.sock !== sock || session!.isDeleting) {
        return;
      }

      const { connection, lastDisconnect, qr } = update;
      
      if (qr) {
        session!.qr = await QRCode.toDataURL(qr);
      }

      if (connection === 'close') {
        const statusCode = (lastDisconnect?.error as any)?.output?.statusCode;
        const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
        const errorMsg = lastDisconnect?.error?.message || 'Unknown error';
        
        console.log(`[WA] Session ${id} connection closed. Code: ${statusCode}. Error: ${errorMsg}. Reconnecting: ${shouldReconnect}`);
        
        session!.status = shouldReconnect ? 'close' : 'loggedOut';
        session!.qr = null;

        // If explicitly logged out or device removed, clean up the data
        if (statusCode === DisconnectReason.loggedOut || statusCode === 401) {
          console.log(`[WA] Session ${id} logged out (401/device_removed). Clearing session and auth data...`);
          const sessionAuthFolder = path.join(activeAuthFolder, id);
          deleteFolderRecursive(sessionAuthFolder).catch(e => console.error(`[WA] Background cleanup failed for ${id}:`, e));
          activeSessions.delete(id);
          return;
        }
        
        if (shouldReconnect) {
          if (session!.reconnectTimeout) clearTimeout(session!.reconnectTimeout);
          
          session!.reconnectAttempts = (session!.reconnectAttempts || 0) + 1;
          
          // Use a fast and smart exponential backoff for reconnection
          // Starts at ~3 seconds, multiplies by 2 for each retry, capped at 45 seconds
          const baseDelay = Math.min(3000 * Math.pow(2, (session!.reconnectAttempts || 1) - 1), 45000);
          const jitter = Math.random() * 2000;
          const delay = baseDelay + jitter;
          
          console.log(`[WA] Reconnect trigger for session ${id} (Error ${statusCode || 'Unknown'}). Resetting in ${Math.round(delay/1000)} seconds... (Attempt ${session!.reconnectAttempts})`);

          // If we hit too many consecutive failures (e.g., >= 15 attempts without successfully connecting), we pause automatic reconnection.
          // IMPORTANT: NEVER delete the credentials directory for network/stream errors like 515 (restartRequired) or typical timeouts,
          // as we want to avoid forcing the user to unnecessarily re-scan their QR code.
          if ((session!.reconnectAttempts || 0) >= 15) {
             console.warn(`[WA] Session ${id} failed to reconnect after ${session!.reconnectAttempts} attempts. Pausing auto-reconnect to prevent log spam. Session credentials remain intact – user can retry manually or restart.`);
             session!.status = 'close';
             session!.reconnectAttempts = 0;
             return;
          }

          session!.reconnectTimeout = setTimeout(async () => {
            try {
              if (activeSessions.has(id) && !session!.isDeleting) {
                console.log(`[WA] Attempting scheduled restart for session ${id} (Previous error: ${statusCode})...`);
                // Force cleanup of old socket state if it's still hanging around
                if (sock) {
                   sock.ev.removeAllListeners('connection.update');
                   sock.ev.removeAllListeners('creds.update');
                   try { sock.end(undefined); } catch(e) {}
                }
                await createSession(id, name, isPrivate);
              }
            } catch (err) {
              console.error(`[WA] Reconnection failed for session ${id}:`, err);
            }
          }, delay);
        } else {
          console.log(`[WA] Session ${id} logged out or unauthorized. Status: ${session!.status}`);
          session!.reconnectAttempts = 0;
        }
      } else if (connection === 'open') {
        session!.status = 'open';
        session!.qr = null;
        session!.user = sock.user;
        session!.reconnectAttempts = 0; // Reset on successful connection
        console.log(`WhatsApp session ${name} (${id}) opened`);

        // Fetch profile picture
        try {
          const jid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
          session!.profilePic = await sock.profilePictureUrl(jid, 'image');
        } catch (e) {
          session!.profilePic = null;
        }
      } else if (connection === 'connecting') {
        session!.status = 'connecting';
      }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      for (const msg of messages) {
        if (msg.key && msg.key.id && msg.message) {
          messageCache.set(msg.key.id, msg.message);
        }
      }
    });

    sock.ev.on('message-receipt.update', (events) => {
      for (const { key, receipt } of events) {
        const session = activeSessions.get(id);
        if (session && session.messages) {
          const msg = session.messages.find(m => m.id === key.id);
          if (msg) {
            const r = receipt as any;
            if (r.readAt) {
              msg.status = 'read';
            } else if (r.deliveredAt) {
              msg.status = 'delivered';
            }
          }
        }
      }
    });

    sock.ev.on('messages.update', (updates) => {
      for (const { key, update } of updates) {
        const session = activeSessions.get(id);
        if (session && session.messages) {
          const msg = session.messages.find(m => m.id === key.id);
          if (msg) {
            const statusVal = update.status as any;
            if (statusVal === 3 || statusVal === 4) {
              msg.status = 'read';
            } else if (statusVal === 2) {
              msg.status = 'delivered';
            } else if (statusVal === 1) {
              msg.status = 'sent';
            } else if (statusVal === 0 || statusVal === 6) {
              msg.status = 'failed';
            }
          }
        }
      }
    });

    sock.ev.on('creds.update', saveCreds);

    return session;
    } finally {
      activeLock.delete(id);
    }
  };

  // Load existing sessions on startup
  const existingSessions = fs.readdirSync(baseAuthFolder);
  for (const sessionId of existingSessions) {
    if (sessionId.startsWith('private_')) {
      console.log(`[WA-STARTUP] Skipping legacy private session ${sessionId} found in demo directory to avoid conflicts.`);
      continue;
    }
    const sessionPath = path.join(baseAuthFolder, sessionId);
    if (fs.statSync(sessionPath).isDirectory()) {
      let sessionName = `Session ${sessionId}`;
      const nameFilePath = path.join(sessionPath, 'session_name.txt');
      if (fs.existsSync(nameFilePath)) {
        sessionName = fs.readFileSync(nameFilePath, 'utf-8');
      }
      createSession(sessionId, sessionName, false);
    }
  }

  // Load existing private sender sessions on startup
  const existingPrivateSessions = fs.readdirSync(privateSenderAuthFolder);
  for (const sessionId of existingPrivateSessions) {
    const sessionPath = path.join(privateSenderAuthFolder, sessionId);
    if (fs.statSync(sessionPath).isDirectory()) {
      let sessionName = `Private ${sessionId}`;
      const nameFilePath = path.join(sessionPath, 'session_name.txt');
      if (fs.existsSync(nameFilePath)) {
        sessionName = fs.readFileSync(nameFilePath, 'utf-8');
      }
      createSession(sessionId, sessionName, true);
    }
  }

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', env: process.env.NODE_ENV });
  });

  // DB initialization & data synchronization routes for MySQL Database
  app.get('/api/db/init', async (req, res) => {
    try {
      if (!isDbConnected()) {
        console.warn('[DB] Skipping database init, database not connected. Falling back to local state.');
        return res.json({
          success: false,
          mongodbConnected: false,
          mysqlConnected: false,
          error: 'Database is not connected'
        });
      }
      const users = await (DbUser as any).find({}).lean();
      const campaigns = await (DbCampaign as any).find({}).lean();
      const transactions = await (DbTransaction as any).find({}).lean();

      // Retrieve new collections
      const citiesResult = await (DbCity as any).find({}).lean();
      const whitelistedResult = await (DbWhitelist as any).find({}).lean();
      const nonWhatsappResult = await (DbNonWhatsapp as any).find({}).lean();
      const whitelistRecordsResult = await (DbWhitelistRecord as any).find({}).lean();
      const nonWhatsappRecordsResult = await (DbNonWhatsappRecord as any).find({}).lean();
      const adminStaffResult = await (DbAdminStaff as any).find({}).lean();
      const campaignConfigResult = await (DbCampaignConfig as any).find({}).lean();

      // Convert arrays back to target formats where necessary:
      const cities = citiesResult.map((c: any) => c.name);
      const whitelistedNumbers = whitelistedResult.map((w: any) => w.number);
      const nonWhatsappNumbers = nonWhatsappResult.map((n: any) => n.number);

      res.json({
        success: true,
        users,
        campaigns,
        transactions,
        cities,
        whitelistedNumbers,
        nonWhatsappNumbers,
        whitelistRecords: whitelistRecordsResult,
        nonWhatsappRecords: nonWhatsappRecordsResult,
        adminStaff: adminStaffResult,
        campaignConfig: campaignConfigResult,
        mongodbConnected: true,
        mysqlConnected: true
      });
    } catch (err: any) {
      console.error('[DB] Failed to fetch synced state from MySQL:', err);
      res.json({
        success: false,
        mongodbConnected: false,
        mysqlConnected: false,
        error: err.message
      });
    }
  });

  app.post('/api/db/sync-users', async (req, res) => {
    try {
      if (!isDbConnected()) {
        return res.status(503).json({ error: 'Database is not connected', mongodbConnected: false, mysqlConnected: false });
      }
      const { users } = req.body;
      if (!Array.isArray(users)) {
        return res.status(400).json({ error: 'invalid users array' });
      }

      for (const u of users) {
        if (!u.id) continue;
        await DbUser.updateOne({ id: u.id }, { $set: u }, { upsert: true });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('[DB] Failed to sync users to MySQL:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/db/sync-campaigns', async (req, res) => {
    try {
      if (!isDbConnected()) {
        return res.status(503).json({ error: 'Database is not connected', mongodbConnected: false, mysqlConnected: false });
      }
      const { campaigns } = req.body;
      if (!Array.isArray(campaigns)) {
        return res.status(400).json({ error: 'invalid campaigns array' });
      }

      for (const c of campaigns) {
        if (!c.id) continue;
        await DbCampaign.updateOne({ id: c.id }, { $set: c }, { upsert: true });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('[DB] Failed to sync campaigns to MySQL:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/db/sync-transactions', async (req, res) => {
    try {
      if (!isDbConnected()) {
        return res.status(503).json({ error: 'Database is not connected', mongodbConnected: false, mysqlConnected: false });
      }
      const { transactions } = req.body;
      if (!Array.isArray(transactions)) {
        return res.status(400).json({ error: 'invalid transactions array' });
      }

      for (const t of transactions) {
        if (!t.id) continue;
        await DbTransaction.updateOne({ id: t.id }, { $set: t }, { upsert: true });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('[DB] Failed to sync transactions to MySQL:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/db/sync-cities', async (req, res) => {
    try {
      if (!isDbConnected()) {
        return res.status(503).json({ error: 'Database is not connected' });
      }
      const { cities } = req.body;
      if (!Array.isArray(cities)) {
        return res.status(400).json({ error: 'invalid cities array' });
      }
      await DbCity.deleteMany({});
      for (const cityName of cities) {
        if (!cityName) continue;
        await DbCity.updateOne({ id: cityName }, { $set: { id: cityName, name: cityName } }, { upsert: true });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('[DB] Failed to sync cities:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/db/sync-whitelisted-numbers', async (req, res) => {
    try {
      if (!isDbConnected()) {
        return res.status(503).json({ error: 'Database is not connected' });
      }
      const { whitelistedNumbers } = req.body;
      if (!Array.isArray(whitelistedNumbers)) {
        return res.status(400).json({ error: 'invalid numbers array' });
      }
      await DbWhitelist.deleteMany({});
      for (const num of whitelistedNumbers) {
        if (!num) continue;
        await DbWhitelist.updateOne({ id: num }, { $set: { id: num, number: num } }, { upsert: true });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('[DB] Failed to sync whitelisted numbers:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/db/sync-non-whatsapp-numbers', async (req, res) => {
    try {
      if (!isDbConnected()) {
        return res.status(503).json({ error: 'Database is not connected' });
      }
      const { nonWhatsappNumbers } = req.body;
      if (!Array.isArray(nonWhatsappNumbers)) {
        return res.status(400).json({ error: 'invalid numbers array' });
      }
      await DbNonWhatsapp.deleteMany({});
      for (const num of nonWhatsappNumbers) {
        if (!num) continue;
        await DbNonWhatsapp.updateOne({ id: num }, { $set: { id: num, number: num } }, { upsert: true });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('[DB] Failed to sync non whatsapp numbers:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/db/sync-whitelist-records', async (req, res) => {
    try {
      if (!isDbConnected()) {
        return res.status(503).json({ error: 'Database is not connected' });
      }
      const { whitelistRecords } = req.body;
      if (!Array.isArray(whitelistRecords)) {
        return res.status(400).json({ error: 'invalid records array' });
      }
      await DbWhitelistRecord.deleteMany({});
      for (const rec of whitelistRecords) {
        if (!rec.id) continue;
        await DbWhitelistRecord.updateOne({ id: rec.id }, { $set: rec }, { upsert: true });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('[DB] Failed to sync whitelist records:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/db/sync-non-whatsapp-records', async (req, res) => {
    try {
      if (!isDbConnected()) {
        return res.status(503).json({ error: 'Database is not connected' });
      }
      const { nonWhatsappRecords } = req.body;
      if (!Array.isArray(nonWhatsappRecords)) {
        return res.status(400).json({ error: 'invalid records array' });
      }
      await DbNonWhatsappRecord.deleteMany({});
      for (const rec of nonWhatsappRecords) {
        if (!rec.id) continue;
        await DbNonWhatsappRecord.updateOne({ id: rec.id }, { $set: rec }, { upsert: true });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('[DB] Failed to sync non whatsapp records:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/db/sync-admin-staff', async (req, res) => {
    try {
      if (!isDbConnected()) {
        return res.status(503).json({ error: 'Database is not connected' });
      }
      const { adminStaff } = req.body;
      if (!Array.isArray(adminStaff)) {
        return res.status(400).json({ error: 'invalid staff array' });
      }
      await DbAdminStaff.deleteMany({});
      for (const staff of adminStaff) {
        if (!staff.id) continue;
        await DbAdminStaff.updateOne({ id: staff.id }, { $set: staff }, { upsert: true });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('[DB] Failed to sync admin staff:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/db/sync-campaign-config', async (req, res) => {
    try {
      if (!isDbConnected()) {
        return res.status(503).json({ error: 'Database is not connected' });
      }
      const { configs } = req.body;
      if (!Array.isArray(configs)) {
        return res.status(400).json({ error: 'invalid configs array' });
      }
      for (const conf of configs) {
        if (!conf.id) continue;
        await DbCampaignConfig.updateOne({ id: conf.id }, { $set: conf }, { upsert: true });
      }
      res.json({ success: true });
    } catch (err: any) {
      console.error('[DB] Failed to sync campaign config:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/whatsapp/status', (req, res) => {
    console.log('[API] GET /api/whatsapp/status');
    try {
      const sessionList = Array.from(sessions.values()).map(s => ({
        id: s.id,
        name: s.name,
        status: s.status,
        qr: s.qr,
        user: s.user,
        profilePic: s.profilePic,
        messages: s.messages || [],
        isRestricted: s.isRestricted || false
      }));
      res.json({ sessions: sessionList });
    } catch (err) {
      console.error('[API] Error in /api/whatsapp/status:', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  app.post('/api/whatsapp/create', async (req, res) => {
    try {
      const { id: reqId, name } = req.body;
      const id = reqId || Date.now().toString();
      const session = await createSession(id, name);
      if (!session) {
        throw new Error('Failed to create session');
      }
      res.json({ id: session.id, name: session.name });
    } catch (err: any) {
      console.error('[API] Error in /api/whatsapp/create:', err);
      res.status(500).json({ error: err.message || 'Failed to create session' });
    }
  });

  app.post('/api/whatsapp/check', async (req, res) => {
    const { sessionId, number } = req.body;
    const session = sessions.get(sessionId);
    
    if (!session || session.status !== 'open') {
      return res.status(400).json({ error: 'WhatsApp session not connected' });
    }

    if (session.isRestricted) {
      return res.status(403).json({ 
        error: "Account Restricted (Error 463): WhatsApp has blocked new contact initiations from this account.", 
        isRestricted: true 
      });
    }

    try {
      let num = number.replace(/\D/g, '');
      if (num.startsWith('00')) {
        num = num.substring(2);
      }
      if (num.startsWith('0') && num.length === 11) {
        num = num.substring(1);
      }
      if (num.length === 10) {
        num = '91' + num;
      }
      
      const jid = num + '@s.whatsapp.net';
      let exists = false;
      try {
        const [result] = await session.sock.onWhatsApp(jid);
        exists = !!result;
      } catch (err: any) {
        console.warn(`[WA-CHECK] onWhatsApp query failed for ${number}, falling back to true:`, err.message || err);
        exists = true; // Fallback to send anyway to prevent blocking
      }
      
      // If result is empty, we also fallback to true if the number structure is valid (7-15 digits)
      if (!exists && num.length >= 7 && num.length <= 15) {
        console.log(`[WA-CHECK] onWhatsApp returned not found for ${number}, but structurally valid. Fallback to exists: true to prevent blocking delivery.`);
        exists = true;
      }
      
      res.json({ exists: exists, jid: jid });
    } catch (error: any) {
      console.error(`[API] Fail-safe active for check number ${number}:`, error);
      res.json({ exists: true, jid: number + '@s.whatsapp.net', warning: error.message });
    }
  });

  app.post('/api/whatsapp/send', async (req, res) => {
    const { id, sessionId, to, message, campaignName } = req.body;
    const session = sessions.get(id || sessionId);
    
    if (!session || session.status !== 'open') {
      return res.status(400).json({ error: 'WhatsApp session not connected' });
    }

    if (session.isRestricted) {
      return res.status(403).json({ 
        error: "Account Restricted (Error 463): WhatsApp has blocked new message delivery on this account.", 
        isRestricted: true 
      });
    }

    try {
      // Remove any non-digit characters (like +)
      let num = to.replace(/\D/g, '');
      
      if (num.startsWith('00')) {
        num = num.substring(2);
      }
      if (num.startsWith('0') && num.length === 11) {
        num = num.substring(1);
      }
      
      // For delivery to work on WhatsApp, the JID must include the country code.
      // If the user provides a 10-digit number, we assume it's an Indian number and add '91'.
      // If it's already 12 digits starting with '91', we leave it as is.
      if (num.length === 10) {
        num = '91' + num;
      } else if (num.length === 12 && num.startsWith('91')) {
        // Already has country code, keep it
      }
      
      const formattedNumber = num + '@s.whatsapp.net';
      const { mediaType, mediaData, fileName } = req.body;

      console.log(`[API] Attempting to send message to: ${formattedNumber} (Type: ${mediaType || 'text'})`);
      
      let sentMsg: any;
      if (mediaType && mediaData) {
        const buffer = Buffer.from(mediaData.split(',')[1] || mediaData, 'base64');
        
        if (mediaType === 'image') {
          sentMsg = await session.sock.sendMessage(formattedNumber, { 
            image: buffer, 
            caption: message 
          });
        } else if (mediaType === 'video') {
          sentMsg = await session.sock.sendMessage(formattedNumber, { 
            video: buffer, 
            caption: message 
          });
        } else if (mediaType === 'pdf' || mediaType === 'document') {
          let mimeType = 'application/pdf';
          if (fileName) {
            const ext = fileName.split('.').pop()?.toLowerCase();
            if (ext === 'doc' || ext === 'docx') mimeType = 'application/msword';
            else if (ext === 'xls' || ext === 'xlsx') mimeType = 'application/vnd.ms-excel';
            else if (ext === 'ppt' || ext === 'pptx') mimeType = 'application/vnd.ms-powerpoint';
            else if (ext === 'txt') mimeType = 'text/plain';
          }
          sentMsg = await session.sock.sendMessage(formattedNumber, { 
            document: buffer, 
            mimetype: mimeType,
            fileName: fileName || 'document.pdf',
            caption: message 
          });
        }
      } else {
        sentMsg = await session.sock.sendMessage(formattedNumber, { text: message });
      }

      // Track the message
      if (sentMsg && sentMsg.key && sentMsg.key.id) {
        if (!session.messages) session.messages = [];
        session.messages.push({
          id: sentMsg.key.id,
          to: to,
          status: 'sent',
          timestamp: Date.now(),
          text: message,
          campaignName: campaignName
        });
        
        // Keep only last 1000 messages to save memory
        if (session.messages.length > 1000) {
          session.messages.shift();
        }
      }

      console.log(`[API] Message sent successfully to: ${formattedNumber}`);
      res.json({ success: true });
    } catch (error: any) {
      const isRestrictedErr = error.message?.includes('463') || 
                              error.message?.toLowerCase()?.includes('restricted') || 
                              error.message?.includes('tctoken');
      if (isRestrictedErr) {
        session.isRestricted = true;
        console.log(`[WA] Session rate adjustment applied (Code 463) for contact check`);
        res.status(500).json({ 
          error: "Account Restricted (Error 463): WhatsApp blocked sending messages to new contacts from this number.", 
          code: 463,
          isRestricted: true 
        });
      } else {
        console.log(`[WA] Pending dispatch status: ${error.message || error}`);
        res.status(500).json({ error: error.message });
      }
    }
  });

  app.post('/api/whatsapp/update-dp', async (req, res) => {
    const { sessionId, imageData } = req.body;
    const session = sessions.get(sessionId);

    if (!session || session.status !== 'open') {
      return res.status(400).json({ error: 'WhatsApp session not connected' });
    }

    try {
      if (!imageData) {
        return res.status(400).json({ error: 'Image data is required' });
      }

      // Baileys expects a JID and a buffer
      const jid = session.user.id.split(':')[0] + '@s.whatsapp.net';
      const buffer = Buffer.from(imageData.split(',')[1] || imageData, 'base64');
      
      console.log(`[API] Updating DP for ${jid}`);
      await session.sock.updateProfilePicture(jid, buffer);
      
      // Update local profile pic if possible (may take a moment for CDN to refresh, but we can try to refetch)
      try {
        session.profilePic = await session.sock.profilePictureUrl(jid, 'image');
      } catch (e) {}

      res.json({ success: true });
    } catch (error: any) {
      console.error(`[API] Failed to update DP for ${sessionId}:`, error);
      res.status(500).json({ error: error.message });
    }
  });

  const deleteFolderRecursive = async (folderPath: string, retries = 5) => {
    // Give a bit of time for file handles to be released after socket closure
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    for (let i = 0; i < retries; i++) {
      try {
        if (fs.existsSync(folderPath)) {
          console.log(`Attempting to delete folder: ${folderPath} (Attempt ${i + 1})`);
          await fs.promises.rm(folderPath, { recursive: true, force: true });
        }
        // Double check if it's really gone
        if (!fs.existsSync(folderPath)) {
          return true;
        }
        console.log(`Folder still exists after fs.rm: ${folderPath}`);
      } catch (e) {
        console.error(`Attempt ${i + 1} to delete ${folderPath} failed:`, e);
      }
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
    return false;
  };

  app.post('/api/whatsapp/logout', async (req, res) => {
    const { sessionId } = req.body;
    
    if (!sessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    console.log(`[LOGOUT] Request received for sessionId: ${sessionId}`);
    const session = sessions.get(sessionId);
    
    if (session) {
      console.log(`[LOGOUT] Found active session for ${sessionId}, stopping...`);
      session.isDeleting = true;
      if (session.reconnectTimeout) {
        clearTimeout(session.reconnectTimeout);
      }
      try {
        // End the socket connection
        session.sock.ev.removeAllListeners('connection.update');
        session.sock.ev.removeAllListeners('creds.update');
        
        // Try to logout gracefully only if connection is open
        if (session.status === 'open') {
          console.log(`[LOGOUT] Attempting socket logout for ${sessionId}`);
          try {
            await Promise.race([
              session.sock.logout(),
              new Promise((_, reject) => setTimeout(() => reject(new Error('Logout Timeout')), 3000))
            ]);
          } catch (err: any) {
            // "Intentional Logout" and "Connection Closed" are expected or harmless during logout
            if (err.message !== 'Intentional Logout' && err.message !== 'Connection Closed' && err.message !== 'Logout Timeout') {
              console.log(`[LOGOUT] Socket logout notice: ${err.message}`);
            }
          }
        } else {
          console.log(`[LOGOUT] Session ${sessionId} status is ${session.status}, skipping socket logout`);
        }
        
        session.sock.end();
        console.log(`[LOGOUT] Socket ended for ${sessionId}`);
      } catch (e) {
        console.error(`[LOGOUT] Error during socket cleanup for ${sessionId}`, e);
      }
      sessions.delete(sessionId);
    } else {
      console.log(`[LOGOUT] No active session found in memory for ${sessionId}, proceeding to folder deletion`);
    }

    // Always ensure the auth folder is removed from disk
    if (!sessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }
    const sessionAuthFolder = path.join(baseAuthFolder, sessionId);
    console.log(`[LOGOUT] Target folder for deletion: ${sessionAuthFolder}`);
    
    const deleted = await deleteFolderRecursive(sessionAuthFolder);
    
    if (deleted) {
      console.log(`[LOGOUT] Successfully removed folder for session ${sessionId}`);
      res.json({ success: true });
    } else {
      console.error(`[LOGOUT] Failed to remove session folder ${sessionId} after all attempts`);
      res.status(500).json({ error: 'Failed to delete session data from disk. It might be locked by the system.' });
    }
  });

  // ==========================================
  // Private Sender API Routes (Completely Isolated)
  // ==========================================

  app.get('/api/private-sender/status', (req, res) => {
    console.log('[API] GET /api/private-sender/status');
    try {
      const sessionList = Array.from(privateSenderSessions.values()).map(s => ({
        id: s.id,
        name: s.name,
        status: s.status,
        qr: s.qr,
        user: s.user,
        profilePic: s.profilePic,
        messages: s.messages || [],
        isRestricted: s.isRestricted || false
      }));
      res.json({ sessions: sessionList });
    } catch (err) {
      console.error('[API] Error in /api/private-sender/status:', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  app.post('/api/private-sender/create', async (req, res) => {
    try {
      const { id: reqId, name } = req.body;
      const id = reqId || Date.now().toString();
      const session = await createSession(id, name, true);
      if (!session) {
        throw new Error('Failed to create private session');
      }
      res.json({ id: session.id, name: session.name });
    } catch (err: any) {
      console.error('[API] Error in /api/private-sender/create:', err);
      res.status(500).json({ error: err.message || 'Failed to create private session' });
    }
  });

  app.post('/api/private-sender/check', async (req, res) => {
    const { sessionId, number } = req.body;
    const session = privateSenderSessions.get(sessionId);
    
    if (!session || session.status !== 'open') {
      return res.status(400).json({ error: 'WhatsApp private session not connected' });
    }

    if (session.isRestricted) {
      return res.status(403).json({ 
        error: "Account Restricted (Error 463): WhatsApp has blocked new contact initiations from this account.", 
        isRestricted: true 
      });
    }

    try {
      let num = number.replace(/\D/g, '');
      if (num.length === 10) {
        num = '91' + num;
      }
      
      const jid = num + '@s.whatsapp.net';
      let exists = false;
      try {
        const [result] = await session.sock.onWhatsApp(jid);
        exists = !!result;
      } catch (err: any) {
        console.warn(`[WA-CHECK-PRIVATE] onWhatsApp query failed for ${number}, falling back to true:`, err.message || err);
        exists = true; // Fallback to send anyway to prevent blocking
      }
      
      // If result is empty, we also fallback to true if the number structure is valid (7-15 digits)
      if (!exists && num.length >= 7 && num.length <= 15) {
        console.log(`[WA-CHECK-PRIVATE] onWhatsApp returned not found for ${number}, but structurally valid. Fallback to exists: true to prevent blocking delivery.`);
        exists = true;
      }
      
      res.json({ exists: exists, jid: jid });
    } catch (error: any) {
      console.error(`[API] Private fail-safe active for check number ${number}:`, error);
      res.json({ exists: true, jid: number + '@s.whatsapp.net', warning: error.message });
    }
  });

  app.post('/api/private-sender/send', async (req, res) => {
    const { id, sessionId, to, message, campaignName } = req.body;
    const session = privateSenderSessions.get(id || sessionId);
    
    if (!session || session.status !== 'open') {
      return res.status(400).json({ error: 'WhatsApp private session not connected' });
    }

    if (session.isRestricted) {
      return res.status(403).json({ 
        error: "Account Restricted (Error 463): WhatsApp has blocked new message delivery on this account.", 
        isRestricted: true 
      });
    }

    try {
      let num = to.replace(/\D/g, '');
      if (num.length === 10) {
        num = '91' + num;
      }
      
      const formattedNumber = num + '@s.whatsapp.net';
      const { mediaType, mediaData, fileName } = req.body;

      console.log(`[API] Attempting to send private message to: ${formattedNumber} (Type: ${mediaType || 'text'})`);
      
      let sentMsg: any;
      if (mediaType && mediaData) {
        const buffer = Buffer.from(mediaData.split(',')[1] || mediaData, 'base64');
        
        if (mediaType === 'image') {
          sentMsg = await session.sock.sendMessage(formattedNumber, { 
            image: buffer, 
            caption: message 
          });
        } else if (mediaType === 'video') {
          sentMsg = await session.sock.sendMessage(formattedNumber, { 
            video: buffer, 
            caption: message 
          });
        } else if (mediaType === 'pdf' || mediaType === 'document') {
          let mimeType = 'application/pdf';
          if (fileName) {
            const ext = fileName.split('.').pop()?.toLowerCase();
            if (ext === 'doc' || ext === 'docx') mimeType = 'application/msword';
            else if (ext === 'xls' || ext === 'xlsx') mimeType = 'application/vnd.ms-excel';
            else if (ext === 'ppt' || ext === 'pptx') mimeType = 'application/vnd.ms-powerpoint';
            else if (ext === 'txt') mimeType = 'text/plain';
          }
          sentMsg = await session.sock.sendMessage(formattedNumber, { 
            document: buffer, 
            mimetype: mimeType,
            fileName: fileName || 'document.pdf',
            caption: message 
          });
        }
      } else {
        sentMsg = await session.sock.sendMessage(formattedNumber, { text: message });
      }

      if (sentMsg && sentMsg.key && sentMsg.key.id) {
        if (!session.messages) session.messages = [];
        session.messages.push({
          id: sentMsg.key.id,
          to: to,
          status: 'sent',
          timestamp: Date.now(),
          text: message,
          campaignName: campaignName
        });
        
        if (session.messages.length > 1000) {
          session.messages.shift();
        }
      }

      console.log(`[API] Private message sent successfully to: ${formattedNumber}`);
      res.json({ success: true });
    } catch (error: any) {
      const isRestrictedErr = error.message?.includes('463') || 
                              error.message?.toLowerCase()?.includes('restricted') || 
                              error.message?.includes('tctoken');
      if (isRestrictedErr) {
        session.isRestricted = true;
        console.log(`[WA] Private session rate adjustment applied (Code 463) for contact check`);
        res.status(500).json({ 
          error: "Account Restricted (Error 463): WhatsApp blocked sending messages to new contacts from this number.", 
          code: 463,
          isRestricted: true 
        });
      } else {
        console.log(`[WA] Private pending dispatch status: ${error.message || error}`);
        res.status(500).json({ error: error.message });
      }
    }
  });

  app.post('/api/private-sender/bulk-send', async (req, res) => {
    const { id, sessionId, recipients, mediaType, mediaData, fileName, campaignName } = req.body;
    const sessId = id || sessionId;
    const session = privateSenderSessions.get(sessId);
    
    if (!session || session.status !== 'open') {
      return res.status(400).json({ error: 'WhatsApp private session not connected' });
    }

    if (!Array.isArray(recipients) || recipients.length === 0) {
      return res.status(400).json({ error: 'Recipients list is empty' });
    }

    if (session.isRestricted) {
      return res.status(403).json({ 
        error: "Account Restricted (Error 463): WhatsApp has blocked new message delivery on this account.", 
        isRestricted: true 
      });
    }

    // Response immediately to client with enqueued payload status
    res.json({ success: true, message: 'Campaign successfully enqueued and running in the background! 🚀' });

    // Process tasks asynchronously in the background
    (async () => {
      const activeSessionId = sessId;
      console.log(`[WA] Background campaign "${campaignName || 'Unnamed'}" starting with ${recipients.length} recipients...`);
      
      for (let i = 0; i < recipients.length; i++) {
        // Double check session vitality inside background loop
        const currentSession = privateSenderSessions.get(activeSessionId);
        if (!currentSession || currentSession.status !== 'open') {
          console.warn(`[WA] Background campaign aborted: Session is no longer open.`);
          break;
        }

        if (currentSession.isRestricted) {
          console.warn(`[WA] Background campaign aborted: Session restricted (463).`);
          break;
        }

        const recipient = recipients[i];
        let to = recipient.to;
        const message = recipient.message;

        try {
          let num = to.replace(/\D/g, '');
          if (num.length === 10) {
            num = '91' + num;
          }
          const formattedNumber = num + '@s.whatsapp.net';

          let sentMsg: any;
          if (mediaType && mediaData) {
            const buffer = Buffer.from(mediaData.split(',')[1] || mediaData, 'base64');
            
            if (mediaType === 'image') {
              sentMsg = await currentSession.sock.sendMessage(formattedNumber, { 
                image: buffer, 
                caption: message 
              });
            } else if (mediaType === 'video') {
              sentMsg = await currentSession.sock.sendMessage(formattedNumber, { 
                video: buffer, 
                caption: message 
              });
            } else if (mediaType === 'pdf' || mediaType === 'document') {
              let mimeType = 'application/pdf';
              if (fileName) {
                const ext = fileName.split('.').pop()?.toLowerCase();
                if (ext === 'doc' || ext === 'docx') mimeType = 'application/msword';
                else if (ext === 'xls' || ext === 'xlsx') mimeType = 'application/vnd.ms-excel';
                else if (ext === 'ppt' || ext === 'pptx') mimeType = 'application/vnd.ms-powerpoint';
                else if (ext === 'txt') mimeType = 'text/plain';
              }
              sentMsg = await currentSession.sock.sendMessage(formattedNumber, { 
                document: buffer, 
                mimetype: mimeType,
                fileName: fileName || 'document.pdf',
                caption: message 
              });
            }
          } else {
            sentMsg = await currentSession.sock.sendMessage(formattedNumber, { text: message });
          }

          if (sentMsg && sentMsg.key && sentMsg.key.id) {
            if (!currentSession.messages) currentSession.messages = [];
            currentSession.messages.push({
              id: sentMsg.key.id,
              to: to,
              status: 'sent',
              timestamp: Date.now(),
              text: message,
              campaignName: campaignName || 'Quick Sends'
            });
            
            if (currentSession.messages.length > 2000) {
              currentSession.messages.shift();
            }
          }
          console.log(`[WA] [Background] Successfully dispatched to ${to}`);
        } catch (e: any) {
          console.error(`[WA] [Background] Failed to send to ${to}:`, e.message || e);
          
          if (!currentSession.messages) currentSession.messages = [];
          currentSession.messages.push({
            id: 'fail_' + Math.random().toString(36).substr(2, 9),
            to: to,
            status: 'failed',
            timestamp: Date.now(),
            text: message + ` (Error: ${e.message || 'Unknown error'})`,
            campaignName: campaignName || 'Quick Sends'
          });

          if (currentSession.messages.length > 2000) {
            currentSession.messages.shift();
          }

          const isRestrictedErr = e.message?.includes('463') || 
                                  e.message?.toLowerCase()?.includes('restricted') || 
                                  e.message?.includes('tctoken');
          if (isRestrictedErr) {
            currentSession.isRestricted = true;
            console.log(`[WA] [Background] Session rate limits hit or blocked (463). Aborting background queue.`);
            break;
          }
        }

        // Wait original 10-second delay between dispatches to maintain safe deliverability profiles
        if (i < recipients.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 10000));
        }
      }
      console.log(`[WA] Background campaign "${campaignName || 'Unnamed'}" finished processing.`);
    })();
  });

  app.post('/api/private-sender/delete-campaign', async (req, res) => {
    const { sessionId, campaignName } = req.body;
    if (!sessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }
    const session = privateSenderSessions.get(sessionId);
    if (!session) {
      return res.status(404).json({ error: 'Session not found' });
    }

    if (session.messages) {
      session.messages = session.messages.filter((m: any) => {
        const name = m.campaignName || 'Quick Sends';
        return name !== campaignName;
      });
    }

    res.json({ success: true, messages: session.messages || [] });
  });

  app.post('/api/private-sender/update-dp', async (req, res) => {
    const { sessionId, imageData } = req.body;
    const session = privateSenderSessions.get(sessionId);

    if (!session || session.status !== 'open') {
      return res.status(400).json({ error: 'WhatsApp private session not connected' });
    }

    try {
      if (!imageData) {
        return res.status(400).json({ error: 'Image data is required' });
      }

      const jid = session.user.id.split(':')[0] + '@s.whatsapp.net';
      const buffer = Buffer.from(imageData.split(',')[1] || imageData, 'base64');
      
      console.log(`[API] Updating DP for private session ${jid}`);
      await session.sock.updateProfilePicture(jid, buffer);
      
      try {
        session.profilePic = await session.sock.profilePictureUrl(jid, 'image');
      } catch (e) {}

      res.json({ success: true });
    } catch (error: any) {
      console.error(`[API] Failed to update DP for private session ${sessionId}:`, error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/private-sender/logout', async (req, res) => {
    const { sessionId } = req.body;
    
    if (!sessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    console.log(`[LOGOUT] Private request received for sessionId: ${sessionId}`);
    const session = privateSenderSessions.get(sessionId);
    
    if (session) {
      console.log(`[LOGOUT] Found active private session for ${sessionId}, stopping...`);
      session.isDeleting = true;
      if (session.reconnectTimeout) {
        clearTimeout(session.reconnectTimeout);
      }
      try {
        session.sock.ev.removeAllListeners('connection.update');
        session.sock.ev.removeAllListeners('creds.update');
        
        if (session.status === 'open') {
          console.log(`[LOGOUT] Attempting socket logout for private session ${sessionId}`);
          try {
            await Promise.race([
              session.sock.logout(),
              new Promise((_, reject) => setTimeout(() => reject(new Error('Logout Timeout')), 3000))
            ]);
          } catch (err: any) {
            if (err.message !== 'Intentional Logout' && err.message !== 'Connection Closed' && err.message !== 'Logout Timeout') {
              console.log(`[LOGOUT] Socket logout notice: ${err.message}`);
            }
          }
        }
        
        session.sock.end();
      } catch (e) {
        console.error(`[LOGOUT] Error during socket cleanup for private session ${sessionId}`, e);
      }
      privateSenderSessions.delete(sessionId);
    } else {
      console.log(`[LOGOUT] No active private session found in memory for ${sessionId}, proceeding to folder deletion`);
    }

    const sessionAuthFolder = path.join(privateSenderAuthFolder, sessionId);
    console.log(`[LOGOUT] Target private folder for deletion: ${sessionAuthFolder}`);
    
    const deleted = await deleteFolderRecursive(sessionAuthFolder);
    
    if (deleted) {
      res.json({ success: true });
    } else {
      res.status(500).json({ error: 'Failed to delete private session data from disk.' });
    }
  });

  // IMPORTANT: Handled unidentified API routes with JSON 404
  app.all('/api/*', (req, res) => {
    console.log(`[API] 404 Not Found: ${req.method} ${req.path}`);
    res.status(404).json({ error: `Route ${req.method} ${req.path} not found` });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
